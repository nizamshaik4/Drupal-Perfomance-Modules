<?php

namespace Drupal\freyr_performance\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Freyr Speed Optimizer — Professional Settings Form.
 */
class FreyrPerformanceSettingsForm extends ConfigFormBase {

  protected function getEditableConfigNames() {
    return ['freyr_performance.settings'];
  }

  public function getFormId() {
    return 'freyr_performance_settings';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('freyr_performance.settings');

    $form['#attached']['library'][] = 'freyr_performance/freyr_admin';

    // Header.
    $form['page_header'] = [
      '#type'   => 'markup',
      '#markup' => '
      <div class="freyr-settings-header">
        <h1>🚀 Freyr Speed Optimizer Settings</h1>
        <p>Enable all options below for maximum performance. Target: <strong>90+ PageSpeed</strong> on Mobile & Desktop</p>
        <a href="/admin/config/performance/freyr-speed/dashboard" class="freyr-btn freyr-btn-primary">← Back to Dashboard</a>
      </div>',
    ];

    // ── TAB CONTAINER ────────────────────────────────────────────────────────
    $form['tabs'] = ['#type' => 'vertical_tabs', '#default_tab' => 'general'];

    // ══════════════════════════════════════════════════════════════════════════
    // TAB 1: GENERAL
    // ══════════════════════════════════════════════════════════════════════════
    $form['general'] = ['#type' => 'details', '#title' => $this->t('⚙️ General'), '#group' => 'tabs', '#open' => TRUE];

    $form['general']['enable_optimization'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Enable Optimization'),
      '#description'   => $this->t('Master switch. Turn off to disable all optimizations without uninstalling the module.'),
      '#default_value' => $config->get('enable_optimization') ?? TRUE,
    ];

    $form['general']['fix_inp'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Fix INP (Interaction to Next Paint)'),
      '#description'   => $this->t('Adds touch-action:manipulation to all clickable elements. Removes 300ms tap delay on mobile. <strong>+3-5 pts INP on mobile.</strong>'),
      '#default_value' => $config->get('fix_inp') ?? TRUE,
    ];

    $form['general']['exclude_pages'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Exclude Pages from Optimization'),
      '#description'   => $this->t('Enter page paths to exclude (one per line). Example: /cart, /checkout, /user/login'),
      '#default_value' => $config->get('exclude_pages') ?? '',
      '#rows'          => 4,
      '#placeholder'   => "/cart\n/checkout\n/user/login",
    ];

    // ══════════════════════════════════════════════════════════════════════════
    // TAB 2: HERO IMAGE & LCP
    // ══════════════════════════════════════════════════════════════════════════
    $form['lcp'] = ['#type' => 'details', '#title' => $this->t('🔴 LCP — Hero Image'), '#group' => 'tabs'];

    $form['lcp']['lcp_info'] = [
      '#type'   => 'markup',
      '#markup' => '<div class="freyr-tip">💡 <strong>Most important setting!</strong> This single fix can reduce LCP from 5.6s → under 2.5s (+12 pts)</div>',
    ];

    $form['lcp']['hero_image_url'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Hero / First Slide Image URL'),
      '#description'   => $this->t('
        Find it: Open site → F12 → Console → type <code>allow pasting</code> → paste:<br>
        <code style="background:#f4f4f4;padding:5px;display:block;margin:5px 0;border-radius:3px;">document.querySelector(\'.slick-slide:not(.slick-cloned) img\')?.src</code>
        Copy the URL shown and paste here.
      '),
      '#default_value' => $config->get('hero_image_url') ?? '',
      '#placeholder'   => 'https://yoursite.com/sites/default/files/hero.jpg',
      '#size'          => 100,
    ];

    $form['lcp']['preload_media'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Additional Preload Resources'),
      '#description'   => $this->t('Other critical resources to preload (one URL per line). E.g. fonts, above-fold images.'),
      '#default_value' => $config->get('preload_media') ?? '',
      '#rows'          => 3,
      '#placeholder'   => "/sites/default/files/logo.webp\n/fonts/myfont.woff2",
    ];

    // ══════════════════════════════════════════════════════════════════════════
    // TAB 3: CSS OPTIMIZATION
    // ══════════════════════════════════════════════════════════════════════════
    $form['css'] = ['#type' => 'details', '#title' => $this->t('🎨 CSS Optimization'), '#group' => 'tabs'];

    $form['css']['inline_critical_css'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Inline Critical CSS (Above-fold)'),
      '#description'   => $this->t('Injects essential CSS directly into HTML so page renders immediately. <strong>Eliminates render-blocking CSS. +5-8 pts.</strong>'),
      '#default_value' => $config->get('inline_critical_css') ?? TRUE,
    ];

    $form['css']['preconnect_google_fonts'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Preconnect to Google Fonts'),
      '#description'   => $this->t('Establishes early connection to Google Fonts servers. Saves 300-500ms.'),
      '#default_value' => $config->get('preconnect_google_fonts') ?? TRUE,
    ];

    $form['css']['optimize_fonts'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Add font-display:swap to Google Fonts'),
      '#description'   => $this->t('Prevents invisible text (FOIT). Text shows immediately in fallback font. Fixes CLS.'),
      '#default_value' => $config->get('optimize_fonts') ?? TRUE,
    ];

    $form['css']['exclude_css'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Exclude CSS URLs from Optimization'),
      '#description'   => $this->t('CSS files to exclude (one per line).'),
      '#default_value' => $config->get('exclude_css') ?? '',
      '#rows'          => 3,
    ];

    $form['css']['custom_css_onload'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Custom CSS (Loaded on Page Load)'),
      '#description'   => $this->t('Add custom CSS that loads immediately with the page. Useful for above-fold styling.'),
      '#default_value' => $config->get('custom_css_onload') ?? '',
      '#rows'          => 5,
      '#attributes'    => ['style' => 'font-family:monospace'],
    ];

    // ══════════════════════════════════════════════════════════════════════════
    // TAB 4: JAVASCRIPT OPTIMIZATION
    // ══════════════════════════════════════════════════════════════════════════
    $form['js'] = ['#type' => 'details', '#title' => $this->t('⚡ JavaScript Optimization'), '#group' => 'tabs'];

    $form['js']['defer_javascript'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Defer JavaScript (Safe Mode — Analytics Only)'),
      '#description'   => $this->t('Defers only analytics/tracking scripts. jQuery, Slick, Bootstrap, and theme JS are <strong>never touched</strong>. Sliders and menus keep working! <strong>+3-5 pts.</strong>'),
      '#default_value' => $config->get('defer_javascript') ?? TRUE,
    ];

    $form['js']['delay_third_party'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Delay Third-Party Scripts (GTM, GA, Chat, FB Pixel)'),
      '#description'   => $this->t('Third-party scripts load ONLY after user interaction or timeout. <strong>Biggest mobile fix! +10-15 pts.</strong>'),
      '#default_value' => $config->get('delay_third_party') ?? TRUE,
    ];

    $form['js']['gtm_id'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Google Tag Manager ID'),
      '#description'   => $this->t('Your GTM ID (e.g. GTM-XXXXXX). Leave empty if not using GTM.'),
      '#default_value' => $config->get('gtm_id') ?? '',
      '#placeholder'   => 'GTM-XXXXXX',
      '#states'        => ['visible' => [':input[name="delay_third_party"]' => ['checked' => TRUE]]],
    ];

    $form['js']['delay_timeout'] = [
      '#type'          => 'number',
      '#title'         => $this->t('Delay Timeout (milliseconds)'),
      '#description'   => $this->t('How long to wait before loading delayed scripts even without user interaction. Default: 5000 (5 seconds).'),
      '#default_value' => $config->get('delay_timeout') ?? 5000,
      '#min'           => 1000,
      '#max'           => 15000,
    ];

    $form['js']['force_lazy_js'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Force Lazy Load JavaScript (one URL pattern per line)'),
      '#description'   => $this->t('Additional JS files to defer. Enter partial URL/filename. E.g. chatwidget.js'),
      '#default_value' => $config->get('force_lazy_js') ?? '',
      '#rows'          => 3,
    ];

    $form['js']['exclude_js'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Exclude JavaScript from Lazy Load'),
      '#description'   => $this->t('JS files that should never be deferred (one per line).'),
      '#default_value' => $config->get('exclude_js') ?? '',
      '#rows'          => 3,
    ];

    $form['js']['custom_js_onload'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Custom JavaScript (On Page Load)'),
      '#description'   => $this->t('JavaScript that runs immediately on page load.'),
      '#default_value' => $config->get('custom_js_onload') ?? '',
      '#rows'          => 5,
      '#attributes'    => ['style' => 'font-family:monospace'],
    ];

    $form['js']['custom_js_after_load'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Custom JavaScript (After Page Load)'),
      '#description'   => $this->t('JavaScript that runs after the page fully loads (window.load event).'),
      '#default_value' => $config->get('custom_js_after_load') ?? '',
      '#rows'          => 5,
      '#attributes'    => ['style' => 'font-family:monospace'],
    ];

    // ══════════════════════════════════════════════════════════════════════════
    // TAB 5: IMAGE OPTIMIZATION
    // ══════════════════════════════════════════════════════════════════════════
    $form['images'] = ['#type' => 'details', '#title' => $this->t('🖼️ Image Optimization'), '#group' => 'tabs'];

    $form['images']['lazy_load_images'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Enable Image Lazy Loading'),
      '#description'   => $this->t('All images load only when about to enter viewport. <strong>+5-8 pts.</strong>'),
      '#default_value' => $config->get('lazy_load_images') ?? TRUE,
    ];

    $form['images']['skip_first_image'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Protect First/Hero Image (Always load eagerly)'),
      '#description'   => $this->t('First image always loads immediately with high priority. <strong>Always keep ON.</strong>'),
      '#default_value' => $config->get('skip_first_image') ?? TRUE,
    ];

    $form['images']['fix_image_dimensions'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Auto-fix Missing Image Dimensions (CLS Fix)'),
      '#description'   => $this->t('Adds width/height to images missing dimensions. Prevents layout shift. <strong>+3-5 pts CLS.</strong>'),
      '#default_value' => $config->get('fix_image_dimensions') ?? TRUE,
    ];

    $form['images']['lazy_load_iframes'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Lazy Load iFrames (YouTube, Google Maps)'),
      '#description'   => $this->t('iframes load only when scrolled into view. <strong>+3-5 pts on mobile.</strong>'),
      '#default_value' => $config->get('lazy_load_iframes') ?? TRUE,
    ];

    $form['images']['lazy_load_videos'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Lazy Load Videos'),
      '#description'   => $this->t('Video elements load only when visible.'),
      '#default_value' => $config->get('lazy_load_videos') ?? TRUE,
    ];

    $form['images']['lazy_offset'] = [
      '#type'          => 'number',
      '#title'         => $this->t('Lazy Load Offset (pixels)'),
      '#description'   => $this->t('Start loading images this many pixels before they enter the viewport. Default: 300px.'),
      '#default_value' => $config->get('lazy_offset') ?? 300,
      '#min'           => 0,
      '#max'           => 1000,
    ];

    $form['images']['exclude_lazy_images'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Exclude Images from Lazy Loading'),
      '#description'   => $this->t('Image URL patterns to exclude (one per line). E.g. /logo, /hero'),
      '#default_value' => $config->get('exclude_lazy_images') ?? '',
      '#rows'          => 3,
    ];

    // ══════════════════════════════════════════════════════════════════════════
    // TAB 6: SLICK SLIDER
    // ══════════════════════════════════════════════════════════════════════════
    $form['slider'] = ['#type' => 'details', '#title' => $this->t('🎠 Slick Slider'), '#group' => 'tabs'];

    $form['slider']['optimize_slick'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Optimize Slick Slider for LCP'),
      '#description'   => $this->t('First slide: fetchpriority=high + eager load. Other slides: lazy. Next slide preloads before transition.'),
      '#default_value' => $config->get('optimize_slick') ?? TRUE,
    ];

    $form['slider']['slider_selector'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Slider CSS Selector'),
      '#description'   => $this->t('CSS selector for your slider. Right-click slider → Inspect to find it.'),
      '#default_value' => $config->get('slider_selector') ?? '.slick-slider',
      '#placeholder'   => '.slick-slider',
    ];

    $form['slider']['slider_min_height'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Slider Reserved Height (CLS Prevention)'),
      '#description'   => $this->t('Reserve this height before slider loads to prevent layout shift. Match your slider height.'),
      '#default_value' => $config->get('slider_min_height') ?? '500px',
      '#placeholder'   => '500px',
    ];

    // ══════════════════════════════════════════════════════════════════════════
    // TAB 7: CDN
    // ══════════════════════════════════════════════════════════════════════════
    $form['cdn'] = ['#type' => 'details', '#title' => $this->t('🌐 CDN'), '#group' => 'tabs'];

    $form['cdn']['cdn_info'] = [
      '#type'   => 'markup',
      '#markup' => '<div class="freyr-tip">💡 Set up <strong>Cloudflare</strong> (free) for best results: <a href="https://cloudflare.com" target="_blank">cloudflare.com</a></div>',
    ];

    $form['cdn']['cdn_url'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('CDN URL'),
      '#description'   => $this->t('Your CDN base URL. Leave empty if using Cloudflare (it works automatically). Example: https://cdn.yoursite.com'),
      '#default_value' => $config->get('cdn_url') ?? '',
      '#placeholder'   => 'https://cdn.yoursite.com',
    ];

    // ══════════════════════════════════════════════════════════════════════════
    // TAB 8: RESOURCE HINTS
    // ══════════════════════════════════════════════════════════════════════════
    $form['hints'] = ['#type' => 'details', '#title' => $this->t('🔗 Resource Hints'), '#group' => 'tabs'];

    $form['hints']['prefetch_on_hover'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Prefetch Pages on Nav Hover'),
      '#description'   => $this->t('Next page loads when user hovers a menu link. Makes navigation feel instant.'),
      '#default_value' => $config->get('prefetch_on_hover') ?? TRUE,
    ];

    $form['hints']['optimize_mega_menu'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Optimize Mega Menu (Freyr-specific fix)'),
      '#description'   => $this->t('Your site has 500+ menu links. This adds CSS containment to reduce paint area. <strong>+3-5 pts especially on mobile.</strong>'),
      '#default_value' => $config->get('optimize_mega_menu') ?? TRUE,
    ];

    $form['hints']['dns_prefetch_domains'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('DNS Prefetch Domains'),
      '#description'   => $this->t('External domains to pre-resolve (one per line).'),
      '#default_value' => $config->get('dns_prefetch_domains') ?? "//fonts.googleapis.com\n//fonts.gstatic.com\n//www.googletagmanager.com\n//www.google-analytics.com\n//connect.facebook.net\n//www.freyafusion.com",
      '#rows'          => 6,
    ];

    // ══════════════════════════════════════════════════════════════════════════
    // TAB 9: CACHE
    // ══════════════════════════════════════════════════════════════════════════
    $form['cache_tab'] = ['#type' => 'details', '#title' => $this->t('💾 Cache & Server'), '#group' => 'tabs'];

    $form['cache_tab']['cache_info'] = [
      '#type'   => 'markup',
      '#markup' => '
      <div class="freyr-section-info">
        <h3>✅ Drupal Cache Settings (Do This Now)</h3>
        <ol>
          <li>Go to <a href="/admin/config/development/performance" target="_blank"><strong>Admin → Configuration → Performance</strong></a></li>
          <li>Enable <strong>Aggregate CSS files</strong></li>
          <li>Enable <strong>Aggregate JavaScript files</strong></li>
          <li>Set cache max age to <strong>1 week</strong></li>
          <li>Click <strong>Clear all caches</strong></li>
        </ol>
        <h3>🌐 Cloudflare Setup (Free — Big Score Boost)</h3>
        <ol>
          <li>Sign up free at <a href="https://cloudflare.com" target="_blank">cloudflare.com</a></li>
          <li>Add your domain → Update nameservers</li>
          <li>Enable Auto Minify (CSS + JS + HTML)</li>
          <li>Enable Brotli compression</li>
          <li>Enable Rocket Loader</li>
          <li>Cache level → Standard</li>
        </ol>
        <div class="freyr-tip">These server fixes add +10-15 pts on top of this module!</div>
      </div>',
    ];

    $clear_url = \Drupal\Core\Url::fromRoute('freyr_performance.clear_cache', [], ['query' => ['token' => \Drupal::csrfToken()->get('freyr-clear-cache')]])->toString();
    $form['cache_tab']['clear_cache_btn'] = [
      '#type'   => 'markup',
      '#markup' => '<a href="' . $clear_url . '" class="freyr-btn freyr-btn-warning" style="display:inline-block;margin-top:15px;">🗑️ Clear All Caches Now</a>',
    ];

    return parent::buildForm($form, $form_state);
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $fields = [
      'enable_optimization', 'fix_inp', 'exclude_pages',
      'hero_image_url', 'preload_media',
      'inline_critical_css', 'preconnect_google_fonts', 'optimize_fonts', 'exclude_css', 'custom_css_onload',
      'defer_javascript', 'delay_third_party', 'gtm_id', 'delay_timeout', 'force_lazy_js', 'exclude_js', 'custom_js_onload', 'custom_js_after_load',
      'lazy_load_images', 'skip_first_image', 'fix_image_dimensions', 'lazy_load_iframes', 'lazy_load_videos', 'lazy_offset', 'exclude_lazy_images',
      'optimize_slick', 'slider_selector', 'slider_min_height',
      'cdn_url',
      'prefetch_on_hover', 'optimize_mega_menu', 'dns_prefetch_domains',
    ];

    $config = $this->config('freyr_performance.settings');
    foreach ($fields as $field) {
      $config->set($field, $form_state->getValue($field));
    }
    $config->save();

    drupal_flush_all_caches();
    parent::submitForm($form, $form_state);
    $this->messenger()->addStatus($this->t('✅ Settings saved! All caches cleared. Retest at <a href="https://pagespeed.web.dev" target="_blank">pagespeed.web.dev</a>'));
  }
}
