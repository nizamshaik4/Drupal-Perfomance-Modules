<?php

namespace Drupal\freyr_performance\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Freyr Speed Optimizer — Dashboard Controller.
 */
class FreyrDashboardController extends ControllerBase {

  /**
   * Dashboard page.
   */
  public function dashboard() {
    $config = \Drupal::config('freyr_performance.settings');

    // Get current scores display.
    $settings_url = \Drupal\Core\Url::fromRoute('freyr_performance.settings')->toString();
    $clear_url = \Drupal\Core\Url::fromRoute('freyr_performance.clear_cache', [], ['query' => ['token' => \Drupal::csrfToken()->get('freyr-clear-cache')]])->toString();
    $site_url = \Drupal::request()->getSchemeAndHttpHost();

    $build = [];

    // Header.
    $build['header'] = [
      '#type'   => 'markup',
      '#markup' => '
      <div class="freyr-dashboard-header">
        <div class="freyr-logo-area">
          <h1>🚀 Freyr Speed Optimizer</h1>
          <p>Professional Performance Optimization for Drupal 10</p>
        </div>
        <div class="freyr-header-actions">
          <a href="' . $settings_url . '" class="freyr-btn freyr-btn-primary">⚙️ Settings</a>
          <a href="' . $clear_url . '" class="freyr-btn freyr-btn-warning">🗑️ Clear All Cache</a>
          <a href="https://pagespeed.web.dev/report?url=' . urlencode($site_url) . '" target="_blank" class="freyr-btn freyr-btn-success">📊 Test Score</a>
        </div>
      </div>',
    ];

    // Status cards.
    $opts = [
      ['enable_optimization', '🔌 Optimization', 'Core optimization engine'],
      ['inline_critical_css', '🎨 Critical CSS', 'Above-fold CSS inlined'],
      ['lazy_load_images', '🖼️ Lazy Images', 'Images load on demand'],
      ['defer_javascript', '⚡ Defer JS', 'Analytics scripts deferred'],
      ['delay_third_party', '⏱️ Delay 3rd Party', 'GTM/Chat delayed'],
      ['optimize_slick', '🎠 Slick Slider', 'Slider LCP optimized'],
      ['optimize_mega_menu', '🗂️ Mega Menu', 'Menu containment applied'],
      ['optimize_fonts', '🔤 Fonts', 'Font-display swap enabled'],
      ['prefetch_on_hover', '⚡ Prefetch', 'Pages prefetch on hover'],
      ['fix_inp', '👆 INP Fix', 'Touch delay removed'],
    ];

    $cards = '<div class="freyr-status-grid">';
    foreach ($opts as $opt) {
      $enabled = $config->get($opt[0]) ?? TRUE;
      $status = $enabled ? 'active' : 'inactive';
      $icon = $enabled ? '✅' : '❌';
      $cards .= "<div class='freyr-status-card freyr-{$status}'>
        <div class='freyr-card-icon'>{$opt[1]}</div>
        <div class='freyr-card-label'>{$opt[2]}</div>
        <div class='freyr-card-status'>{$icon} " . ($enabled ? 'Active' : 'Disabled') . "</div>
      </div>";
    }
    $cards .= '</div>';

    $build['status'] = [
      '#type'   => 'markup',
      '#markup' => '<div class="freyr-section"><h2>📋 Optimization Status</h2>' . $cards . '</div>',
    ];

    // Hero image status.
    $hero = $config->get('hero_image_url') ?? '';
    $hero_status = !empty($hero)
      ? '<span class="freyr-good">✅ Set: <code>' . htmlspecialchars($hero) . '</code></span>'
      : '<span class="freyr-bad">❌ Not set — <a href="' . $settings_url . '#hero">Set it now</a> for biggest LCP improvement!</span>';

    // GTM status.
    $gtm = $config->get('gtm_id') ?? '';
    $gtm_status = !empty($gtm)
      ? '<span class="freyr-good">✅ ' . htmlspecialchars($gtm) . ' (delayed mode)</span>'
      : '<span class="freyr-neutral">⚪ Not configured</span>';

    // CDN status.
    $cdn = $config->get('cdn_url') ?? '';
    $cdn_status = !empty($cdn)
      ? '<span class="freyr-good">✅ ' . htmlspecialchars($cdn) . '</span>'
      : '<span class="freyr-neutral">⚪ Not configured</span>';

    $build['config_summary'] = [
      '#type'   => 'markup',
      '#markup' => '
      <div class="freyr-section">
        <h2>⚙️ Configuration Summary</h2>
        <table class="freyr-table">
          <tr><td>Hero Image URL</td><td>' . $hero_status . '</td></tr>
          <tr><td>GTM Integration</td><td>' . $gtm_status . '</td></tr>
          <tr><td>CDN URL</td><td>' . $cdn_status . '</td></tr>
          <tr><td>Slider Selector</td><td><code>' . htmlspecialchars($config->get('slider_selector') ?? '.slick-slider') . '</code></td></tr>
          <tr><td>Slider Height</td><td><code>' . htmlspecialchars($config->get('slider_min_height') ?? '500px') . '</code></td></tr>
          <tr><td>Delay Timeout</td><td><code>' . ($config->get('delay_timeout') ?? 5000) . 'ms</code></td></tr>
        </table>
      </div>',
    ];

    // How to test.
    $build['test'] = [
      '#type'   => 'markup',
      '#markup' => '
      <div class="freyr-section">
        <h2>🧪 Test Your Score</h2>
        <div class="freyr-test-links">
          <a href="https://pagespeed.web.dev/report?url=' . urlencode($site_url) . '&strategy=mobile" target="_blank" class="freyr-test-btn">📱 Test Mobile Score</a>
          <a href="https://pagespeed.web.dev/report?url=' . urlencode($site_url) . '&strategy=desktop" target="_blank" class="freyr-test-btn">🖥️ Test Desktop Score</a>
          <a href="https://gtmetrix.com/" target="_blank" class="freyr-test-btn">📈 GTmetrix</a>
        </div>
      </div>',
    ];

    // ── DYNAMICALLY READ ACTUAL DRUPAL SETTINGS ─────────────────────────────
    $drupal_perf_config = \Drupal::config('system.performance');
    $css_aggregation    = (bool) $drupal_perf_config->get('css.preprocess');
    $js_aggregation     = (bool) $drupal_perf_config->get('js.preprocess');
    $aggregation_done   = $css_aggregation && $js_aggregation;
    $cache_max_age      = (int) $drupal_perf_config->get('cache.page.max_age');
    $cache_done         = $cache_max_age >= 86400; // at least 1 day

    // Detect Cloudflare by checking CF-Ray header (only works if behind CF).
    $cf_ray     = \Drupal::request()->headers->get('CF-Ray', '');
    $cloudflare = !empty($cf_ray);

    // Helper closure to render a checklist item.
    $item = function($done, $label, $fix = '') {
      $cls  = $done ? 'done' : 'todo';
      $icon = $done ? '✅' : '⬜';
      $fix_html = (!$done && !empty($fix)) ? ' <span class="freyr-fix-hint">' . $fix . '</span>' : '';
      return "<div class='freyr-check-item {$cls}'><span class='freyr-check-icon'>{$icon}</span>{$label}{$fix_html}</div>";
    };

    // Build all checklist items with real values.
    $checklist_items =
      $item(!empty($hero),        'Hero Image URL is set (LCP fix)',
            '<a href="' . $settings_url . '">→ Go to Settings → LCP tab</a>') .
      $item($css_aggregation,     'Aggregate CSS files is ON',
            '<a href="/admin/config/development/performance" target="_blank">→ Admin → Performance</a>') .
      $item($js_aggregation,      'Aggregate JavaScript files is ON',
            '<a href="/admin/config/development/performance" target="_blank">→ Admin → Performance</a>') .
      $item($cache_done,          'Browser cache max age ≥ 1 day (currently: ' . ($cache_max_age >= 3600 ? round($cache_max_age/3600) . 'h' : $cache_max_age . 's') . ')',
            '<a href="/admin/config/development/performance" target="_blank">→ Set to 1 week</a>') .
      $item($cloudflare,          'Cloudflare CDN is active',
            '<a href="https://cloudflare.com" target="_blank">→ Set up free at cloudflare.com</a>') .
      $item(!empty($gtm),         'GTM ID configured for delayed loading',
            'Optional — only needed if you use Google Tag Manager') .
      $item(!empty($cdn),         'CDN URL configured for asset delivery',
            'Optional — Cloudflare handles this automatically') .
      $item($config->get('enable_optimization') ?? TRUE, 'Module optimization is enabled') .
      $item($config->get('inline_critical_css') ?? TRUE, 'Critical CSS is inlined') .
      $item($config->get('lazy_load_images') ?? TRUE,    'Image lazy loading is active') .
      $item($config->get('optimize_slick') ?? TRUE,      'Slick slider is optimized') .
      $item($config->get('delay_third_party') ?? TRUE,   'Third-party script delay is active');

    // Score estimate based on real state.
    $score = 29;
    if (!empty($hero))                               $score += 12;
    if ($css_aggregation && $js_aggregation)         $score += 10;
    if ($cache_done)                                 $score += 5;
    if ($cloudflare)                                 $score += 12;
    if ($config->get('inline_critical_css') ?? TRUE) $score += 8;
    if ($config->get('lazy_load_images') ?? TRUE)    $score += 6;
    if ($config->get('delay_third_party') ?? TRUE)   $score += 8;
    if ($config->get('optimize_slick') ?? TRUE)      $score += 5;
    $score = min(98, $score);
    $score_color = $score >= 90 ? '#34a853' : ($score >= 70 ? '#fbbc04' : '#ea4335');
    $score_label = $score >= 90 ? '🟢 Target reached!' : ($score >= 70 ? '🟡 Getting close!' : '🔴 More fixes needed');

    $build['checklist'] = [
      '#type'   => 'markup',
      '#markup' => '
      <div class="freyr-section">
        <h2>✅ 90+ Score Checklist <span class="freyr-live-badge">Live Status</span></h2>
        <div class="freyr-score-row">
          <div class="freyr-score-display" style="border-color:' . $score_color . ';color:' . $score_color . '">
            <span class="freyr-score-num">' . $score . '</span>
            <span class="freyr-score-label">/100 est.</span>
          </div>
          <div class="freyr-score-msg">' . $score_label . '<br><small>Based on current configuration</small></div>
        </div>
        <div class="freyr-checklist">' . $checklist_items . '</div>
      </div>',
    ];

    $build['#attached']['library'][] = 'freyr_performance/freyr_admin';

    return $build;
  }

  /**
   * Clear all caches.
   */
  public function clearCache() {
    drupal_flush_all_caches();
    \Drupal::messenger()->addStatus(t('✅ All Freyr Speed Optimizer caches cleared successfully!'));
    return new RedirectResponse(\Drupal\Core\Url::fromRoute('freyr_performance.dashboard')->toString());
  }

}
