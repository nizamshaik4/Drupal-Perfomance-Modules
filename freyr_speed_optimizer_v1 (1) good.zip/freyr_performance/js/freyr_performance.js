(function ($, Drupal, drupalSettings, once) {
  'use strict';

  var cfg = drupalSettings.freyrPerformance || {};
  if (!cfg.enabled) return;

  Drupal.behaviors.freyrPerformance = {
    attach: function (context, settings) {

      // ── 1. LAZY LOAD IMAGES ─────────────────────────────────────────────
      if (cfg.lazyLoadImages) {
        var imgCount = 0;
        var offset = cfg.lazyOffset || 300;
        var excludePatterns = (cfg.excludeLazyImages || '').split('\n').filter(Boolean);

        // Use IntersectionObserver for best performance
        var imgObserver = 'IntersectionObserver' in window ? new IntersectionObserver(function(entries) {
          entries.forEach(function(entry) {
            if (entry.isIntersecting) {
              var img = entry.target;
              if (img.dataset.src) img.src = img.dataset.src;
              if (img.dataset.srcset) img.srcset = img.dataset.srcset;
              img.classList.add('freyr-loaded');
              imgObserver.unobserve(img);
            }
          });
        }, { rootMargin: offset + 'px 0px' }) : null;

        once('freyr-img', 'img', context).forEach(function(img, index) {
          var $img = $(img);
          imgCount++;

          // Protect hero/first image
          if (cfg.skipFirstImage && imgCount === 1) {
            $img.attr({ fetchpriority: 'high', loading: 'eager', decoding: 'sync' });
            $img.addClass('freyr-loaded');
            return;
          }

          // Check exclusions
          var src = img.src || img.getAttribute('data-src') || '';
          var excluded = excludePatterns.some(function(p) { return p && src.indexOf(p) !== -1; });
          if (excluded) return;

          // Skip logo and tiny images
          if ($img.closest('.logo, .site-logo, .navbar-brand').length) return;
          var w = parseInt($img.attr('width') || '0');
          if (w > 0 && w < 60) return;

          // Skip already processed
          if ($img.attr('loading') === 'lazy') {
            if (imgObserver) imgObserver.observe(img);
            return;
          }

          $img.attr({ loading: 'lazy', decoding: 'async' });
          $img.on('load', function() { $(this).addClass('freyr-loaded'); });
          if (img.complete) $img.addClass('freyr-loaded');
          if (imgObserver) imgObserver.observe(img);
        });
      }

      // ── 2. LAZY LOAD IFRAMES ────────────────────────────────────────────
      if (cfg.lazyLoadIframes) {
        once('freyr-iframe', 'iframe', context).forEach(function(el) {
          if (!el.getAttribute('loading')) {
            el.setAttribute('loading', 'lazy');
          }
        });
      }

      // ── 3. LAZY LOAD VIDEOS ─────────────────────────────────────────────
      if (cfg.lazyLoadVideos) {
        once('freyr-video', 'video', context).forEach(function(el) {
          if (!el.getAttribute('preload')) {
            el.setAttribute('preload', 'none');
          }
        });
      }

      // ── 4. FIX IMAGE DIMENSIONS (CLS) ───────────────────────────────────
      if (cfg.fixImageDimensions) {
        once('freyr-dim', 'img', context).forEach(function(img) {
          function setDims() {
            if (img.naturalWidth > 0) {
              if (!img.getAttribute('width'))  img.setAttribute('width',  img.naturalWidth);
              if (!img.getAttribute('height')) img.setAttribute('height', img.naturalHeight);
              if (!img.style.aspectRatio) {
                img.style.aspectRatio = img.naturalWidth + ' / ' + img.naturalHeight;
              }
            }
          }
          img.complete ? setDims() : img.addEventListener('load', setDims);
        });
      }

      // ── 5. SLICK SLIDER OPTIMIZATION ────────────────────────────────────
      if (cfg.optimizeSlick) {
        var sel = cfg.sliderSelector || '.slick-slider';
        var minH = cfg.sliderMinHeight || '500px';

        once('freyr-slick', sel, context).forEach(function(slider) {
          var $s = $(slider);
          $s.css({ 'min-height': minH, 'contain': 'layout' });

          function optimizeSlides() {
            $s.find('.slick-slide').not('.slick-cloned').each(function(i) {
              var $img = $(this).find('img').first();
              if (!$img.length) return;
              if (i === 0) {
                $img.attr({ fetchpriority: 'high', loading: 'eager', decoding: 'sync' });
                $img.addClass('freyr-loaded');
              } else {
                if (!$img.attr('loading')) {
                  $img.attr({ loading: 'lazy', decoding: 'async' });
                }
              }
            });
          }

          $s.hasClass('slick-initialized') ? optimizeSlides() : $s.on('init', optimizeSlides);

          // Preload next slide
          $s.on('beforeChange', function(e, slick, cur, next) {
            var $nextImg = $(slick.$slides[next]).find('img').first();
            var src = $nextImg.attr('src') || $nextImg.attr('data-lazy') || $nextImg.attr('data-src');
            if (src && !$('link[href="' + src + '"][rel="preload"]').length) {
              $('<link>').attr({ rel: 'preload', as: 'image', href: src }).appendTo('head');
            }
          });

          $s.on('afterChange init', function() {
            setTimeout(function() { $s.css('min-height', ''); }, 400);
          });
        });
      }

      // ── 6. MEGA MENU OPTIMIZATION ────────────────────────────────────────
      if (cfg.optimizeMegaMenu) {
        once('freyr-menu', 'nav, .main-navigation, #block-main-navigation', context).forEach(function(nav) {
          $(nav).find('.menu-item').css('contain', 'layout');
        });
      }

      // ── 7. FONT OPTIMIZATION ─────────────────────────────────────────────
      if (cfg.optimizeFonts) {
        once('freyr-fonts', 'head', context).forEach(function() {
          $('link[href*="fonts.googleapis.com"]').each(function() {
            var href = $(this).attr('href');
            if (href && href.indexOf('display=swap') === -1) {
              $(this).attr('href', href + (href.indexOf('?') !== -1 ? '&' : '?') + 'display=swap');
            }
          });
        });
      }

      // ── 8. INP FIX — Remove 300ms tap delay ─────────────────────────────
      if (cfg.fixInp) {
        once('freyr-inp', 'a, button, [role="button"], input[type="submit"], label', context).forEach(function(el) {
          if (!el.style.touchAction) el.style.touchAction = 'manipulation';
        });
      }

      // ── 9. PREFETCH ON HOVER ─────────────────────────────────────────────
      if (cfg.prefetchOnHover) {
        once('freyr-prefetch', 'nav a[href], header a[href]', context).forEach(function(link) {
          $(link).on('mouseenter', function() {
            var href = $(this).attr('href');
            if (!href || /^(#|javascript:|mailto:|tel:)/.test(href)) return;
            if (/^https?:\/\//.test(href) && href.indexOf(window.location.hostname) === -1) return;
            if ($('link[href="' + href + '"][rel="prefetch"]').length) return;
            $('<link>').attr({ rel: 'prefetch', href: href }).appendTo('head');
          });
        });
      }

      // ── 10. CLS — RESERVE SPACE FOR DYNAMIC BANNERS ─────────────────────
      once('freyr-banner', '[class*="top-bar"],[class*="alert-bar"],[class*="announcement"],[class*="notice-bar"]', context).forEach(function(el) {
        var h = $(el).outerHeight(true);
        if (h > 0) $(el).css({ 'min-height': h + 'px', 'contain': 'layout' });
      });

      // ── 11. CDN URL REPLACEMENT ──────────────────────────────────────────
      if (cfg.cdnUrl) {
        var cdn = cfg.cdnUrl.replace(/\/$/, '');
        var origin = window.location.origin;
        once('freyr-cdn', 'img[src], source[srcset], link[rel="stylesheet"]', context).forEach(function(el) {
          if (el.src && el.src.indexOf(origin) === 0) {
            el.src = cdn + el.src.replace(origin, '');
          }
          if (el.srcset) {
            el.srcset = el.srcset.replace(new RegExp(origin.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), cdn);
          }
        });
      }

      // ── 12. BACKGROUND IMAGE LAZY LOAD ──────────────────────────────────
      if ('IntersectionObserver' in window) {
        once('freyr-bg', '[data-bg]', context).forEach(function(el) {
          var bgObserver = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
              if (entry.isIntersecting) {
                entry.target.style.backgroundImage = 'url(' + entry.target.getAttribute('data-bg') + ')';
                bgObserver.unobserve(entry.target);
              }
            });
          }, { rootMargin: '300px' });
          bgObserver.observe(el);
        });
      }

    }
  };

})(jQuery, Drupal, drupalSettings, once);
