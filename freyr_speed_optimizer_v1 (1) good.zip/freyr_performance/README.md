# Freyr Speed Optimizer
### Professional Performance Module for Drupal 10
**Version 1.0.0 | Target: 90+ PageSpeed on Mobile & Desktop**

---

## 🚀 Features

| Feature | Details |
|---|---|
| Critical CSS | Inlines above-fold CSS to eliminate render-blocking |
| Image Lazy Loading | IntersectionObserver-based with configurable offset |
| Hero Image Preload | fetchpriority=high preload for fastest LCP |
| JS Optimization | Safe defer of analytics scripts only |
| Third-party Delay | GTM/GA/Chat load only after user interaction |
| Slick Slider LCP | First slide eager, others lazy, next slide preloaded |
| Mega Menu Fix | CSS containment for 500+ link menus |
| CLS Fixes | Image dimensions, slider height reservation, banner space |
| INP Fix | touch-action:manipulation removes 300ms tap delay |
| Font Optimization | font-display:swap, preconnect, display=swap |
| CDN Integration | Rewrite asset URLs to CDN |
| DNS Prefetch | Pre-resolve all external domains |
| Prefetch on Hover | Nav links prefetch on hover |
| Video Lazy Load | Video preload=none until visible |
| iframe Lazy Load | YouTube/Maps load on demand |
| Admin Dashboard | Full status overview with test links |
| Score Estimator | Live score estimate as you configure |
| Exclusion Rules | Exclude pages, images, JS, CSS from optimization |
| Custom Code | Inject custom CSS/JS on load or after load |
| Cache Management | One-click clear all caches |

---

## 📦 Installation

1. Upload `freyr_performance` folder to `/modules/custom/`
2. Go to **Admin → Extend**
3. Search "Freyr Speed Optimizer" → Check box → Install
4. Go to **Admin → Configuration → Development → Freyr Speed Optimizer**

---

## ⚙️ Quick Setup (5 minutes)

### Step 1 — Get Hero Image URL
Open your site → F12 → Console → type `allow pasting` → paste:
```javascript
document.querySelector('.slick-slide:not(.slick-cloned) img')?.src
```
Copy the URL shown.

### Step 2 — Configure Module
Go to: Admin → Configuration → Development → Freyr Speed Optimizer → Settings

- Paste Hero Image URL in **LCP tab**
- Enable all checkboxes
- Save configuration

### Step 3 — Drupal Performance
Go to: Admin → Configuration → Performance
- ✅ Aggregate CSS files
- ✅ Aggregate JavaScript files
- Cache max age → 1 week
- Clear all caches

### Step 4 — Cloudflare (Free)
- Sign up at cloudflare.com
- Enable Auto Minify, Brotli, Rocket Loader

### Step 5 — Test
https://pagespeed.web.dev

---

## 📊 Expected Score Improvements

| Fix | Mobile | Desktop |
|---|---|---|
| Hero image preload | +12 pts | +8 pts |
| Third-party delay | +10 pts | +5 pts |
| Critical CSS | +8 pts | +5 pts |
| Lazy loading | +6 pts | +4 pts |
| CLS fixes | +5 pts | +5 pts |
| Fonts | +3 pts | +3 pts |
| INP fix | +3 pts | — |
| Cloudflare | +10 pts | +8 pts |
| **Total** | **+57 pts** | **+38 pts** |

---

## 🔧 Troubleshooting

**Sliders broken after install?**
→ Our JS defer is safe-mode only — it never touches jQuery or Slick.
→ Try: Admin → Configuration → Performance → Clear all caches

**Score didn't improve?**
→ Make sure Drupal CSS/JS Aggregation is ON
→ Make sure Hero Image URL is set correctly
→ Check F12 → Console for red errors

**GTM not loading?**
→ Enter your real GTM-XXXXXX ID in Settings → JavaScript tab
→ Leave blank if not using GTM

---

## 📁 Module Structure

```
freyr_performance/
├── freyr_performance.info.yml
├── freyr_performance.module
├── freyr_performance.routing.yml
├── freyr_performance.links.menu.yml
├── freyr_performance.libraries.yml
├── css/
│   ├── freyr_performance.css  (frontend)
│   └── freyr_admin.css        (admin dashboard)
├── js/
│   ├── freyr_performance.js   (frontend optimizations)
│   └── freyr_admin.js         (admin UI enhancements)
├── src/
│   ├── Controller/
│   │   └── FreyrDashboardController.php
│   └── Form/
│       └── FreyrPerformanceSettingsForm.php
└── config/install/
    └── freyr_performance.settings.yml
```

---

*Built for freyrsolutions.com — Drupal 10 | Version 1.0.0*
