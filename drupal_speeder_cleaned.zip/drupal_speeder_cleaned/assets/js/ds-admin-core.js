/* =============================================================
   Drupal Speeder – Admin Core JS  (rewritten, clean)
   ============================================================= */

var codeEditor = [];
var DS_FORM_SUBMITTING = false; // guard against double-submit

/* ---------------------------------------------------------------
   UTILITY
--------------------------------------------------------------- */
function IsJsonString(str) {
	try { JSON.parse(str); } catch (e) { return false; }
	return true;
}

/* ---------------------------------------------------------------
   TAB SWITCHING  – pure custom, no Bootstrap dependency
--------------------------------------------------------------- */
function dsActivateTab(section) {
	if (!section) return;
	// Hide all panes, show target
	jQuery('.tab-pane').removeClass('active in');
	jQuery('#' + section).addClass('active in');
	// Update sidebar active state
	jQuery('.ds-nav-item').removeClass('active');
	jQuery('.ds-nav-item[data-section="' + section + '"]').addClass('active');
	// Update topbar title
	var label = jQuery('.ds-nav-item[data-section="' + section + '"] .ds-nav-label').text();
	if (label) jQuery('#ds-page-title').text(label);
	// Update URL without page reload
	var url = window.location.href;
	var re  = /([?&])tab=[^&]*/;
	var sep = url.indexOf('?') !== -1 ? '&' : '?';
	var newUrl = url.match(re)
		? url.replace(re, '$1tab=' + section)
		: url + sep + 'tab=' + section;
	history.pushState({}, '', newUrl);
}

/* ---------------------------------------------------------------
   FORM SAVE  – AJAX-based, no header()/redirect conflicts
--------------------------------------------------------------- */
function dsSubmitMainForm() {
	if (DS_FORM_SUBMITTING) return;
	DS_FORM_SUBMITTING = true;

	var $form = jQuery('.main-form');
	if (!$form.length) { DS_FORM_SUBMITTING = false; return; }

	// Encode preload_resources URLs so they survive POST
	$form.find('input[name="preload_resources[]"]').each(function () {
		var v = jQuery(this).val();
		jQuery(this).val(v.replace(/https/g, '####').replace(/http/g, '###'));
	});

	// Show saving indicator
	jQuery('.save-changes-loader').show();
	jQuery('.hook_submit').prop('disabled', true);

	// Collect all form data + flag as AJAX save
	var formData = $form.serialize() + '&_ajax_save=1';

	jQuery.ajax({
		url: $form.attr('action') || window.location.href,
		type: 'POST',
		data: formData,
		dataType: 'json',
		timeout: 30000,
		success: function (resp) {
			if (resp && resp.success) {
				var redirectUrl = resp.redirect || window.location.href.split('?')[0];
				var tabMatch = window.location.href.match(/[?&]tab=([^&]+)/);
				if (tabMatch) {
					var sep = redirectUrl.indexOf('?') !== -1 ? '&' : '?';
					redirectUrl += sep + 'tab=' + tabMatch[1];
				}
				window.location.href = redirectUrl;
			} else {
				dsShowToast('error', (resp && resp.error) ? resp.error : 'Save failed. Please try again.');
				jQuery('.save-changes-loader').hide();
				jQuery('.hook_submit').prop('disabled', false);
				DS_FORM_SUBMITTING = false;
			}
		},
		error: function (xhr) {
			// Server did a real redirect or returned HTML = save likely succeeded
			if (xhr.status === 0 || xhr.status === 200) {
				window.location.reload();
			} else {
				dsShowToast('error', 'Server error (' + xhr.status + '). Please try again.');
				jQuery('.save-changes-loader').hide();
				jQuery('.hook_submit').prop('disabled', false);
				DS_FORM_SUBMITTING = false;
			}
		}
	});
}

/* ---------------------------------------------------------------
   CRITICAL CSS PROGRESS
--------------------------------------------------------------- */
function create_critical_css() {
	jQuery('.critical-progress-bar').addClass('progress-bar-animated progress-bar-striped');
	jQuery.ajax({
		url: adminUrl,
		data: { 'action': 'drupal_speeder_preload_css', 'page': 'admin', 'ver': Math.random() },
		success: function (data) {
			try { data = jQuery.parseJSON(data); } catch(e) { return; }
			if (data[0] === 'success' || (data[0] === 'error' &&
				(data[1] === 'process-already-running' || data[1].indexOf('no stylesheets found') > -1))) {
				var textArea = jQuery('textarea.preload_error_css');
				if (textArea.attr('data-running') !== data[4]) {
					textArea.attr('data-running', data[4]);
					textArea.html('Critical CSS is currently running for ' + data[4]);
				}
				jQuery('.preload_total_css').html(data[2]);
				jQuery('.preload_created_css').html(data[3]);
				var percent = (data[2] > 0 && data[3] > 0)
					? parseFloat(data[3]) / parseFloat(data[2]) * 100 : 1;
				jQuery('.critical-progress-bar').css('width', percent.toFixed(1) + '%');
				jQuery('.critical-progress-bar .progress-percent').html(percent.toFixed(1) + '%');
				jQuery('.percent-number-critical').html(percent.toFixed(1) + '%');
				if (percent.toFixed(1) == 100) jQuery('.critical-percentage').addClass('no-animate');
				if (data[2] > data[3] || data[3] == 0) {
					setTimeout(create_critical_css, 10000);
				} else {
					setTimeout(create_critical_css, 20000);
					jQuery('.critical-css-bar').hide();
					jQuery('.preload_error_css').html('');
					jQuery('.critical-percentage').addClass('no-animate');
				}
			} else {
				setTimeout(create_critical_css, 20000);
				jQuery('#create_critical_css').prop('disabled', true);
				jQuery('.critical-css-bar').hide();
			}
		},
		error: function () {
			jQuery('.critical-progress-bar').addClass('progress-bar-animated progress-bar-striped');
		}
	});
}

/* ---------------------------------------------------------------
   HOOK VALIDATION (before save on Hooks tab)
--------------------------------------------------------------- */
function checkHookData(script) {
	jQuery.ajax({
		url: adminUrl,
		type: 'POST',
		data: {
			'action': 'hookBeforeStartOptimization',
			'script': JSON.stringify(script),
			'_w3nonce': secureKey
		},
		success: function (data) {
			jQuery('.CodeMirror.cm-s-default.CodeMirror-wrap').removeClass('error_textarea');
			if (data.trim().length > 1) {
				var parsed  = jQuery.parseJSON(data);
				var newData = parsed[0];
				var startIndex = data.indexOf('{"error":"') + 10;
				var endIndex   = data.lastIndexOf('"}');
				jQuery('.error-hook-main').show();
				jQuery('.error_hooks').html(data.slice(startIndex, endIndex)).show();
				jQuery(newData).parent('.single-hook')
					.find('.CodeMirror.cm-s-default.CodeMirror-wrap').addClass('error_textarea');
				jQuery('li.w3_hooks a').click();
				jQuery('.save-changes-loader').hide();
				DS_FORM_SUBMITTING = false;
			} else {
				jQuery('.error_hooks').hide();
				dsSubmitMainForm();
			}
		},
		error: function (xhr) {
			jQuery('.CodeMirror.cm-s-default.CodeMirror-wrap').removeClass('error_textarea');
			var text = xhr.responseText ? xhr.responseText.replace(/\\/g, '') : '';
			jQuery('.error-hook-main').show();
			jQuery('.error_hooks').html(text).show();
			jQuery('li.w3_hooks a').click();
			jQuery('.save-changes-loader').hide();
			DS_FORM_SUBMITTING = false;
		}
	});
}

/* ---------------------------------------------------------------
   LOGS: web vitals
--------------------------------------------------------------- */
function w3SpeedsterAjaxLoadLog(limit, issueType, urls, startDate, endDate, deviceType, paged) {
	jQuery('.log-data-table').addClass('loading');
	jQuery.ajax({
		url: adminUrl, method: 'POST',
		data: { action: 'dsGetLogData', getBy: 'ajax', limit: limit,
			issuetype: issueType, url: urls, start_date: startDate,
			end_date: endDate, paged: paged, deviceType: deviceType },
		success: function (data) {
			jQuery('.log-data-table').html(data).removeClass('loading');
		},
		error: function (e) { console.log(e); }
	});
}

function getLogData(page) {
	page = page || '';
	var paged = (page > 0) ? page : (jQuery('.p-num.active').attr('data-page') || 1);
	w3SpeedsterAjaxLoadLog(
		jQuery('.show_log_entry').val(),
		jQuery('.filter_by_issuetype').val(),
		jQuery('#filter_by_url').val(),
		jQuery('.start_date').val(),
		jQuery('.end_date').val(),
		jQuery('.filter_by_deviceType').val(),
		paged
	);
}

/* ---------------------------------------------------------------
   LOGS: change log
--------------------------------------------------------------- */
function w3SpeedsterAjaxLoadChangeLog(limit, startDate, endDate, paged) {
	jQuery('.change-log-data-table').addClass('loading');
	jQuery.ajax({
		url: adminUrl, method: 'POST',
		data: { action: 'dsGetChangeLogData', getBy: 'ajax',
			limit: limit, start_date: startDate, end_date: endDate, paged: paged },
		success: function (data) {
			jQuery('.change-log-data-table').html(data).removeClass('loading');
		},
		error: function (e) { console.log(e); }
	});
}

function getChangeLogData(page) {
	page = page || '';
	var paged = (page > 0) ? page : (jQuery('.change-p-num.active').attr('data-page') || 1);
	w3SpeedsterAjaxLoadChangeLog(
		jQuery('.show_change_log_entry').val(),
		jQuery('.changelog_start_date').val(),
		jQuery('.changelog_end_date').val(),
		paged
	);
}

/* ---------------------------------------------------------------
   CHANGE LOG POPUP
--------------------------------------------------------------- */
function showPopup(content) {
	var popup = jQuery(
		'<div class="change-log-popup">' +
		'<div class="change-log-popup-content">' +
		'<span class="change-log-close-popup">&times;</span>' +
		'<pre>' + content + '</pre>' +
		'</div></div>'
	);
	jQuery('body').append(popup);
	popup.find('.change-log-close-popup').on('click', function () { popup.remove(); });
	jQuery(window).on('click.dspopup', function (e) {
		if (jQuery(e.target).is(popup)) { popup.remove(); jQuery(window).off('click.dspopup'); }
	});
}

/* ---------------------------------------------------------------
   HOOKS SEARCH
--------------------------------------------------------------- */
function get_all_hooks() {
	var items = '';
	jQuery('.single-hook').each(function () {
		var label = jQuery(this).find('span.main-label').html();
		if (!label) return;
		var cls = label.toLowerCase().replace(/\s+/g, '');
		jQuery(this).addClass('filter-' + cls);
		items += '<li><a class="scroll_element_item" data-label="' + label +
			'" data-filter="' + cls + '" href="javascript:void(0);">' + label + '</a></li>';
	});
	jQuery('.entry_search_contaner').html('<ul>' + items + '</ul>');
	jQuery('.all_hooks').removeClass('single_selected');
}

function scrollElem(filter) {
	jQuery('.single-hook').hide();
	jQuery('.single-hook.filter-' + filter).show();
	jQuery('.all_hooks').addClass('single_selected');
	jQuery('.clear_field').show();
	jQuery('.entry_search_contaner').html('');
}

/* ---------------------------------------------------------------
   CDN: get selected types
--------------------------------------------------------------- */
var getAllSelectedTypes = function () {
	var values = [];
	document.querySelectorAll('.w3-cdn input[name$="[type]"]').forEach(function (el) {
		if (el.value) el.value.split(',').forEach(function (v) { if (values.indexOf(v) < 0) values.push(v); });
	});
	return values;
};

var filterCdnOptions = function (input, listId) {
	var filter = input.value.toLowerCase();
	var allSel = getAllSelectedTypes();
	jQuery('#' + listId + ' .dropdown-item').each(function () {
		var show = (jQuery(this).text().toLowerCase().indexOf(filter) > -1 ||
			jQuery(this).hasClass('select-all')) &&
			allSel.indexOf(jQuery(this).data('value')) < 0;
		jQuery(this).toggle(show);
	});
	jQuery('#' + listId).toggle(jQuery('#' + listId + ' .dropdown-item:visible').length > 0);
};

/* ---------------------------------------------------------------
   TOAST
--------------------------------------------------------------- */
function dsShowToast(type, message) {
	var iconMap = { success: 'fa-check-circle', error: 'fa-times-circle',
		danger: 'fa-times-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
	var typeClass = (type === 'danger') ? 'error' : type;
	var container = document.getElementById('ds-toast-container') ||
		document.querySelector('.w3-toast-container');
	if (!container) return;
	var toast = document.createElement('div');
	toast.className = 'ds-toast ds-toast-' + typeClass;
	toast.innerHTML = '<i class="fa ' + (iconMap[type] || 'fa-info-circle') + '"></i><span>' + message + '</span>';
	container.appendChild(toast);
	setTimeout(function () { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 4000);
}

function w3ShowToast(type, message) {
	var container = document.querySelector('.w3-toast-container');
	if (!container) return;
	var toast = document.createElement('div');
	toast.className = 'w3-toast-message w3-toast-' + type;
	toast.innerHTML = '<span>' + message + '</span>' +
		'<button class="w3-toast-close-button" onclick="this.parentElement.remove()">×</button>';
	container.appendChild(toast);
}

/* ===============================================================
   DOM READY
=============================================================== */
jQuery(document).ready(function () {

	/* --- TABS: click handler ----------------------------------- */
	jQuery(document).on('click', '.ds-nav-item[data-section]', function (e) {
		e.preventDefault();
		e.stopPropagation();
		dsActivateTab(jQuery(this).attr('data-section'));
	});

	/* --- TABS: activate from URL on load ---------------------- */
	var urlMatch = window.location.href.match(/[?&]tab=([^&]+)/);
	if (urlMatch && urlMatch[1]) {
		dsActivateTab(urlMatch[1]);
	}

	/* --- COLLAPSIBLE CARDS (data-ds-toggle, NOT data-toggle) -- */
	jQuery(document).on('click', '[data-ds-toggle]', function (e) {
		e.preventDefault();
		var targetId = jQuery(this).attr('data-ds-toggle');
		jQuery('#' + targetId).slideToggle(200);
		jQuery(this).find('.ds-chevron').toggleClass('ds-chevron-up');
	});

	/* --- MOBILE SIDEBAR TOGGLE -------------------------------- */
	var mobileBtn = document.getElementById('ds-mobile-toggle');
	var sidebar   = document.getElementById('ds-sidebar');
	if (mobileBtn && sidebar) {
		mobileBtn.addEventListener('click', function () {
			sidebar.classList.toggle('ds-sidebar-open');
		});
	}

	/* --- SAVE BUTTON (hook_submit) ---------------------------- */
	jQuery(document).on('click', '.hook_submit', function () {
		if (DS_FORM_SUBMITTING) return;
		jQuery('.save-changes-loader').show();

		if (codeEditor.length > 0) {
			var script = [];
			jQuery('.hook_before_start').each(function (i) {
				var val = codeEditor[i] ? codeEditor[i].getValue() : '';
				if (val.length > 1) {
					script.push({ hookKey: '#' + jQuery(this).attr('id'), value: val });
				}
			});
			if (script.length > 0) {
				DS_FORM_SUBMITTING = true;
				checkHookData(script);
				return;
			}
		}
		dsSubmitMainForm();
	});

	/* --- QUICK-CHANGE CHECKBOXES (basic settings) ------------- */
	jQuery('.basic-set-checkbox').on('change', function () {
		var childClass = '.' + jQuery(this).attr('data-class');
		if (jQuery(this).is(':checked')) {
			jQuery(childClass).each(function () { if (!jQuery(this).is(':checked')) jQuery(this).prop('checked', true); });
			if (childClass === '.opt-js') jQuery('.opt-js-select').val('after_page_load');
		} else {
			jQuery(childClass).each(function () { if (jQuery(this).is(':checked')) jQuery(this).prop('checked', false); });
			if (childClass === '.opt-js') jQuery('.opt-js-select').val('on_page_load');
		}
		document.cookie = 'way_to_psi=true; path=/; max-age=86400';
		dsSubmitMainForm();
	});

	/* init: run basic-set-checkbox checks ---------------------- */
	jQuery('.basic-set-checkbox').each(function () {
		var childClass = '.' + jQuery(this).attr('data-class');
		if (jQuery(this).is(':checked')) {
			if (childClass === '.main-opt-img' && parseInt(jQuery('.progress-number').text()) > 0) {
				jQuery('.start_image_optimization').click();
			}
			if (childClass === '.opt-css') {
				jQuery('#create_critical_css').click();
			}
		}
	});

	/* --- CRITICAL CSS ----------------------------------------- */
	jQuery('#create_critical_css').click(function () {
		jQuery(this).prop('disabled', true);
		jQuery('.critical-css-bar').show();
		create_critical_css();
	});

	/* --- PARENT/CHILD FIELD TOGGLES --------------------------- */
	jQuery('.parent-fields').on('change', function () {
		jQuery(this).closest('.css_box').find('.child-fields')
			.toggle(jQuery(this).is(':checked'));
	});

	/* --- IMPORT BUTTON ---------------------------------------- */
	jQuery('#import_button').click(function () {
		var text = jQuery('#import_text').val();
		if (!IsJsonString(text)) {
			alert('Data is corrupted, please check and enter again.');
			return false;
		}
		jQuery('#import_form').submit();
	});

	/* --- IMAGE OPTIMIZATION ----------------------------------- */
	jQuery('button.reset_image_optimization.btn').click(function () {
		if (confirm('Are you sure you want to reset image optimization?')) {
			var url = window.location.href;
			window.location.href = url + (url.indexOf('?') === -1 ? '?' : '&') + 'reset=1';
		}
	});

	jQuery('.add_more_image').click(function () {
		var idx = jQuery(this).parents('#w3_opt_img_content').find('.image_src_field').length;
		jQuery(this).parents('.image_add_more_field').before(
			'<tr class="image_src_field"><td style="width:70%;padding-left:0">' +
			'<input type="text" name="optimiz_images[' + idx + '][src]" placeholder="Image Src"></td>' +
			'<td style="padding-left:0"><input type="text" name="optimiz_images[' + idx + '][width]" placeholder="Width"></td>' +
			'<td class="remove_image_field" style="width:5%;cursor:pointer">X</td></tr>'
		);
	});

	jQuery('.add_more_combine_image').click(function () {
		var idx = jQuery(this).parents('#w3_opt_img_combin_content').find('.image_src_field').length;
		jQuery(this).parents('.image_add_more_field').before(
			'<tr class="image_src_field"><td style="width:70%;padding-left:0">' +
			'<input type="text" name="combine_images[' + idx + '][src]" placeholder="Image Src"></td>' +
			'<td style="padding-left:0"><input type="text" name="combine_images[' + idx + '][position]" placeholder="Position"></td>' +
			'<td class="remove_image_field" style="width:5%;cursor:pointer">X</td></tr>'
		);
	});

	jQuery('table').delegate('.remove_image_field', 'click', function () {
		jQuery(this).parents('.image_src_field').remove();
	});

	/* --- EXPAND TEXTAREA -------------------------------------- */
	jQuery('.expend-textarea').click(function (e) {
		e.preventDefault();
		jQuery('#' + jQuery(this).attr('data-id')).toggleClass('fullscreen');
	});

	/* --- ERROR CLOSE BUTTONS ---------------------------------- */
	jQuery('.error_hooks_close').click(function () {
		jQuery(this).parent('.error-hook-main').hide();
	});
	jQuery('.error_close_btn').click(function () {
		jQuery(this).parent('.error-div-main').hide();
	});

	/* --- CDN ADD ROWS ----------------------------------------- */
	jQuery('.add_more_row').click(function () {
		var name = jQuery(this).attr('data-name');
		var ph   = jQuery(this).attr('data-placeholder');
		jQuery(this).closest('.input_box').find('.single-row').append(
			'<div class="cdn_input_box minus w3d-flex">' +
			'<input placeholder="' + ph + '" type="text" name="' + name + '[]">' +
			'<button type="button" class="w3text-white rem-row w3bg-danger"><i class="fa fa-times"></i></button></div>'
		);
	});
	jQuery('.input_box').on('click', '.rem-row', function () {
		jQuery(this).closest('.cdn_input_box.minus.w3d-flex').remove();
	});

	/* --- HOOKS SEARCH ----------------------------------------- */
	get_all_hooks();

	jQuery('.pl_search_field').on('focus', function () {
		jQuery('.entry_search_contaner').show();
		if (!jQuery(this).val()) get_all_hooks();
	});

	jQuery('.pl_search_field').on('focusout', function () {
		setTimeout(function () { jQuery('.entry_search_contaner').hide(); }, 300);
	});

	jQuery('.pl_search_field').on('keyup', function () {
		var term  = jQuery(this).val();
		var items = '';
		if (term.length > 0) {
			jQuery('.clear_field').show();
			jQuery('.single-hook').each(function () {
				if (jQuery(this).text().toLowerCase().indexOf(term.toLowerCase()) > -1) {
					jQuery(this).show().addClass('active');
					var label = jQuery(this).find('span.main-label').html();
					var cls   = label ? label.toLowerCase().replace(/\s+/g, '') : '';
					items += '<li><a class="scroll_element_item" data-label="' + label +
						'" data-filter="' + cls + '" href="javascript:void(0);">' + label + '</a></li>';
				} else {
					jQuery(this).hide().removeClass('active');
				}
			});
			jQuery('.entry_search_contaner').html('<ul>' + (items || '<li>No matching.</li>') + '</ul>').show();
		} else {
			jQuery('.single-hook').show().removeClass('active');
			get_all_hooks();
			jQuery('.clear_field').hide();
		}
	});

	jQuery('body').delegate('.scroll_element_item', 'click', function () {
		scrollElem(jQuery(this).attr('data-filter'));
		jQuery('.pl_search_field').val(jQuery(this).attr('data-label'));
	});

	jQuery('body').delegate('.used_hook_btn', 'click', function () {
		scrollElem(jQuery(this).attr('data-filter'));
		jQuery('.pl_search_field').val(jQuery(this).attr('data-label'));
	});

	jQuery('button.clear_field').click(function () {
		jQuery('.pl_search_field').val('');
		jQuery(this).hide();
		jQuery('.single-hook').show();
		jQuery('.all_hooks').removeClass('single_selected');
	});

	jQuery('body').click(function (e) {
		if (!jQuery(e.target).closest('.menu-header-search').length) {
			jQuery('.entry_search_container').hide();
		}
	});

	/* --- LOGS ------------------------------------------------- */
	jQuery(document).on('click', '.pagination .p-num', function () {
		jQuery('.p-num').removeClass('active');
		jQuery(this).addClass('active');
		getLogData();
	});
	jQuery(document).on('click', '.pagination .page-next', function () {
		getLogData(parseInt(jQuery(this).attr('data-page')) + 1);
	});
	jQuery(document).on('click', '.pagination .page-next-last', function () {
		getLogData(parseInt(jQuery(this).attr('data-page')));
	});
	jQuery(document).on('click', '.pagination .page-prev', function () {
		var p = Math.max(1, parseInt(jQuery(this).attr('data-page')) - 1);
		getLogData(p);
	});
	jQuery(document).on('click', '.btn-log-refresh, .btn-apply-filter', function () { getLogData(); });
	jQuery('.show_log_entry').on('change', function () { getLogData(); });

	jQuery('.btn-rem-filter').click(function () {
		jQuery('.filter_by_issuetype, .filter_by_deviceType').val('');
		jQuery('#filter_by_url').val('').trigger('change');
		jQuery('.start_date, .end_date, .custom_select_inp').val('');
		jQuery('.url_checkbox').prop('checked', false);
		jQuery('span.select2.select2-container.select2-container--default').hide();
		jQuery('.btn_clear_url_inp').hide();
		w3SpeedsterAjaxLoadLog(jQuery('.show_log_entry').val(), '', '', '', '', '', 1);
	});

	jQuery('.btn-log-delete').on('click', function () {
		jQuery('.log-data-table').addClass('loading');
		jQuery.ajax({
			url: adminUrl, method: 'POST',
			data: { action: 'dsDeleteLogData', time_interval: jQuery('.log_select').val() },
			success: function (d) { jQuery('.log-data-table').html(d).removeClass('loading'); },
			error:   function (e) { console.log(e); }
		});
	});

	jQuery('#enable-webvitals-log, #enable-change-log').on('change', function () {
		dsSubmitMainForm();
	});

	/* datepickers */
	if (jQuery.fn.datepicker) {
		jQuery('.start_date, .end_date').datepicker({ changeMonth: true, changeYear: true, yearRange: '-100:+0' }).show();
		jQuery('.changelog_start_date, .changelog_end_date').datepicker({ changeMonth: true, changeYear: true, yearRange: '-100:+0' }).show();
	}

	jQuery(document).on('click', '.more_info', function () {
		var id   = jQuery(this).attr('data-id');
		var data = jQuery('.data_' + id + ' .log-data').html();
		jQuery('.log-info').html('<li><strong>Data:</strong><code>' + data + '</code></li>');
	});

	/* URL suggestions */
	if (jQuery.fn.select2) {
		jQuery('.url-select-multiple').select2();
		jQuery('span.select2.select2-container.select2-container--default').hide();
	}

	jQuery(document).on('keyup', '.custom_select_inp', function () {
		var text = jQuery(this).val();
		jQuery('.btn_clear_url_inp').toggle(text.length > 0);
		if (text.length > 2) {
			jQuery.ajax({
				url: adminUrl, method: 'POST',
				data: { action: 'w3SpeddsterShowUrlSuggestions', s_text: text },
				success: function (resp) {
					var rd = JSON.parse(resp);
					if (!rd.length) { jQuery('#custom_select_url').html('No URL found').show(); return; }
					var html = '<ul class="option_checkobx">';
					rd.forEach(function (v) {
						var sel = (jQuery('#filter_by_url').val() || []).indexOf(v) > -1 ? 'checked' : '';
						html += '<div class="single-url"><div class="url">' + v + '</div>' +
							'<input type="checkbox" class="url_checkbox" ' + sel + '></div>';
					});
					jQuery('#custom_select_url').html(html + '</ul>').show();
				}
			});
		} else if (text.length === 0) {
			jQuery('#custom_select_url').hide();
		}
	});

	jQuery('.btn_clear_url_inp').on('click', function () {
		jQuery('.custom_select_inp').val('');
		jQuery(this).hide();
	});

	jQuery(document).on('change', '.url_checkbox', function () {
		var url  = jQuery(this).parent('.single-url').find('.url').html();
		var vals = jQuery('#filter_by_url').val() || [];
		if (jQuery(this).is(':checked')) {
			if (vals.indexOf(url) < 0) vals.push(url);
		} else {
			vals = vals.filter(function (v) { return v !== url; });
		}
		jQuery('#filter_by_url').val(vals).trigger('change');
		jQuery('span.select2.select2-container.select2-container--default').toggle(vals.length > 0);
	});

	jQuery('#custom_select_url').on('click', function (e) { e.stopPropagation(); });
	jQuery(document).on('click', function (e) {
		if (!jQuery(e.target).closest('#custom_select_url').length) jQuery('#custom_select_url').hide();
	});

	/* --- CHANGE LOG ------------------------------------------- */
	jQuery(document).on('click', '.pagination .change-p-num', function () {
		jQuery('.change-p-num').removeClass('active');
		jQuery(this).addClass('active');
		getChangeLogData();
	});
	jQuery(document).on('click', '.pagination .change-page-next', function () {
		getChangeLogData(parseInt(jQuery(this).attr('data-page')) + 1);
	});
	jQuery(document).on('click', '.pagination .change-page-next-last', function () {
		getChangeLogData(parseInt(jQuery(this).attr('data-page')));
	});
	jQuery(document).on('click', '.pagination .change-page-prev', function () {
		var p = Math.max(1, parseInt(jQuery(this).attr('data-page')) - 1);
		getChangeLogData(p);
	});
	jQuery('.show_change_log_entry').on('change', function () { getChangeLogData(); });
	jQuery(document).on('click', '.btn-change-log-refresh, .btn-changelog-apply-filter', function () { getChangeLogData(); });
	jQuery('.btn-changelog-rem-filter').click(function () {
		jQuery('.changelog_start_date, .changelog_end_date').val('');
		w3SpeedsterAjaxLoadChangeLog(jQuery('.show_change_log_entry').val(), '', '', 1);
	});
	jQuery('.btn-changelog-delete').on('click', function () {
		jQuery('.change-log-data-table').addClass('loading');
		jQuery.ajax({
			url: adminUrl, method: 'POST',
			data: { action: 'dsDeleteChangeLogData', time_interval: jQuery('#changelog_delete_time').val() },
			success: function (d) { jQuery('.change-log-data-table').html(d).removeClass('loading'); },
			error:   function (e) { console.log(e); }
		});
	});

	jQuery(document).on('click', '.show-more', function () {
		showPopup(jQuery('#' + jQuery(this).data('target')).find('pre').html());
	});
	jQuery(document).on('click', '.show-diff', function () {
		var prev = jQuery('#' + jQuery(this).data('target-old')).find('pre').html();
		var next = jQuery('#' + jQuery(this).data('target-new')).find('pre').html();
		var diff = Diff.diffLines(prev, next);
		var out  = '';
		diff.forEach(function (p) {
			var tag = p.added ? 'ins' : p.removed ? 'del' : 'span';
			out += '<' + tag + '>' + p.value + '</' + tag + '>';
		});
		showPopup(out);
	});

	/* --- PASSWORD TOGGLE -------------------------------------- */
	jQuery('.togglePass').click(function () {
		var $inp = jQuery('#' + jQuery(this).data('password-id'));
		if ($inp.length) {
			if ($inp.attr('type') === 'password') {
				$inp.attr('type', 'text');
				jQuery(this).html("<i class='fa fa-eye-slash'></i>");
			} else {
				$inp.attr('type', 'password');
				jQuery(this).html("<i class='fa fa-eye'></i>");
			}
		}
	});

	/* --- RESTORE ORIGINAL IMAGES ------------------------------ */
	function toggleRestoreButton() {
		jQuery('#restore-original-images').toggle(!jQuery('#remove-original-images').is(':checked'));
	}
	toggleRestoreButton();
	jQuery('#remove-original-images').on('change', toggleRestoreButton);

	jQuery('#restore-original-images').click(function () {
		if (!confirm('Are you sure you want to restore all original images? This action is irreversible.')) return;
		var $btn = jQuery(this).data('original-text', jQuery(this).text()).text('Restoring...').prop('disabled', true);
		(function doRestore() {
			jQuery.ajax({
				url: adminUrl, data: { action: 'ds_restore_original_images' },
				success: function (r) {
					try {
						var res = (typeof r === 'string') ? JSON.parse(r) : r;
						if (res.pending < 1) {
							alert('All Images Restored Successfully.');
							$btn.text($btn.data('original-text')).prop('disabled', false);
						} else { doRestore(); }
					} catch (e) { alert('Unexpected response.'); }
				},
				error: function () {
					alert('Server error. Please try again.');
					$btn.text($btn.data('original-text')).prop('disabled', false);
				}
			});
		})();
	});

	/* init first hook button */
	var $hooks = jQuery('.used_hook_btn');
	if ($hooks.length > 0) $hooks.first().trigger('click');

}); /* end document.ready */

/* ===============================================================
   MULTI CDN (runs after DOM ready, jQuery() shorthand)
=============================================================== */
jQuery(function () {
	var cdnIndex = jQuery('.w3-cdn').length || 0;

	jQuery('.add_more_cdnRows').click(function () {
		var row = '<div class="w3-cdn" data-index="' + cdnIndex + '">' +
			'<div class="w3d-flex gap10">' +
			'<label>CDN url</label>' +
			'<div class="cdn_input_box minus"><button type="button" class="Remove_w3_cdnentries"><i class="fa fa-times"></i></button></div>' +
			'<div class="input_box"><input type="text" name="cdn[' + cdnIndex + '][url]" placeholder="CDN URL"></div>' +
			'</div>' +
			'<div class="w3d-flex gap20"><label>File Types</label>' +
			'<div class="input_box custom-dropdown">' +
			'<input type="hidden" name="cdn[' + cdnIndex + '][type]" id="cdn-type-' + cdnIndex + '" value="">' +
			'<div class="selected-items" id="selected-extensions-' + cdnIndex + '"></div>' +
			'<input type="text" placeholder="Filter extensions" class="dropdown-input" data-list-id="extensions-list-' + cdnIndex + '">' +
			'<div class="dropdown-list" id="extensions-list-' + cdnIndex + '">' +
			'<div class="dropdown-item select-all" data-value="all">Select All</div>' +
			'<div class="dropdown-item" data-value="image">Image</div>' +
			'<div class="dropdown-item" data-value="font">Fonts</div>' +
			'<div class="dropdown-item" data-value="js">JS</div>' +
			'<div class="dropdown-item" data-value="css">CSS</div>' +
			'<div class="dropdown-item" data-value="audio">Audio</div>' +
			'<div class="dropdown-item" data-value="video">Video</div>' +
			'</div></div></div>' +
			'<div class="w3d-flex gap20"><label>Exclude paths from CDN</label>' +
			'<div class="input_box"><input type="text" name="cdn[' + cdnIndex + '][exclude_path]" placeholder="Paths separated by comma"></div>' +
			'</div></div>';
		jQuery('.addmore_button').before(row);
		getAllSelectedTypes().forEach(function (t) {
			jQuery('.w3-cdn:last .dropdown-item[data-value="' + t + '"]').hide();
		});
		cdnIndex++;
	});

	jQuery(document).on('focus input', '.dropdown-input', function () {
		jQuery('#' + jQuery(this).data('list-id')).show();
		filterCdnOptions(this, jQuery(this).data('list-id'));
	});

	jQuery(document).on('click', '.Remove_w3_cdnentries', function () {
		var $row = jQuery(this).closest('.w3-cdn');
		if (jQuery('.w3-cdn').length > 1) {
			$row.remove();
			jQuery('.w3-cdn').each(function (i) {
				jQuery(this).attr('data-index', i).find('input').each(function () {
					var n = jQuery(this).attr('name');
					if (n) jQuery(this).attr('name', n.replace(/cdn\[\d+\]/, 'cdn[' + i + ']'));
				});
			});
		} else {
			$row.find('input').val('');
			$row.find('.selected-items').empty();
			$row.find('.dropdown-item:not(.select-all)').show();
		}
	});

	jQuery(document).on('click', function (e) {
		if (!jQuery(e.target).closest('.custom-dropdown').length) jQuery('.dropdown-list').hide();
	});

	jQuery(document).on('click', '.dropdown-item', function () {
		var $dd   = jQuery(this).closest('.custom-dropdown');
		var $inp  = $dd.find('input[type="hidden"]');
		var $sel  = $dd.find('.selected-items');
		var value = jQuery(this).data('value');

		if (jQuery(this).hasClass('select-all')) {
			$dd.find('.dropdown-item:not(.select-all):visible').each(function () {
				var v = jQuery(this).data('value');
				if (!$sel.find('.selected-item[data-value="' + v + '"]').length) {
					$sel.append('<span class="selected-item" data-value="' + v + '">' + jQuery(this).text() +
						'<button type="button" class="remove-item" data-value="' + v + '">x</button></span>');
					jQuery(this).hide();
				}
			});
			$inp.val($sel.find('.selected-item').map(function () { return jQuery(this).data('value'); }).get().join(','));
		} else if (!$sel.find('.selected-item[data-value="' + value + '"]').length) {
			$sel.append('<span class="selected-item" data-value="' + value + '">' + jQuery(this).text() +
				'<button type="button" class="remove-item" data-value="' + value + '">x</button></span>');
			var cur = $inp.val() ? $inp.val().split(',') : [];
			cur.push(value);
			$inp.val(cur.join(','));
			jQuery(this).hide();
		}
		$dd.find('.dropdown-input').val('');
		$dd.find('.dropdown-list').hide();
	});

	jQuery(document).on('click', '.remove-item', function () {
		var value = jQuery(this).data('value');
		jQuery(this).closest('.selected-item').remove();
		var $dd  = jQuery(this).closest('.custom-dropdown');
		var $inp = $dd.find('input[type="hidden"]');
		$inp.val($inp.val().split(',').filter(function (v) { return v !== value; }).join(','));
		jQuery('.dropdown-item[data-value="' + value + '"]').show();
	});

	// Restore selections on load
	jQuery('.w3-cdn').each(function () {
		var types = jQuery(this).find('input[name$="[type]"]').val();
		if (types) {
			types.split(',').forEach(function (t) {
				jQuery('.dropdown-item[data-value="' + t + '"]').hide();
			});
		}
	});

	if (!jQuery('.w3-cdn').length) jQuery('.add_more_cdnRows').trigger('click');
});
