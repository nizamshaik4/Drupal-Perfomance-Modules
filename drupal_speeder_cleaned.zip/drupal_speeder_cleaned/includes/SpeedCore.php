<?php

namespace DrupalSpeeder;

class SpeedCore
{
    var $addSettings;
    var $settings;
    var $html = "";
    var $statusCode = "";
    var $cdnTypes = ['image', 'css', 'js', 'font', 'audio', 'video'];
    var $htaccessModifyKeys = [];
    public function setAdditionalSettings()
    {
        $this->addSettings['w3_get'] = $_GET;
        $this->addSettings['secure'] = (isset($this->addSettings['siteUrl']) && strpos($this->addSettings['siteUrl'], 'https') !== false) ? 'https://' : (!empty($_SERVER['REQUEST_SCHEME']) ? $_SERVER['REQUEST_SCHEME'] . '://' : 'http://');
        $home_url_arr = $this->w3ParseUrl($this->addSettings['homeUrl']);
        $this->convertCdnStringSettingsToMultiCdn();
        if (!empty($this->settings['cdn']) && is_array($this->settings['cdn'])) {
            foreach ($this->settings['cdn'] as $key => $value) {
                if (!empty($value['type'])) {
                    foreach (explode(',', $value['type']) as $type) {
                        $this->addSettings["{$type}_cdn_url"] = rtrim($value['url'], '/');
                        $this->addSettings["{$type}_exclude_cdn_path"] = $value['exclude_path'];
                    }
                }
            }
        }

        $this->addSettings['mainLicenseKey'] = !empty($this->settings['license_key']) ? $this->settings['license_key'] : 'dsspeed-' . $home_url_arr['host'];
        foreach ($this->cdnTypes as $type) {
            $this->addSettings[$type.'_cdn_url'] = !empty($this->addSettings[$type.'_cdn_url']) ? $this->addSettings[$type.'_cdn_url'] : $this->addSettings['siteUrl'];
            $this->addSettings[$type.'_exclude_cdn_path'] = !empty($this->addSettings[$type.'_exclude_cdn_path']) ? explode(',', str_replace(' ', '', $this->addSettings[$type.'_exclude_cdn_path'])) : [];
            $this->addSettings[$type.'UrlArr'] = $this->w3ParseUrl($this->addSettings[$type.'_cdn_url']);
            if(!empty($this->addSettings[$type.'UrlArr']['path'])){
                $this->addSettings[$type.'UrlArr']['host'] .= rtrim($this->addSettings[$type.'UrlArr']['path'], '/'); 
            }
        }
        $this->addSettings['dsApiUrl'] = !empty($this->settings['dsApiUrl']) ? rtrim($this->settings['dsApiUrl'], '/') : 'https://rest.drupal-speeder.com/optimize';
        $this->addSettings['HTTP_USER_AGENT'] = !empty($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        $this->addSettings['is_mobile'] = $this->is_mobile();
        $this->addSettings['full_url'] = !empty($_SERVER['HTTP_HOST']) ? $this->addSettings['secure'] . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] : $this->addSettings['homeUrl'] . $_SERVER['REQUEST_URI'];
        $full_url_array = explode('?', $this->addSettings['full_url']);
        $this->addSettings['fullUrlWithoutParam'] = $full_url_array[0];
        $this->addSettings['cache_path'] = (!empty($this->settings['cache_path']) ? rtrim($this->settings['cache_path'], '/') : $this->addSettings['content_path'] . '/cache');
        $this->addSettings['rootCachePath'] = $this->addSettings['cache_path'] . '/w3-cache';
        $this->addSettings['criticalCssPath'] = (!empty($this->settings['cache_path']) ? $this->settings['cache_path'] : $this->addSettings['content_path']) . '/critical-css';
        $this->addSettings['cacheUrl'] = str_replace($this->addSettings['documentRoot'], $this->addSettings['siteUrl'], $this->addSettings['rootCachePath']);
        $this->addSettings['uploadPath'] = $this->addSettings['content_path'];
        list($this->addSettings['upload_base_url'], $this->addSettings['upload_base_dir']) = $this->w3GetUploadsBasepath();
        $this->addSettings['webp_path'] = $this->addSettings['uploadPath'] . '/w3-webp';
        $this->addSettings['w3OrgImgPath'] = $this->addSettings['uploadPath'] . '/w3-backup-images';
        $this->addSettings['ds_rand_key'] = $this->w3GetOption('ds_rand_key', 0);
        if (empty($this->addSettings['ds_rand_key'])) {
            $this->w3CreateRandomKey();
            $this->addSettings['ds_rand_key'] = $this->w3GetOption('ds_rand_key', 0);
        }
        $this->addSettings['excludedImg'] = !empty($this->settings['exclude_lazy_load']) ? explode("\r\n", stripslashes($this->settings['exclude_lazy_load'])) : array();
        $this->addSettings['excludedImg'] = array_merge($this->addSettings['excludedImg'], array('about:blank'));
        if (!empty($this->settings['separate_cache_for_mobile']) && $this->addSettings['is_mobile']) {
            $this->addSettings['css_ext'] = 'mob.css';
            $this->addSettings['js_ext'] = 'mob.js';
            $this->addSettings['preload_css'] = !empty($this->settings['preload_css_mobile']) ? explode("\r\n", $this->settings['preload_css_mobile']) : array();
        } else {
            $this->addSettings['css_ext'] = '.css';
            $this->addSettings['js_ext'] = '.js';
            $this->addSettings['preload_css'] = !empty($this->settings['preload_css']) ? explode("\r\n", $this->settings['preload_css']) : array();
        }
        $this->addSettings['preload_css_url'] = [];
        $this->addSettings['headers'] = function_exists('getallheaders') ? getallheaders() : array();
        $this->addSettings['main_css_url'] = [];
        $this->addSettings['lazy_load_js'] = [];
        $this->addSettings['webp_enable'] = [];
        $this->addSettings['webp_enable_instance'] = array($this->addSettings['siteUrl'] . (str_replace($this->addSettings['documentRoot'], "", $this->addSettings['uploadPath'])));
        $this->addSettings['webp_enable_instance_replace'] = array($this->addSettings['siteUrl'] . (str_replace($this->addSettings['documentRoot'], "", $this->addSettings['webp_path'])));
        if (!empty($this->addSettings['isMultisiteSubDomain'])) {
            $this->addSettings['webp_enable_instance'][] = $this->addSettings['network_site_url'] . (str_replace($this->addSettings['documentRoot'], "", $this->addSettings['uploadPath']));
            $this->addSettings['webp_enable_instance_replace'][] = $this->addSettings['network_site_url'] . (str_replace($this->addSettings['documentRoot'], "", $this->addSettings['webp_path']));
        }
        if (!empty($this->settings['webp_jpg'])) {
            $this->addSettings['webp_enable'] = array_merge($this->addSettings['webp_enable'], array('.jpg', '.jpeg'));
        }
        if (!empty($this->settings['webp_png'])) {
            $this->addSettings['webp_enable'] = array_merge($this->addSettings['webp_enable'], array('.png'));
        }
        $this->addSettings['htaccess'] = 0;
        if (file_exists($this->addSettings['documentRoot'] . "/.htaccess")) {
            $htaccess = $this->drupal_speederGetContents($this->addSettings['documentRoot'] . "/.htaccess");
            if (strpos($htaccess, 'W3WEBP') !== false) {
                $this->addSettings['htaccess'] = 1;
            }
        }
        $this->addSettings['critical_css'] = '';
        $this->addSettings['starttime'] = $this->microtime_float();
        $this->addSettings['w3UserLoggedIn'] = $this->w3UserLoggedIn();
        $this->addSettings['fonts_api_links'] = [];
        $this->addSettings['fonts_api_links_css2'] = [];
        $this->addSettings['preload_resources'] = [];
        $this->addSettings['preload_resources']['all'] = [];
        $this->addSettings['js_is_excluded'] = 0;
        $preventHtaccess = 0;
        if (!empty($this->settings['hook_prevent_generation_htaccess'])) {
            $code = str_replace('$preventHtaccess', '$args[0]', $this->settings['hook_prevent_generation_htaccess']);
            $preventHtaccess = $this->hookCallbackFunction($code, $preventHtaccess);
        }

        $this->addSettings['w3-wget'] = (int)$this->w3GetOption('w3-wget');
        $this->addSettings['wptouch'] = false;
        $this->addSettings['blank_image_url'] = $this->createBlankDataImage(16, 9);
        if ($this->isAdmin() && !function_exists('ds_prevent_htaccess_generation') && $preventHtaccess == 0) {
            if (!file_exists($this->addSettings['documentRoot'] . $this->addSettings['webp_path'] . '/.htaccess')) {
                $this->w3CreateFile($this->addSettings['documentRoot'] . $this->addSettings['webp_path'] . '/.htaccess', '<IfModule mod_cgid.c>' . "\n" . 'Options -Indexes' . "\n" . '</IfModule>');
            }
            if (!file_exists($this->addSettings['rootCachePath'] . '/.htaccess')) {
                $this->w3CreateFile($this->addSettings['rootCachePath'] . '/.htaccess', '<IfModule mod_cgid.c>' . "\n" . 'Options -Indexes' . "\n" . '</IfModule>' . "\n" . '<IfModule mod_rewrite.c>' . "\n" . 'RewriteEngine On' . "\n" . 'RewriteCond %{REQUEST_FILENAME} !-f' . "\n" . 'RewriteRule ^(.*)$ ' . str_replace($this->addSettings['documentRoot'], '', DRUPAL_SPEEDER_DIR) . '/check.php?path=%{REQUEST_URI}&url=%{HTTP_REFERER}' . ' [L]' . "\n" . '</IfModule>');
            }
            if (!file_exists($this->addSettings['criticalCssPath'] . '/.htaccess')) {
                $this->w3CreateFile($this->addSettings['criticalCssPath'] . '/.htaccess', '<IfModule mod_cgid.c>' . "\n" . 'Options -Indexes' . "\n" . '</IfModule>');
            }
        }
        $this->addSettings['serverType'] = isset($_SERVER['SERVER_SOFTWARE']) && stripos($_SERVER['SERVER_SOFTWARE'], 'Apache') !== false ? 'apache' : '';
        $this->addSettings['disable_htaccess_webp'] = 0;
        $this->addSettings['advanced_cache_exist'] = 0;
        $this->copyAssets();
        $this->mergeInlineNExternalJavascript();
    }
    function is_mobile()
    {
        $useragent = $this->addSettings['HTTP_USER_AGENT'];
        if (!empty($useragent)) {
            if (preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $useragent) || preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i', substr($useragent, 0, 4))) {
                return 1;
            }
        }
        return 0;
    }

    function w3SpeedsterCreateHTMLCacheFile($html)
    {
        if ($msg = $this->w3NoHtmlCache($html)) {
            $html = preg_replace('/<\!--W3_PAGE_TYPE_[a-z]+-->/i', '', $html);
            return $html . (strlen($msg) > 1 ? $msg : '');
        } else {
            $html = preg_replace('/<\!--W3_PAGE_TYPE_[a-z]+-->/i', '', $html);
        }
        $html = $this->createHtmlfile($html);
        return $html;
    }

    public function get_mobile_browsers()
    {
        $mobile_browsers  = array(
            '\bCrMo\b|CriOS|Android.*Chrome\/[.0-9]*\s(Mobile)?',
            '\bDolfin\b',
            'Opera.*Mini|Opera.*Mobi|Android.*Opera|Mobile.*OPR\/[0-9.]+|Coast\/[0-9.]+',
            'Skyfire',
            'Mobile\sSafari\/[.0-9]*\sEdge',
            'IEMobile|MSIEMobile', // |Trident/[.0-9]+
            'fennec|firefox.*maemo|(Mobile|Tablet).*Firefox|Firefox.*Mobile|FxiOS',
            'bolt',
            'teashark',
            'Blazer',
            'Version.*Mobile.*Safari|Safari.*Mobile|MobileSafari',
            'Tizen',
            'UC.*Browser|UCWEB',
            'baiduboxapp',
            'baidubrowser',
            'DiigoBrowser',
            'Puffin',
            '\bMercury\b',
            'Obigo',
            'NF-Browser',
            'NokiaBrowser|OviBrowser|OneBrowser|TwonkyBeamBrowser|SEMC.*Browser|FlyFlow|Minimo|NetFront|Novarra-Vision|MQQBrowser|MicroMessenger',
            'Android.*PaleMoon|Mobile.*PaleMoon'
        );
        return $mobile_browsers;
    }
    function dsIsMobileDevice($user_agent)
    {
        // Regular expression to identify common mobile user agents
        $pattern = "/(\bCrMo\b|CriOS|Android.*Chrome\/[.0-9]*\s(Mobile)?|\bDolfin\b|Opera.*Mini|Opera.*Mobi|Android.*Opera|Mobile.*OPR\/[0-9.]+|Coast\/[0-9.]+|Skyfire|Mobile\sSafari\/[.0-9]*\sEdge|IEMobile|MSIEMobile|fennec|firefox.*maemo|(Mobile|Tablet).*Firefox|Firefox.*Mobile|FxiOS|bolt|teashark|Blazer|Version.*Mobile.*Safari|Safari.*Mobile|MobileSafari|Tizen|UC.*Browser|UCWEB|baiduboxapp|baidubrowser|DiigoBrowser|Puffin|\bMercury\b|Obigo|NF-Browser|NokiaBrowser|OviBrowser|OneBrowser|TwonkyBeamBrowser|SEMC.*Browser|FlyFlow|Minimo|NetFront|Novarra-Vision|MQQBrowser|MicroMessenger|Android.*PaleMoon|Mobile.*PaleMoon|Android|blackberry|\bBB10\b|rim\stablet\sos|PalmOS|avantgo|blazer|elaine|hiptop|palm|plucker|xiino|Symbian|SymbOS|Series60|Series40|SYB-[0-9]+|\bS60\b|Windows\sCE.*(PPC|Smartphone|Mobile|[0-9]{3}x[0-9]{3})|Window\sMobile|Windows\sPhone\s[0-9.]+|WCE;|Windows\sPhone\s10.0|Windows\sPhone\s8.1|Windows\sPhone\s8.0|Windows\sPhone\sOS|XBLWP7|ZuneWP7|Windows\sNT\s6\.[23]\;\sARM\;|\biPhone.*Mobile|\biPod|\biPad|Apple-iPhone7C2|MeeGo|Maemo|J2ME\/|\bMIDP\b|\bCLDC\b|webOS|hpwOS|\bBada\b|BREW)/i";
        return preg_match($pattern, $user_agent);
    }
    public function w3CheckEnableCdnPath($url, $type = '')
    {
        $enable_cdn = 1;
        if (!empty($this->addSettings["{$type}_exclude_cdn_path"])) {
            foreach ($this->addSettings["{$type}_exclude_cdn_path"] as $path) {
                if (strpos($url, $path) !== false) {
                    $enable_cdn = 0;
                    break;
                }
            }
        }
        return $enable_cdn;
    }
    function w3DeleteHtmlCacheAfterPreloadCss($url)
    {
        if ($path = $this->w3GetHtmlCacheFilePath($url)) {
            $this->w3DeleteFile($path);
        }
    }
    function w3GetCurlErrorMsg($response)
    {
        return $response->get_error_message();
    }
    function w3DeleteServerCache()
    {
        $options = array(
            'url' => $this->addSettings['homeUrl'],
            'key' => $this->getLicenseKey($this->addSettings['homeUrl'])
        );

        $response = $this->w3RemoteGet($this->addSettings['dsApiUrl'] . '/css/delete-css.php', $options);
        if (!empty($response)) {
            return true;
        } else {
            return false;
        }
    }
    function drupal_speederValidateLicenseKey($key = '')
    {
        $key = !empty($this->addSettings['w3_get']['key']) ? $this->addSettings['w3_get']['key'] : $key;
        if (!empty($key)) {
            $options = array(
                'license_id' => $key,
                'domain' => base64_encode($this->addSettings['homeUrl'])
            );

            $response = $this->w3RemoteGet($this->addSettings['dsApiUrl'] . '/get_license_detail.php', $options);
            if (!empty($response)) {
                $res_arr = json_decode($response);
                if ($res_arr[0] == 'success') {
                    return $this->w3JsonEncode(array('success', 'verified', $res_arr[1]));
                } else {
                    return $this->w3JsonEncode(array('fail', 'could not verify-1' . $response));
                }
            } else {
                return $this->w3JsonEncode(array('fail', 'could not verify-3'));
            }
        }
    }
    public function isSpecialContentType()
    {
        if ($this->w3Endswith($this->addSettings['full_url'], '.xml') || $this->w3Endswith($this->addSettings['full_url'], '.xsl')) {
            return true;
        }

        return false;
    }
    function getW3contentsInsertLink($all_links)
    {
        $insertLink = '';
        if (strpos($this->html, '<script>var w3GoogleFont') !== false) {
            $insertLink = '<script>var w3GoogleFont';
        } elseif (!empty($all_links['link'])) {
            foreach ($all_links['link'] as $link) {
                if (strpos($link, 'stylesheet') !== false) {
                    $insertLink = $link;
                    break;
                }
            }
        } else {
            $insertLink = !empty($all_links['script'][0]) ? $all_links['script'][0] : '';
        }
        return $insertLink;
    }
    function w3DebugTime($process)
    {
        if (!empty($this->addSettings['w3_get']['w3_debug'])) {
            $starttime = !empty($this->addSettings['starttime']) ? $this->addSettings['starttime'] : $this->microtime_float();
            $endtime = $this->microtime_float();
            $this->html .= $process . '-' . ($endtime - $starttime) . '-ram-' . (memory_get_usage() / 1024 / 1024) . '-cpu-' . $this->w3JsonEncode(sys_getloadavg()) . "\n";
        }
    }
    function microtime_float()
    {
        list($usec, $sec) = explode(" ", microtime());
        return ((float) $usec + (float) $sec);
    }
    function w3StrReplaceLast($search, $replace, $str)
    {
        if (($pos = strrpos($str, $search)) !== false) {
            $search_length = strlen($search);
            $str = substr_replace($str, $replace, $pos, $search_length);
        }
        return $str;
    }

    function w3CustomParseUrl($src)
    {
        if (!empty($this->addSettings['siteUrlArr']['path'])) {
            if (strpos($src, $this->addSettings['siteUrlArr']['host']) !== false) {
                $src = str_replace($this->addSettings['siteUrlArr']['host'] . $this->addSettings['siteUrlArr']['path'], $this->addSettings['siteUrlArr']['host'], $src);
            } else {
                $src = $this->strReplaceFirst($this->addSettings['siteUrlArr']['path'], '', $src);
            }
        }
        if (substr_count($src, '//') > 0) {
            $src = substr($src, 0, 7) . str_replace('//', '/', substr($src, 7));
        }
        $src_arr = $this->w3ParseUrl($src);
        return $src_arr;
    }
    function strReplaceFirst($search, $replace, $subject)
    {
        $pos = strpos($subject, $search); // Find the position of the first occurrence
        if ($pos !== false) {
            $subject = substr_replace($subject, $replace, $pos, strlen($search));
        }
        return $subject;
    }

    function w3IsExternal($url, $components = [], $type = 'image')
    {
        if (empty($components)) {
            $components = $this->w3ParseUrl($url);
        }
        $siteHost = $this->addSettings['siteUrlArr']['host'] ?? '';
        $cdnHost = $this->addSettings[$type . 'UrlArr']['host'] ?? $siteHost;
        $urlHost = $components['host'] ?? '';
        if (empty($urlHost) || stripos($cdnHost, $urlHost) !== false) {
            return false;
        }
        return true;
    }

    function w3Endswith($string, $test)
    {
        $str_arr = explode('?', $string);
        $string = $str_arr[0];
        $ext = '.' . pathinfo($str_arr[0], PATHINFO_EXTENSION);
        if ($ext == $test)
            return true;
        else
            return false;
    }

    function w3Echo($text)
    {
        if (!empty($this->addSettings['w3_get']['w3_preload_css'])) {
            echo $text;
        }
    }
    function w3PrintR($text)
    {
        if (!empty($this->addSettings['w3_get']['w3_preload_css'])) {
            print_r($text);
        }
    }
    function w3GeneratePreloadCss()
    {
        if (empty($this->settings['optimization_on'])) {
            return;
        }
        if (!empty($this->addSettings['w3_get']['url'])) {
            $key_url = $this->addSettings['w3_get']['url'];
        }
        if (!empty($_REQUEST['page']) && $_REQUEST['page'] == 'admin' && empty($this->w3GetOption('dsHitBulkCriticalCss'))) {
            $this->w3UpdateOption('dsHitBulkCriticalCss',1);
            $this->w3EnqueCriticalUrlsOnServer();
        }
        $preload_css_new = $preload_css = $this->w3GetOption('dsPreloadCss');
        if (!empty($preload_css) && is_array($preload_css) && count($preload_css) > 0) {
            if(count($preload_css) > 2){
                $preload_css_new = $this->w3EnqueCriticalUrlsOnServer($preload_css);
            }
            foreach ($preload_css as $key1 => $url) {
                if (strpos($key1, $this->addSettings['siteUrl']) !== false || (!isset($url[0]) || !isset($url[1]) || !isset($url[2]))) {
                    unset($preload_css_new[$key1]);
                    continue;
                }
                $key = base64_decode($key1);
                if (!empty($key_url) && !empty($preload_css[base64_encode($key_url)])) {
                    $key = $key_url;
                    $url = $preload_css[base64_encode($key_url)];
                    $key_url = '';
                }
                $this->w3Echo('rocket1' . $key . $url[0] . $url[1]);
                if (empty($url[2])) {
                    $this->w3Echo('rocket2-deleted');
                    unset($preload_css_new[$key1]);
                    continue;
                }
                $this->w3UpdateOption('ds_critical_running_url', urldecode($key), 'no', 0);
                $response = $this->w3CreatePreloadCss($key, $url[0], $url[2]);

                if (!empty($response) && $response === "exists") {
                    unset($preload_css_new[$key1]);
                    continue;
                }
                if (!empty($response) && $response === "hold") {
                    $this->w3Echo('rocket5' . $response);
                    break;
                }
                if ($response || $preload_css[$key1][1] == 1) {
                    $this->w3Echo('rocket4' . $response);
                    $total = (int)$this->w3GetOption('ds_preload_css_total', 0) - 1;
                    $this->w3UpdateOption('ds_preload_css_total', $total > 0 ? $total : 0 , 'no', 0);
                    unset($preload_css_new[$key1]);
                } else {
                    $this->w3Echo('rocket6');
                    $preload_css_new[$key1][1] = 1;
                }
                break;
            }
            $this->w3UpdateOption('dsPreloadCss', $preload_css_new, 'no');
            return $response;
        } 
        
    }

    function browsePost()
    {
        $options = array(
            'url' => $this->addSettings['homeUrl']
        );
        $this->w3RemoteGet($this->addSettings['dsApiUrl'] . '/css/browse.php', $options);
    }
    function w3GetHtmlCacheFilePath($url, $mobile = 0)
    {
        if ($path = $this->w3GetHtmlCachePath($url, $mobile)) {
            return $path . "/index.html";
        }
        return false;
    }
    function w3GetHtmlCachePath($url, $mobile = 0)
    {
        $type = "/html";
        $enableCachingGetPara = isset($this->settings['enable_caching_get_para']) ? 1 : 0;
        $parsed_url = $this->w3ParseUrl($url);
        $cachePath = !empty($parsed_url['path']) ? trim($parsed_url['path'], '/') : '';
        $device = '';
        if ($mobile) {
            $device = '/w3mob';
        }
        if (!empty($enableCachingGetPara) && !empty($parsed_url['query'])) {
            $cachePath .= '/' . $parsed_url['query'];
        }
        if (!empty($this->settings['enable_loggedin_user_caching']) && !empty($this->getUserHash())) {
            $type .= '/' . $this->getUserHash();
        }
        $type .= "/" . ($parsed_url['scheme'] === "https" ? "on" : "off") . "-" . $parsed_url['host'];
        $cachePath = $this->getWebCachePath($type, $cachePath);
        $cachePath .= $device;
        if ($cachePath) {
            $cachePath = urldecode($cachePath);
        }
        // for security
        if (preg_match("/\.{2,}/", $cachePath)) {
            $cachePath = false;
        }
        return $cachePath;
    }
    function w3CssCompressInit($minify)
    {
        $minify = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $minify);
        $minify = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), ' ', $minify);
        return $minify;
    }
    function createCssResponseKey($option)
    {
        $key = $this->w3GetOption($option, 0);
        if (empty($key)) {
            $key = $this->w3Rand();
            $this->w3UpdateOption($option, $key);
        }
        return $key;
    }
    function w3CreatePreloadCss($url, $filename, $css_path)
    {
        $this->w3Echo('rocket2' . $filename . $url);
        $this->w3Echo('rocket3' . $css_path);
        if (file_exists($css_path . '/' . $filename)) {
            $this->w3Echo('rocket9');
            return 'exists';
        }
        $nonce = $this->createSecureKey('create_critical_css');
        $csskey = $this->createCssResponseKey('DsCssResponseKey');
        if ($this->checkEnableCdn('css')) {
            $css_urls = $this->addSettings['siteUrl'] . ',' . $this->addSettings['css_cdn_url'];
        } else {
            $css_urls = $this->addSettings['siteUrl'];
        }
        list($preload_total, $preload_created) = $this->w3CriticalCssDetails();
        $responseCssPath = $this->addSettings['criticalCssPath'] . '/responses';
        $this->w3CreateFolder($responseCssPath);
        $responseCssFile = $responseCssPath . '/' . base64_encode($url) . '.json';
        if (file_exists($responseCssFile)) {
            $content = file_get_contents($responseCssFile);
            $contentJson = (array)json_decode($content);
            unlink($responseCssFile);
            if (!empty($contentJson['url']) && !empty($contentJson['w3_css']) && !empty($contentJson['_w3nonce']) && $this->checkSecurityKey('create_critical_css', $contentJson['_w3nonce'])) {
                $this->saveCriticalCss($contentJson['w3_css'], $url, $css_path, $filename);
                return 'exists';
            }
        }
        $options = array(
            'url' => $url,
            'key' => $this->getLicenseKey($url),
            '_w3nonce' => $nonce,
            'filename' => $filename,
            'css_url' => $css_urls,
            'path' => $css_path,
            'response_url' => $this->getCssResponseUrl(),
            'response_path' => $responseCssPath,
            'DsCssResponseKey' => $csskey,
            'auto' => ($preload_created ? $preload_created : 1)
        );
        if (function_exists('dsModifyCriticalCssAPIOptions')) {
            $options = dsModifyCriticalCssAPIOptions($options);
        }
        $this->w3UpdateOption('ds_critical_css_error', '', 'no', 0);
        $response = $this->w3RemoteGet($this->addSettings['dsApiUrl'] . '/css/', $options);
        $this->w3Echo('<pre>');
        $this->w3PrintR($options);
        $this->w3Echo($response);
        if (!empty($response)) {
            $this->w3Echo('rocket3' . $css_path . '/' . $filename);
            $response_arr = (array) json_decode($response);
            if (!empty($response_arr['result']) && $response_arr['result'] == 'success' && !empty($response_arr['w3_css'])) {
                $this->saveCriticalCss($response_arr['w3_css'], $url, $css_path, $filename);
                return 'exists';
            } elseif (!empty($response_arr['error'])) {
                if ($response_arr['error'] == 'process already running') {
                    return 'hold';
                } else {
                    $this->w3Echo('rocket-error' . $response_arr['error']);
                    $this->w3UpdateOption('ds_critical_css_error', $response_arr['error'], 'no', 0);
                    return false;
                }
            }
            $this->w3Echo('rocket7');
            return false;
        } else {
            $this->w3Echo('rocket8');
            return false;
        }
    }
    function saveCriticalCss($w3Css, $url, $css_path, $filename)
    {
        if (function_exists('ds_customize_critical_css')) {
            $w3Css = ds_customize_critical_css($w3Css);
        }
        if (!empty($this->settings['hook_customize_critical_css'])) {
            $code = str_replace(array('$critical_css'), array('$args[0]'), $this->settings['hook_customize_critical_css']);
            $w3Css = $this->hookCallbackFunction($code, $w3Css);
        }
        $this->w3CreateFile($css_path . '/' . $filename, $w3Css);
        $this->w3DeleteHtmlCacheAfterPreloadCss($url);
        return true;
    }
    function w3PutPreloadCss()
    {
        if (!isset($_POST['_w3nonce']) || $this->checkSecurityKey('create_critical_css', $_POST['_w3nonce'])) {
            echo 'Request not valid';
            exit;
        }
        if (!empty($_POST['url']) && !empty($_POST['filename']) && !empty($_POST['w3_css'])) {
            if (!empty($_POST['result']) && $_POST['result'] == 'success') {
                $url = $_POST['url'];
                $w3Css = $_POST['w3_css'];
                $path = $_POST['path'];
                $filename = $_POST['filename'];
                if (function_exists('ds_customize_critical_css')) {
                    $w3Css = ds_customize_critical_css($w3Css);
                }
                if (!empty($this->settings['hook_customize_critical_css'])) {
                    $code = str_replace(array('$critical_css'), array('$args[0]'), $this->settings['hook_customize_critical_css']);
                    $w3Css = $this->hookCallbackFunction($code, $w3Css);
                }
                $this->w3CreateFile($path . '/' . $filename, $w3Css);
                $preload_css = $this->w3GetOption('dsPreloadCss');
                unset($preload_css[base64_encode($url)]);
                $this->w3DeleteHtmlCacheAfterPreloadCss($url);
                echo 'saved';
                exit;
            }
        }
        echo false;
        exit;
    }
    function w3CreateFile($path, $text = '//')
    {
        $path_arr = explode('/', $path);
        $filename = array_pop($path_arr);
        $realpath = urldecode(implode('/', $path_arr));
        if (is_link($realpath) || strpos($realpath, '/./') !== false || strpos($realpath, '/../') !== false) {
            $realpath = realpath($realpath);
        }
        $this->w3CreateFolder($realpath);
        $realFullPath = $realpath . '/' . $filename;
        $file = $this->drupal_speederPutContents($realFullPath, $text);
        if ($file) {
            // @codingStandardsIgnoreLine
            //chmod($realFullPath, 0644);
            return true;
        } else {
            return false;
        }
    }
    function w3ParseScript($tag, $link)
    {
        $data_exists = strpos($link, '>');
        if (!empty($data_exists)) {
            $end_tag_pointer = strpos($link, '</' . $tag . '>', $data_exists);
            $link_arr = substr($link, $data_exists + 1, $end_tag_pointer - $data_exists - 1);
        }
        return $link_arr;
    }
    function w3ParseLink($tag, $link)
    {
        $xmlDoc = new \DOMDocument();
        if (empty($link) || @$xmlDoc->loadHTML($link) === false) {
            return array();
        }
        $tag_html = $xmlDoc->getElementsByTagName($tag);
        $link_arr = array();
        if (!empty($tag_html[0])) {
            foreach ($tag_html[0]->attributes as $attr) {
                $link_arr[$attr->nodeName] = iconv('ISO-8859-1', 'UTF-8', $attr->nodeValue);
            }
        }
        if (strpos($link, '><') === false) {
            $link_arr['html'] = $this->w3ParseScript($tag, $link);
        }
        return $link_arr;
    }

    function w3ImplodeLinkArray($tag, $array)
    {
        if (empty($array)) {
            return '';
        }
        $link = '<' . $tag . ' ';
        $html = '';
        if (!empty($array['html'])) {
            $html = $array['html'];
            unset($array['html']);
        }
        foreach ($array as $key => $arr) {
            if ($key != 'html') {
                $link .= $key . "=\"" . str_replace('"', "'", $arr) . "\" ";
            }
        }
        $link = trim($link);
        if ($tag == 'script') {
            $link .= '>' . $html . '</script>';
        } elseif ($tag == 'iframe') {
            $link .= '>' . $html . '</iframe>';
        } elseif ($tag == 'iframelazy') {
            $link .= '>' . $html . '</iframelazy>';
        } else {
            $link .= '>';
        }
        return $link;
    }

    function w3InsertContentHead($content, $pos, $link = '')
    {
        global $insert_content_head;
        $insert_content_head[] = array($content, $pos, $link);
        if ($pos == 1) {
            $this->html = preg_replace('/<style/', $content . '<style', $this->html, 1, $count);
        } elseif ($pos == 2) {
            if (!empty($link)) {
                $this->html = str_replace($link, $content . $link, $this->html);
            } else {
                $this->html = preg_replace('/(<link.*>)/', $content . "$1", $this->html, 1);
            }
        } elseif ($pos == 3) {
            $this->html = preg_replace('/<head([^<]*)>/', '<head$1>' . $content, $this->html, 1, $count);
            if (empty($count)) {
                $this->html = preg_replace('/<html([^<]*)>/', '<html$1>' . $content, $this->html, 1, $count);
            }
        } elseif ($pos == 4) {
            $this->html = preg_replace('/<\/head(\s*)>/', $content . '</head$1>', $this->html, 1, $count);
            if (empty($count)) {
                $this->html = preg_replace('/<body([^<]*)>/', $content . '<body$1>', $this->html, 1, $count);
            }
        } elseif ($pos == 5) {
            $this->html = preg_replace($content, '', $this->html, 1, $count);
        } elseif ($pos == 6) {
            $this->html = $this->rightReplace($this->html, '<link ', $content . '<link ');
        } else {
            $this->html = preg_replace('/<script/', $content . '<script', $this->html, 1, $count);
        }
    }

    function rightReplace($string, $search, $replace)
    {
        $offset = strrpos($string, $search);
        if ($offset !== false) {
            $length = strlen($search);
            $string = substr_replace($string, $replace, $offset, $length);
        }
        return $string;
    }

    function rightReplaceArray($search, $replace, $subject)
    {
        if (!is_array($search) || !is_array($replace)) {
            return $subject;
        }
        foreach ($search as $key => $searchValue) {
            if (isset($replace[$key])) {
                $replaceValue = $replace[$key];
                $pos = strrpos($subject, $searchValue);
                if ($pos !== false) {
                    $subject = substr_replace($subject, $replaceValue, $pos, strlen($searchValue));
                }
            }
        }
        return $subject;
    }
    function insertString($originalString, $stringToInsert, $position)
    {
        return substr($originalString, 0, $position) . $stringToInsert . substr($originalString, $position);
    }

    function w3StrReplaceSetImg($str, $rep)
    {
        global $str_replace_str_img, $str_replace_rep_img;
        $str_replace_str_img[] = $str;
        $str_replace_rep_img[] = $rep;
    }
    function w3StrReplaceSetJs($str, $rep)
    {
        global $str_replace_str_js, $str_replace_rep_js;
        $str_replace_str_js[] = $str;
        $str_replace_rep_js[] = $rep;
    }

    function w3StrReplaceBulkJson($str = array(), $rep = array())
    {
        if (!empty($rep['php'])) {
            $rep['php'] = '<style>' . $this->drupal_speederGetContents($rep['php']) . '</style>';
        }
        $this->html = str_replace($str, $rep, $this->html);
    }

    function w3StrReplaceSetCss($str, $rep, $key = '')
    {
        global $str_replace_str_css, $str_replace_rep_css;
        if ($key) {
            $str_replace_str_css[$key] = $str;
            $str_replace_rep_css[$key] = $rep;
        } else {
            $str_replace_str_css[] = $str;
            $str_replace_rep_css[] = $rep;
        }
    }

    function w3StrReplaceBulk()
    {
        global $str_replace_str_array, $str_replace_rep_array;
        global $str_replace_str_css, $str_replace_rep_css;
        global $str_replace_str_js, $str_replace_rep_js;
        global $str_replace_str_img, $str_replace_rep_img;
        if (!is_array($str_replace_str_array) && !is_array($str_replace_rep_array)) {
            $str_replace_str_array = array();
            $str_replace_rep_array = array();
        }
        if (!is_array($str_replace_str_css) && !is_array($str_replace_rep_css)) {
            $str_replace_str_css = array();
            $str_replace_rep_css = array();
        }
        if (!is_array($str_replace_str_js) && !is_array($str_replace_rep_js)) {
            $str_replace_str_js = array();
            $str_replace_rep_js = array();
        }
        if (!is_array($str_replace_str_img) && !is_array($str_replace_rep_img)) {
            $str_replace_str_img = array();
            $str_replace_rep_img = array();
        }
        $this->w3DebugTime('start json merge');
        $str_replace_str_array = array_merge($str_replace_str_img, $str_replace_str_css, $str_replace_str_js);
        $str_replace_rep_array = array_merge($str_replace_rep_img, $str_replace_rep_css, $str_replace_rep_js);
        $this->w3DebugTime('end json merge');
        $this->html = str_replace($str_replace_str_array, $str_replace_rep_array, $this->html);
    }
    function w3GetFullUrlCachePath($full_url = '')
    {
        $cache_path = $this->w3CheckFullUrlCachePath($full_url);
        $this->w3CheckNCreateFolder($cache_path);
        return $cache_path;
    }
    function w3GetFullUrlCache($type = 'image')
    {
        $cache_path = str_replace($this->addSettings['documentRoot'], ($this->addSettings[$type.'_cdn_url'] ?? ''), $this->w3CheckFullUrlCachePath());
        return $cache_path;
    }
    function w3CheckFullUrlCachePath($full_url = '')
    {
        $full_url = !empty($full_url) ? $full_url : $this->addSettings['full_url'];
        $url_array = $this->w3ParseUrl($full_url);
        $query = !empty($url_array['query']) ? '/?' . $url_array['query'] : '';
        $path =  !empty($url_array['path']) ? '/?' . $url_array['path'] : '';
        $full_url_arr = explode('/', trim($path, '/') . $query);
        $cache_path = $this->w3GetCachePath('all');
        if (is_array($full_url_arr) && count($full_url_arr) > 0)
            foreach ($full_url_arr as $path) {
                $cache_path .= '/' . md5($path);
            }
        if (!empty($this->settings['separate_cache_for_mobile']) && !empty($this->addSettings['is_mobile'])) {
            $cache_path .= '/mob';
        }
        return $cache_path;
    }
    function w3CreateFolder($path)
    {
        $realpath = urldecode($path);
        if (is_dir($realpath)) {
            return $path;
        }
        try {
            $this->w3Mkdir($realpath, 0755, true);
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }
        return $path;
    }
    function getLicenseKey($url = '')
    {
        $key = $this->addSettings['mainLicenseKey'];
        if (function_exists('dsModifyLicenseKey')) {
            $key = dsModifyLicenseKey($key, $url);
        }
        return $key;
    }
    function optimizeImage($width, $url, $is_webp = false)
    {
        $key = $this->getLicenseKey($url);
        $apiUrl = $this->addSettings['dsApiUrl'] . '/basic1.php';
        $width = $width < 1920 ? $width : 1920;
        $options = array(
            'key' => $key,
            'width' => $width,
            'url' => urlencode($url)
        );
        if ($is_webp) {
            $q = !empty($this->settings['webp_quality']) ? $this->settings['webp_quality'] : '';
            $option = array('webp' => 1, 'q' => $q);
        } else {
            $q = !empty($this->settings['img_quality']) ? $this->settings['img_quality'] : '';
            $option = array('webp' => 1, 'q' => $q);
        }
        $options = array_merge($options, $option);
        return $this->w3RemoteGet($apiUrl, array_merge($options, $option));
    }
    function w3CombineGoogleFonts($full_css_url)
    {
        if (empty($this->settings['google_fonts'])) {
            return false;
        }

        $url_arr = $this->w3ParseUrl(str_replace('#038;', '&', $full_css_url));
        if (strpos($url_arr['path'], 'css2') !== false) {
            $query_arr = explode('&', $url_arr['query']);
            if (!empty($query_arr) && count($query_arr) > 0) {
                foreach ($query_arr as $family) {
                    if (strpos($family, 'family') !== false) {
                        $this->addSettings['fonts_api_links_css2'][] = $family;
                    }
                }
                return true;
            }
            return false;
        } elseif (!empty($url_arr['query'])) {
            parse_str($url_arr['query'], $get_array);
            if (!empty($get_array['family'])) {
                $font_array = explode('|', $get_array['family']);
                foreach ($font_array as $font) {

                    if (!empty($font)) {
                        $font_split = explode(':', $font);

                        if (empty($font_split[0])) {
                            continue;
                        }
                        if (empty($this->addSettings['fonts_api_links'][$font_split[0]]) || !is_array($this->addSettings['fonts_api_links'][$font_split[0]])) {
                            $this->addSettings['fonts_api_links'][$font_split[0]] = array();
                        }
                        $this->addSettings['fonts_api_links'][$font_split[0]] = !empty($font_split[1]) ? array_merge($this->addSettings['fonts_api_links'][$font_split[0]], explode(',', $font_split[1])) : $this->addSettings['fonts_api_links'][$font_split[0]];
                    }
                }
                return true;
            }
            return false;
        }
        return false;
    }
    function w3GetTagsDataHtml($data, $start_tag, $end_tag)
    {
        $data_exists = 0;
        $i = 0;
        $tag_char_len = strlen($start_tag);
        $end_tag_char_len = strlen($end_tag);
        $script_array = array();
        while ($data_exists != -1 && $i < 5000) {
            $data_exists = strpos($data, $start_tag, $data_exists);
            if ($data_exists !== false) {
                $end_tag_pointer = strpos($data, $end_tag, $data_exists);
                $script_array[] = substr($data, $data_exists, $end_tag_pointer - $data_exists + $end_tag_char_len);
                $data_exists = $end_tag_pointer;
            } else {
                $data_exists = -1;
            }
            $i++;
        }
        return $script_array;
    }
    function w3GetTagsData($data, $start_tag, $end_tag,$duplicate='')
    {
        $data_exists = 0;
        $i = 0;
        $end_tag_char_len = strlen($end_tag);
        $script_array = array();
        $duplicate = !empty($duplicate) ? $duplicate : $start_tag;
        $script_array = array();
        while($data_exists != -1 && $i<20000) {
            if($start_tag == '<script'){
                $data1 = strpos($data,$start_tag.' ',$data_exists);
                $data2 = strpos($data,$start_tag.'>',$data_exists);
                if($data1 === false && $data2 !== false){
                    $data_exists = $data2;
                    $duplicate = $start_tag.'>';
                }elseif($data2 === false && $data1 !== false){
                    $data_exists = $data1;
                    $duplicate = $start_tag.' ';
                }elseif( $data1 > $data2){
                    $data_exists = $data2;
                    $duplicate = $start_tag.'>';
                }else{
                    $data_exists = $data1;
                    $duplicate = $start_tag.' ';
                }
            }else{
                $data_exists = strpos($data,$start_tag,$data_exists);
            }
            if(!empty($data_exists)){
                $end_tag_pointer = strpos($data,$end_tag,$data_exists);
                $extractedText = substr($data, $data_exists, $end_tag_pointer-$data_exists+$end_tag_char_len);
                if(($count = substr_count($extractedText,$duplicate)) > 0 && $count != substr_count($extractedText,$end_tag)){
                    $end_tag_pointer = $this->findNthOccurrence($data, $end_tag, $count,$data_exists);
                }
                if(empty($end_tag_pointer)){
                    $end_tag_pointer = strlen($data)-strlen($end_tag);
                }
                $script_array[] = substr($data, $data_exists, $end_tag_pointer-$data_exists+$end_tag_char_len);
                $data_exists = $end_tag_pointer;
            }else{
                $data_exists = -1;
            }
            $i++;
        }
        return $script_array;
    }

    function findNthOccurrence($haystack, $needle, $nth,$data_exists) {
        $pos = $data_exists;
        for ($i = 0; $i < $nth; $i++) {
            $pos = strpos($haystack, $needle, $pos);
            if ($pos === false) {
                return false; // Not found
            }
            $pos++; // Move past the last found position
        }
        //echo '--'."rocketwww".($pos - 1 ?? $data_exists)."<br>";
        return $pos - 1 ?? $data_exists; // Adjust position (since we increment after finding)
    }
    public function w3CacheRmdir($dir)
    {
        if (!is_dir($dir)) {
            return;
        }
        $objects = @scandir($dir);
        if ($objects === false) {
            return;
        }
        foreach ($objects as $object) {
            if ($object === '.' || $object === '..') {
                continue;
            }
            $path = $dir . DIRECTORY_SEPARATOR . $object;
            if (is_dir($path) && $object !== 'critical-css') {
                $this->w3CacheRmdir($path);
            } else {
                $this->w3DeleteFile($path);
            }
        }
        @rmdir($dir);
    }
    function w3Rmfiles($dir)
    {
        if (is_dir($dir)) {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != "." && $object != "..") {
                    if (filetype($dir . "/" . $object) != "dir") {
                        $this->w3DeleteFile($dir . "/" . $object);
                    }
                }
            }
            reset($objects);
        }
    }
    public function w3Rmdir($dir)
    {
        if (is_dir($dir)) {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != "." && $object != "..") {
                    if (filetype($dir . "/" . $object) == "dir") {
                        $this->w3Rmdir($dir . "/" . $object);
                    } else {
                        $this->w3DeleteFile($dir . "/" . $object);
                    }
                }
            }
            reset($objects);
            return rmdir($dir);
        }
    }

    function w3RemoveCacheFilesHourlyEventCallback($path = '')
    {
        if ($path == "html") {
            $cachePath =  $this->addSettings['rootCachePath'] . '/html';
        } else {
            $cachePath =  $this->w3GetCachePath($path);
        }
        $this->w3CreateRandomKey();
        if (function_exists('exec')) {
            exec('rm -r ' . $cachePath, $output, $retval);
        }
        $this->w3CacheRmdir($cachePath);
        return $this->w3CacheSizeCallback();
    }
    function w3RemoveCriticalCssCacheFiles()
    {
        $this->w3UpdateOption('ds_critical_running_url', '', 'no', 0);
        $this->w3UpdateOption('critical_css_delete_time', gmdate('d:m:Y::h:i:sa') . $this->w3JsonEncode($_REQUEST), 'no', 0);
        $this->w3UpdateOption('dsPreloadCss', [], 'no');
        $this->w3UpdateOption('ds_preload_css_total', 0, 'no', 0);
        $this->w3UpdateOption('dsHitBulkCriticalCss',0);
        $this->w3Rmdir($this->addSettings['criticalCssPath']);
        $this->w3DeleteServerCache();
        return true;
    }

    function w3SetAllLinks($data, $resources = array())
    {
        $resource_arr = array();
        $comment_tag = $this->w3GetTagsData($data, '<!--', '-->');
        $new_comment_tag = array();
        foreach ($comment_tag as $key => $comment) {
            if (strpos($comment, '<script>') !== false || strpos($comment, '</script>') !== false || strpos($comment, '<link') !== false) {
                $new_comment_tag[] = $comment;
            }
        }
        $noscript_tag = $this->w3GetTagsData($data, '<noscript', '</noscript>');
        $data = str_replace(array_merge($new_comment_tag, $noscript_tag), '', $data);
        $scripts = $this->w3GetTagsData($data, '<script', '</script>');
        $data = str_replace($scripts, '', $data);

        $data = str_replace($comment_tag, '', $data);
        if (!empty($this->settings['js']) && in_array('script', $resources)) {
            $resource_arr['script'] = $scripts;
        } else {
            $resource_arr['script'] = array();
        }

        if (in_array('picture', $resources)) {
            $resource_arr['picture'] = $this->w3GetTagsData($data, '<picture', '</picture>');
        } else {
            $resource_arr['picture'] = array();
        }
        if (in_array('img', $resources)) {
            $resource_arr['img'] = $this->w3GetTagsData($data, '<img', '>');
        } else {
            $resource_arr['img'] = array();
        }
        if (in_array('svg', $resources)) {
            $resource_arr['svg'] = $this->w3GetTagsData($data, '<svg', '</svg>');
        } else {
            $resource_arr['svg'] = array();
        }
        if (!empty($this->settings['css']) && in_array('link', $resources)) {
            $resource_arr['link'] = $this->w3GetTagsData($data, '<link', '>');
            $resource_arr['style'] = $this->w3GetTagsData($data, '<style', '</style>');
        } else {
            $resource_arr['link'] = array();
            $resource_arr['style'] = array();
        }

        if (in_array('iframe', $resources)) {
            $resource_arr['iframe'] = $this->w3GetTagsData($data, '<iframe', '</iframe>');
        } else {
            $resource_arr['iframe'] = array();
        }
        if (in_array('video', $resources)) {
            $resource_arr['video'] = $this->w3GetTagsData($data, '<video', '</video>');
        } else {
            $resource_arr['video'] = array();
        }
        if (in_array('audio', $resources)) {
            $resource_arr['audio'] = $this->w3GetTagsData($data, '<audio', '</audio>');
        } else {
            $resource_arr['audio'] = array();
        }
        if (in_array('url', $resources)) {
            $resource_arr['url'] = $this->w3GetTagsData($data, 'url(', ')');
        } else {
            $resource_arr['url'] = array();
        }
        return $resource_arr;
    }

    function w3GetCacheFileSize()
    {
        $dir = $this->w3GetCachePath();
        $size = 0;
        foreach (glob(rtrim($dir, '/') . '/*', GLOB_NOSORT) as $each) {
            $size += file_exists($each) ? filesize($each) : $this->w3Foldersize($each);
        }
        return ($size / 1024) / 1024;
    }

    function w3Foldersize($path)
    {
        $total_size = 0;
        if (is_dir($path)) {
            $files = scandir($path);
            $cleanPath = rtrim($path, '/') . '/';
            foreach ($files as $t) {
                if ($t <> "." && $t <> "..") {
                    $currentFile = $cleanPath . $t;
                    if (is_dir($currentFile)) {
                        $size = $this->w3Foldersize($currentFile);
                        $total_size += $size;
                    } else {
                        $size = filesize($currentFile);
                        $total_size += $size;
                    }
                }
            }
        }
        return $total_size;
    }
    function w3CacheSizeCallback()
    {
        $filesize = $this->w3GetCacheFileSize();
        $this->w3UpdateOption('ds_speedup_filesize', $filesize, 'no', 0);
        return $filesize;
    }
    function w3CreateRandomKey()
    {
        $this->w3UpdateOption('ds_rand_key', $this->w3Rand(), 'no', 0);
    }

    function w3PreloadResources()
    {
        $preload_html = '';
        $preload_resources = !empty($this->settings['preload_resources']) ? explode("\r\n", $this->settings['preload_resources']) : array();
        if (!empty($this->addSettings['preload_resources']['all']) && is_array($this->addSettings['preload_resources']['all']) && count($this->addSettings['preload_resources']['all']) > 0) {
            $preload_resources = array_merge($preload_resources, $this->addSettings['preload_resources']['all']);
        }
        if (!empty($this->addSettings['preload_resources']['critical_css'])) {
            $preload_resources = $this->addSettings['preload_resources']['critical_css'] != 1 ? array_merge($preload_resources, array($this->addSettings['preload_resources']['critical_css'])) : $preload_resources;
            $this->addSettings['preload_resources']['css'] = [];
        } elseif (!empty($this->addSettings['preload_resources']['css'])) {
            $preload_resources = array_merge($preload_resources, $this->addSettings['preload_resources']['css']);
        }
        if (!empty($this->addSettings['preload_resources']['preconnect'])) {
            $preloadArr = $this->addSettings['preload_resources']['preconnect'];
            foreach ($preloadArr as $link) {
                $preload_html .= '<link rel="preconnect" href="' . trim($link) . '">';
            }
        }
        if(!empty($this->addSettings['preload_resources']['font'])){
            $preload_resources = array_merge($preload_resources, $this->addSettings['preload_resources']['font']);
        }
        $preload_resources = array_unique($preload_resources);
        if (!empty($preload_resources)) {
            foreach ($preload_resources as $link) {
                $link_arr = explode('?', $link);
                $extension = explode(".", $link_arr[0]);
                $extension = end($extension);
                if (empty($extension)) {
                    continue;
                }
                if (in_array($extension, array('jpeg', 'jpg', 'png', 'gif', 'webp', 'tiff', 'psd', 'raw', 'bmp', 'heif', 'indd'))) {
                    $preload_html .= '<link rel="preload" href="' . trim($link) . '" as="image">';
                }
                if (in_array(strtolower($extension), array('otf', 'ttf', 'woff', 'woff2', 'gtf', 'mmm', 'pea', 'tpf', 'ttc', 'wtf'))) {
                    $preload_html .= '<link rel="preload" href="' . trim($link) . '" as="font" type="font/' . $extension . '" crossorigin>';
                }

                if (in_array($extension, array('mp4', 'webm'))) {
                    $preload_html .= '<link rel="preload" href="' . trim($link) . '" as="video" type="video/' . $extension . '">';
                }
                if ($extension == 'css') {
                    $crossorigin = $this->w3IsExternal($link, [], 'css') ? 'crossorigin' : '';
                    $preload_html .= '<link rel="preload" href="' . trim($link) . '" as="style" ' . $crossorigin . '>';
                }
                if ($extension == 'js') {
                    $crossorigin = $this->w3IsExternal($link, [], 'js') ? 'crossorigin' : '';
                    $preload_html .= '<link rel="preload" href="' . trim($link) . '" as="script" ' . $crossorigin . '>';
                }
            }
        }
        return $preload_html;
    }
    function removeDotPathSegments($path)
    {
        if (strpos($path, '.') === false) {
            return $path;
        }

        $inputBuffer = $path;
        $outputStack = [];

        while ($inputBuffer != '') {
            if (strpos($inputBuffer, "./") === 0) {
                $inputBuffer = substr($inputBuffer, 2);
                continue;
            }
            if (strpos($inputBuffer, "../") === 0) {
                $inputBuffer = substr($inputBuffer, 3);
                continue;
            }

            if ($inputBuffer === "/.") {
                $outputStack[] = '/';
                break;
            }
            if (substr($inputBuffer, 0, 3) === "/./") {
                $inputBuffer = substr($inputBuffer, 2);
                continue;
            }

            if ($inputBuffer === "/..") {
                array_pop($outputStack);
                $outputStack[] = '/';
                break;
            }
            if (substr($inputBuffer, 0, 4) === "/../") {
                array_pop($outputStack);
                $inputBuffer = substr($inputBuffer, 3);
                continue;
            }

            if ($inputBuffer === '.' || $inputBuffer === '..') {
                break;
            }

            if (($slashPos = stripos($inputBuffer, '/', 1)) === false) {
                $outputStack[] = $inputBuffer;
                break;
            } else {
                $outputStack[] = substr($inputBuffer, 0, $slashPos);
                $inputBuffer = substr($inputBuffer, $slashPos);
            }
        }

        return implode($outputStack);
    }
    function checkIgnoreCriticalCss()
    {
        if (isset($this->addSettings['ignoreCriticalCss'])) {
            return $this->addSettings['ignoreCriticalCss'];
        }
        $ignore_critical_css = 0;
        if (!empty($this->addSettings['w3UserLoggedIn']) || $this->is_404()) {
            $ignore_critical_css = 1;
        }
        if (function_exists('ds_no_critical_css')) {
            $ignore_critical_css = ds_no_critical_css($this->addSettings['full_url']);
        }

        if (!empty($this->settings['hook_no_critical_css'])) {
            $url = $this->addSettings['full_url'];
            $code = str_replace(array('$ignore_critical_css', '$url'), array('$args[0]', '$args[1]'), $this->settings['hook_no_critical_css']);
            $ignore_critical_css = $this->hookCallbackFunction($code, $ignore_critical_css, $url);
        }
        $this->addSettings['ignoreCriticalCss'] = $ignore_critical_css;
        return $ignore_critical_css;
    }
    function w3AddPageCriticalCss()
    {
        if ($this->is_404()) {
            return;
        }
        // All pages supported - no license restriction
        if (!empty($this->settings['optimization_on'])) {
            $preload_css = $this->w3GetOption('dsPreloadCss');
            $preload_css = (empty($preload_css) || !is_array($preload_css)) ? array() : $preload_css;
            if (is_array($preload_css) && count($preload_css) > 500) {
                return;
            }
            if (!is_array($preload_css) || (is_array($preload_css) && !array_key_exists(base64_encode($this->addSettings['fullUrlWithoutParam']), $preload_css)) || (!empty($preload_css[$this->addSettings['fullUrlWithoutParam']]) && $preload_css[$this->addSettings['fullUrlWithoutParam']][0] != $this->addSettings['critical_css'])) {
                $preload_css[base64_encode($this->addSettings['fullUrlWithoutParam'])] = array($this->addSettings['critical_css'], 2, $this->w3PreloadCssPath());
                $this->w3UpdateOption('dsPreloadCss', $preload_css, 'no');
                $this->w3UpdateOption('ds_preload_css_total', (int)$this->w3GetOption('ds_preload_css_total', 0) + 1, 'no', 0);
                return serialize($this->w3GetOption('dsPreloadCss'));
            }
        }
    }
    function w3CustomJsEnqueue()
    {
        if (!empty($this->settings['custom_js'])) {
            $custom_js = stripslashes($this->settings['custom_js']);
        } else {
            $custom_js = 'console.log("js loaded");';
        }
        $js_file_name1 = 'custom_js_after_load.js';
        if (!file_exists($this->w3GetCachePath('js') . '/' . $js_file_name1)) {
            $this->w3CreateFile($this->w3GetCachePath('js') . '/' . $js_file_name1, $custom_js);
        }
        $this->html = $this->w3StrReplaceLast('</body>', '<script src="' . $this->w3GetCacheUrl('js') . '/' . $js_file_name1 . '"></script></body>', $this->html);
    }
    function loadStyleTagInHead($style_tags)
    {

        $counter = 0;
        $load_style_tag_in_head_arr = array();
        $load_style_tag_in_head    = !empty($this->settings['load_style_tag_in_head']) ? explode("\r\n", $this->settings['load_style_tag_in_head']) : array();
        foreach ($load_style_tag_in_head as $ex_css) {
            $ex_css_arr = explode(' ', $ex_css);
            $load_style_tag_in_head_arr[$counter][0] = $ex_css_arr[0];
            if (!empty($ex_css_arr[1])) {
                $load_style_tag_in_head_arr[$counter][1] = $ex_css_arr[1];
            }
            $counter++;
        }
        $styleArr = array();
        $styleRep = array();
        $stylesContent = '';

        foreach ($style_tags as $style_tag) {
            $load_in_head = 0;
            $file_name = $this->w3GetOption('ds_rand_key', 0);
            foreach ($load_style_tag_in_head_arr as $ex_css) {
                if (!empty($ex_css[0]) && !empty($style_tag) && strpos($style_tag, $ex_css[0]) !== false) {
                    $styleArr[] = $style_tag;

                    if (!empty($ex_css[1]) && $ex_css[1] === '1') {
                        $file_name = $ex_css[0];
                        $stylesContentFile = $this->w3ParseScript('style', $style_tag);
                        $link = $this->w3LoadStyleInFile($file_name, $stylesContentFile);
                        $styleRep[] = $link;
                    } else {
                        $stylesContent .= $this->w3ParseScript('style', $style_tag);
                        $styleRep[] = '';
                    }
                    break;
                }
            }
        }
        if (count($styleArr) > 0 && count($styleRep) > 0) {
            $this->html = str_replace($styleArr, $styleRep, $this->html);
        }
        if (empty($stylesContent)) {
            return;
        }
        $this->html = str_replace('</head>', '<style>' . $this->w3CssCompressInit($stylesContent) . '</style></head>', $this->html);
    }
    function w3LoadStyleInFile($file_name, $stylesContentFile)
    {
        $file_name_cache = md5($file_name) . '.css';
        if (!file_exists($this->w3CheckFullUrlCachePath() . '/' . $file_name_cache)) {
            $this->w3CreateFile($this->w3CheckFullUrlCachePath() . '/' . $file_name_cache, $this->w3CssCompressInit($stylesContentFile));
        }
        $defer = 'href=';
        if (!$this->checkIgnoreCriticalCss() && !empty($this->settings['load_critical_css']) && !empty($this->addSettings['critical_css']) && file_exists($this->w3PreloadCssPath() . '/' . $this->addSettings['critical_css'])) {
            $defer = 'data-css="1" href=';
        }
        return '<link rel="stylesheet" ' . $defer . '"' . $this->w3GetFullUrlCache('css') . '/' . $file_name_cache . '">';
    }

    function createBlankDataImage($width, $height)
    {

        $image = '%3Csvg%20xmlns=\'http://www.w3.org/2000/svg\'%20width=\'' . $width . '\'%20height=\'' . $height . '\'%3E%3Crect%20width=\'100%25\'%20height=\'100%25\'%20opacity=\'0\'/%3E%3C/svg%3E';
        $dataURI = 'data:image/svg+xml,' . $image;
        return $dataURI;
    }

    function createSVGImageFile($filename, $content)
    {
        $this->w3CreateFile($filename, $content);
    }

    function w3LoadGoogleFonts()
    {
        $google_font = array();
        if (!empty($this->addSettings['fonts_api_links'])) {
            $all_links = '';
            foreach ($this->addSettings['fonts_api_links'] as $key => $links) {
                $all_links .= !empty($links) && is_array($links) ? $key . ':' . implode(',', $links) . '|' : $key . '|';
            }
            $google_font[] = $this->addSettings['secure'] . "fonts.googleapis.com/css?display=swap&family=" . urlencode(trim($all_links, '|'));
        }
        if (!empty($this->addSettings['fonts_api_links_css2'])) {
            $all_links = 'https://fonts.googleapis.com/css2?';
            foreach ($this->addSettings['fonts_api_links_css2'] as $font) {
                $all_links .= $font . '&';
            }
            $all_links .= 'display=swap';
            $google_font[] = $all_links;
        }
        $google_font = $this->localizeGoogleFonts($google_font);
        return '<script>var w3GoogleFont=' . $this->w3JsonEncode($google_font) . ';</script>';
    }

    function localizeGoogleFonts($google_font)
    {
        if (empty($this->settings['localize_google_fonts'])) {
            return $google_font;
        }
        $fontsArr = $google_font;
        $enableCdn = $this->checkEnableCdn('font');
        foreach ($google_font as $key => $font) {
            $cssfileName = md5($font) . '.css';
            $cssfilePath = $this->addSettings['rootCachePath'] . '/fonts/' . $cssfileName;
            $content = file_exists($cssfilePath) && filesize($cssfilePath) > 0 ? $this->drupal_speederGetContents($cssfilePath) : $this->w3RemoteGet($font);
            if (empty($content)) {
                continue;
            }
            $fontUrl = $this->w3GetTagsData($content, 'url(', ')');
            foreach ($fontUrl as $url) {
                if (strpos($url, 'fonts.gstatic.com') !== false) {
                    $sanitizeUrl = str_replace(array('url(', ')', "url('", "')", ')', "'", '"', '&#039;'), '', html_entity_decode($url));
                    if ($fileUrl = $this->localizeGoogleFont($sanitizeUrl)) {
                        $content = str_replace($sanitizeUrl, $fileUrl, $content);
                    }
                }
            }
            $fontsArr[$key] = $this->addSettings['cacheUrl'] . '/fonts/' . $cssfileName;
            if($enableCdn && !$this->w3CheckExcludedPath($fontsArr[$key], $this->addSettings['font_exclude_cdn_path'])){
                $fontsArr[$key] = str_replace($this->addSettings['siteUrlArr']['host'], $this->addSettings['fontUrlArr']['host'], $fontsArr[$key]);
            }
            $this->w3CreateFile($cssfilePath, $content);
        }
        return $fontsArr;
    }

    function localizeGoogleFont($sanitizeUrl)
    {
        $ext = '.' . pathinfo($sanitizeUrl, PATHINFO_EXTENSION);
        $urlArr = $this->w3ParseUrl($sanitizeUrl);
        $fileName = !empty($urlArr['path']) ? $urlArr['path'] : md5($sanitizeUrl) . $ext;
        $filepath = $this->addSettings['rootCachePath'] . '/fonts' . $fileName;
        $fontData = file_exists($filepath) && filesize($filepath) > 0 ? $this->drupal_speederGetContents($filepath) : $this->w3RemoteGet($sanitizeUrl);
        $enableCdn = $this->checkEnableCdn('font');
        if (!empty($fontData)) {
            $this->w3CreateFile($filepath, $fontData);
            $fontUrl = $this->addSettings['cacheUrl'] . '/fonts' . $fileName;
            if($enableCdn && !$this->w3CheckExcludedPath($fontUrl, $this->addSettings['font_exclude_cdn_path'])){
                $fontUrl = str_replace($this->addSettings['siteUrlArr']['host'], $this->addSettings['fontUrlArr']['host'], $fontUrl);
            }
            return $fontUrl;
        }
        return false;
    }
    function lazyLoadIframe($iframe_links)
    {
        if (!empty($this->settings['lazy_load_iframe'])) {
            foreach ($iframe_links as $img) {
                if (strpos($img, '\\') !== false) {
                    continue;
                }
                if ($this->checkImageExcluded($img)) {
                    continue;
                }
                $img_obj = $this->w3ParseLink('iframe', $img);
                $iframe_html = '';
                if (empty($img_obj['src'])) {
                    continue;
                }
                if (strpos($img_obj['src'], 'youtu') !== false) {
                    preg_match("#([\/|\?|&]vi?[\/|=]|youtu\.be\/|embed\/)([a-zA-Z0-9_-]+)#", $img_obj['src'], $matches);
                    if (empty($img_obj['style'])) {
                        $img_obj['style'] = '';
                    }
                    $img_obj['style'] .= 'background-image:url(https://i.ytimg.com/vi/' . trim(end($matches)) . '/sd1.jpg);background-size:contain;';
                }
                $img_obj['data-src'] = $img_obj['src'];
                $img_obj['src'] = 'about:blank';
                $img_obj['data-class'] = 'LazyLoad';

                $iframelazy = 0;
                if (!empty($this->settings['hook_iframe_to_iframelazy'])) {
                    $code = str_replace('$iframelazy', '$args[0]', $this->settings['hook_iframe_to_iframelazy']);
                    $iframelazy = $this->hookCallbackFunction($code, $iframelazy);
                }
                if ((function_exists('ds_change_iframe_to_iframelazy') && ds_change_iframe_to_iframelazy()) || $iframelazy) {
                    $this->w3StrReplaceSetImg($img, $this->w3ImplodeLinkArray('iframelazy', $img_obj) . $iframe_html);
                } else {
                    $this->w3StrReplaceSetImg($img, $this->w3ImplodeLinkArray('iframe', $img_obj) . $iframe_html);
                }
            }
        }
    }
    function lazyLoadVideo($video_links)
    {
        if (!empty($this->settings['lazy_load_video'])) {
            $enableCdn =  $this->checkEnableCdn('video');
            if (strpos($this->addSettings['upload_base_url'], $this->addSettings['siteUrl']) !== false && $enableCdn) {
                $v_src = $this->addSettings['video_cdn_url'] . str_replace($this->addSettings['siteUrl'], '', $this->addSettings['upload_base_url']) . '/blank.mp4';
            } else {
                $v_src = $this->addSettings['upload_base_url'] . '/blank.mp4';
            }
            foreach ($video_links as $video) {
                if (strpos($video, '\\') !== false) {
                    continue;
                }
                if ($this->checkImageExcluded($video)) {
                    continue;
                }
                $video_new = $video;
                if (strpos($video, 'poster=') !== false) {
                    $video_new = str_replace('poster=', 'data-poster=', $video_new);
                }
                $video_new = str_replace('src=', 'src="' . $v_src . '" data-src=', $video_new);
                $video_new = str_replace('<video ', '<video data-class="LazyLoad" ', $video_new);
                $videolazy = 0;
                if (!empty($this->settings['hook_video_to_videolazy'])) {
                    $code = str_replace('$videolazy', '$args[0]', $this->settings['hook_video_to_videolazy']);
                    $videolazy = $this->hookCallbackFunction($code, $videolazy);
                }
                if (function_exists('ds_change_video_to_videolazy') && ds_change_video_to_videolazy() || $videolazy) {
                    $video_new = str_replace(array('<video', '</video>'), array('<videolazy', '</videolazy>'), $video_new);
                }
                $videoObj = $this->w3ParseLink('video', $video);
                if($enableCdn && !empty($videoObj['src']) && !$this->w3CheckExcludedPath($videoObj['src'], $this->addSettings['video_exclude_cdn_path'])){
                    $video_new = str_replace($this->addSettings['siteUrlArr']['host'], $this->addSettings['videoUrlArr']['host'], $video);
                }
                $this->w3StrReplaceSetImg($video, $video_new);
            }
        }
    }
    function lazyLoadAudio($audio_links)
    {
        if (!empty($this->settings['lazy_load_audio'])) {
            $enableCdn =  $this->checkEnableCdn('audio');
            if (strpos($this->addSettings['upload_base_url'], $this->addSettings['siteUrl']) !== false && $enableCdn) {
                $v_src = $this->addSettings['audio_cdn_url'] . str_replace($this->addSettings['siteUrl'], '', $this->addSettings['upload_base_url']) . '/blank.mp3';
            } else {
                $v_src = $this->addSettings['upload_base_url'] . '/blank.mp3';
            }
            foreach ($audio_links as $audio) {
                if (strpos($audio, '\\') !== false) {
                    continue;
                }
                if ($this->checkImageExcluded($audio)) {
                    continue;
                }
                $audioObj = $this->w3ParseLink('audio', $audio);
                if($enableCdn && !empty($audioObj['src']) && !$this->w3CheckExcludedPath($audioObj['src'], $this->addSettings['audio_exclude_cdn_path'])){
                    $audio_new = str_replace($this->addSettings['siteUrlArr']['host'], $this->addSettings['audioUrlArr']['host'], $audio);
                }
                $audio_new = str_replace('src=', 'data-class="LazyLoad" src="' . $v_src . '" data-src=', $audio_new);
                $this->w3StrReplaceSetImg($audio, $audio_new);
            }
        }
    }
    function lazyLoadImg($picture_links, $img_links)
    {
        if (empty($this->settings['lazy_load'])) {
            return;
        }

        if (!empty($picture_links)) {
            foreach ($picture_links as $picture) {
                $pictureNew = $picture;
                if ($this->checkImageExcluded($picture)) {
                    continue;
                }
                $sourceTags = $this->w3GetTagsData($picture, '<source ', '>');
                if (is_array($sourceTags) && count($sourceTags) > 0) {
                    $pictureNew = str_replace('<picture', '<picture data-class=\'LazyLoad\'', $pictureNew);
                    foreach($sourceTags  as $sourceTag){
                        $sourceTagN = str_replace(array(' srcset='), array(' data-srcset='), $sourceTag);
                        $pictureNew = str_replace($sourceTag, $sourceTagN, $pictureNew);
                    }
                    $this->w3StrReplaceSetImg($picture, $pictureNew);
                }
            }
        }
        
        if (!empty($img_links)) {
            $webp_enable = $this->addSettings['webp_enable'];
            $webp_enable_instance = $this->addSettings['webp_enable_instance'];
            $webp_enable_instance_replace = $this->addSettings['webp_enable_instance_replace'];
            foreach ($img_links as $img) {
                $imgnn = $img;
                $imgnn_org_arr = $imgnn_arr = $this->w3ParseLink('img', $imgnn);
                if (empty($imgnn_arr['src'])) {
                    continue;
                }
                if (strpos($imgnn_arr['src'], '\\') !== false || strpos($imgnn_arr['src'], 'data:image') !== false) {
                    continue;
                }
                $components = $this->w3ParseUrl($imgnn_arr['src']);
                if (!$this->w3IsExternal($imgnn_arr['src'], $components)) {
                    $imgnn_arr['src'] = $this->removeQueryParams($imgnn_arr['src'], $components);
                    list($img_root_path, $img_root_url) = $this->getImgRootPath($imgnn_arr['src']);
                    $w3_img_ext = '.' . pathinfo($imgnn_arr['src'], PATHINFO_EXTENSION);
                    $imgsrc_filepath = $this->getResourceRootPath($imgnn_arr['src'], $img_root_url, $img_root_path);
                    $imgnn = trim(preg_replace('/\s+/', ' ', $imgnn));
                    $img_size = $this->w3GetImageSize($img, $imgsrc_filepath);
                    if (!empty($img_size[0]) && !empty($img_size[1])) {
                        $imgnn = $this->getImageAttributes($imgnn, $imgnn_arr, $img_size);
                    }
                    if (!empty($this->addSettings['is_mobile']) && strpos($img, ' srcset=') === false && !empty($this->settings['resp_bg_img'])) {
                        if (!empty($img_size[0]) && $img_size[0] > 600) {
                            [$imgnn_arr, $imgsrc_filepath] = $this->convertToSmallerImage($imgsrc_filepath, $imgnn_arr, $w3_img_ext);
                        }
                    }
                    if (count($webp_enable) > 0 && in_array($w3_img_ext, $webp_enable)) {
                        $imgsrc_webpfilepath = $this->getImgWebpPath($img_root_path, $imgsrc_filepath);
                        if (!empty($this->settings['opt_img_on_the_go']) && !file_exists($imgsrc_webpfilepath) && file_exists($imgsrc_filepath)) {
                            $this->w3IncrementPrioritizedImg($imgsrc_filepath);
                        }
                        if (file_exists($imgsrc_webpfilepath)) {
                            $imgnn_arr['src'] = str_replace($webp_enable_instance, $webp_enable_instance_replace, $imgnn_arr['src']) . 'w3.webp';
                            if (strpos($imgnn, ' srcset=') !== false) {
                                $imgnn_arr['srcset'] = $this->srcsetToWebp($imgnn_arr['srcset'], $img_root_url, $img_root_path);
                            }
                        }
                    }
                }
                if (!empty($imgnn_org_arr['srcset']) && $imgnn_arr['srcset'] != $imgnn_org_arr['srcset']) {
                    $imgnn = str_replace($imgnn_org_arr['srcset'], $imgnn_arr['srcset'], $imgnn);
                }
                if ($imgnn_arr['src'] != $imgnn_org_arr['src']) {
                    $imgnn = str_replace([' src="'.$imgnn_org_arr['src'].'"', " src='".$imgnn_org_arr['src']."'"],[' src="'.$imgnn_arr['src'].'"', " src='".$imgnn_arr['src']."'"], $imgnn);
                }
                if ($this->checkEnableCdn('image') && !$this->w3CheckExcludedPath($imgnn, $this->addSettings['image_exclude_cdn_path'])) {
                    $imgnn = str_replace($this->addSettings['siteUrl'], $this->addSettings['image_cdn_url'], $imgnn);
                }
                if ($this->checkImageExcluded($img, $imgnn_arr)) {
                    $this->addSettings['preload_resources']['all'][] = $imgnn_arr['src'];
                    if (function_exists('ds_customize_image')) {
                        $imgnn = ds_customize_image($imgnn, $img, $imgnn_arr);
                    }
                    if (!empty($this->settings['hook_customize_image'])) {
                        $code = str_replace(array('$imgnn', '$img', '$imgnn_arr'), array('$args[0]', '$args[1]', '$args[2]'), $this->settings['hook_customize_image']);
                        $imgnn = $this->hookCallbackFunction($code, $imgnn, $img, $imgnn_arr);
                    }
                    $imgnn = str_replace('<img ', '<img fetchpriority="high" loading="eager" ', $imgnn);
                    if ($img != $imgnn) {
                        $this->w3StrReplaceSetImg($img, $imgnn);
                    }
                    continue;
                } elseif (!empty($imgnn_arr['fetchpriority']) && $imgnn_arr['fetchpriority'] == 'high') {
                    $imgnn = str_replace(' src=', ' loading="eager" src=', $imgnn);
                } else {
                    $imgnn = str_replace(' src=', ' loading="lazy" src=', $imgnn);
                }
                if (function_exists('ds_customize_image')) {
                    $imgnn = ds_customize_image($imgnn, $img, $imgnn_arr);
                }
                if (!empty($this->settings['hook_customize_image'])) {
                    $code = str_replace(array('$imgnn', '$img', '$imgnn_arr'), array('$args[0]', '$args[1]', '$args[2]'), $this->settings['hook_customize_image']);
                    $imgnn = $this->hookCallbackFunction($code, $imgnn, $img, $imgnn_arr);
                }
                $this->w3StrReplaceSetImg($img, $imgnn);
            }
        }
    }

    function convertToSmallerImage($imgsrc_filepath, $imgnn_arr, $w3_img_ext)
    {
        $imgsrc_filepath_595xh = rtrim(str_replace($w3_img_ext . '$', '-595xh' . $w3_img_ext . '$', $imgsrc_filepath . '$'), '$');
        if (file_exists($imgsrc_filepath_595xh)) {
            $imgsrc_filepath = $imgsrc_filepath_595xh;
            $imgsrc_filepath = str_replace(' ', '%20', $imgsrc_filepath);
            $imgnn_arr['src'] = str_replace($imgnn_arr['src'], $this->getResourceUrl($imgsrc_filepath), $imgnn_arr['src']);
        }
        return [$imgnn_arr, $imgsrc_filepath];
    }
    function srcsetToWebp($srcset, $img_root_url, $img_root_path)
    {
        $urls = $this->parseSrcset($srcset);
        $webpUrls = $this->srcToWebp($urls, $img_root_url, $img_root_path);
        if (count($webpUrls) > 0) {
            $srcset = str_replace($urls, $webpUrls, $srcset);
        }
        return $srcset;
    }

    function srcToWebp($urls, $img_root_url, $img_root_path)
    {
        $webpUrls = [];
        foreach ($urls as $url) {
            $imgsrc_filepath = $this->getResourceRootPath($url, $img_root_url, $img_root_path);
            $imgsrc_webpfilepath = $this->getImgWebpPath($img_root_path, $imgsrc_filepath);
            if (file_exists($imgsrc_webpfilepath)) {
                $webpUrls[] = $this->getResourceUrl($imgsrc_webpfilepath);
            } else {
                $webpUrls[] = $url;
            }
        }
        return $webpUrls;
    }
    function parseSrcset($srcset)
    {
        $entries = explode(',', $srcset);
        $urls = [];

        foreach ($entries as $entry) {
            // Trim spaces and split URL from descriptors
            $parts = preg_split('/\s+/', trim($entry));
            if (count($parts) > 0) {
                $urls[] = $parts[0]; // First part is always the URL
            }
        }

        return $urls;
    }

    function getImgWebpPath($img_root_path, $imgsrc_filepath)
    {
        if (!empty($this->addSettings['uploadPath'])) {
            $imgsrc_webpfilepath = str_replace($this->addSettings['uploadPath'], $this->addSettings['webp_path'], $imgsrc_filepath)  . 'w3.webp';
        } else {
            $imgsrc_webpfilepath = str_replace($img_root_path . $this->addSettings['uploadPath'], $img_root_path . $this->addSettings['webp_path'], $imgsrc_filepath) . 'w3.webp';
        }
        return $imgsrc_webpfilepath;
    }
    function removeQueryParams($url, $components = [])
    {
        $url = urldecode(trim($url));
        if (!empty($components['host']) && $components['host'] != $this->addSettings['siteUrlArr']['host']) {
            $url = $this->addSettings['siteUrl'] . $components['path'];
        }
        if (!empty($this->addSettings['siteUrlArr']['path'])) {
            if (strpos($url, $this->addSettings['siteUrlArr']['host']) === false) {
                if (strpos(substr($url, 0, 1), '/') !== false) {
                    $url = $this->addSettings['homeUrl'] . '/' . ltrim($url, '/');
                } else {
                    $url = $this->addSettings['siteUrl'] . '/' . ltrim($url, '/');
                }
            }
        } elseif (strpos($url, $this->addSettings['siteUrlArr']['host']) === false) {
            $url = $this->addSettings['siteUrl'] . '/' . ltrim($url, '/');
        }
        if (strpos($url, $this->addSettings['image_cdn_url']) !== false) {
            $url = str_replace($this->addSettings['image_cdn_url'], $this->addSettings['siteUrl'], $url);
        }
        $parsedUrl = parse_url($url);
        if (!isset($parsedUrl['scheme']) || !isset($parsedUrl['host'])) {
            return $this->addSettings['siteUrl'] . (isset($parsedUrl['path']) ? $parsedUrl['path'] : '');
        } else {
            return $this->addSettings['siteUrlArr']['scheme'] . '://' . $parsedUrl['host'] . (isset($parsedUrl['path']) ? $parsedUrl['path'] : '');
        }
    }

    function getImageAttributes($imgnn, $imgnn_arr, $img_size)
    {
        if (empty($imgnn_arr['width']) || $imgnn_arr['width'] == 'auto' || $imgnn_arr['width'] == '100%') {
            $imgnn = str_replace(array(' width="auto"', ' src='), array('', ' width="' . $img_size[0] . '" src='), $imgnn);
        }
        if (empty($imgnn_arr['height']) || $imgnn_arr['height'] == 'auto' || $imgnn_arr['height'] == '100%') {
            $imgnn = str_replace(array(' height="auto"', ' src='), array('', ' height="' . $img_size[1] . '" src='), $imgnn);
        }
        return $imgnn;
    }

    function w3debug($text)
    {
        if (!empty($_REQUEST['tester'])) {
            $this->html .= $text;
        }
    }

    function w3GetImageSize($img, $path)
    {
        if (!file_exists($path)) {
            return array('', '');
        }
        $img_size = array();
        $w3_img_ext = '.' . pathinfo($path, PATHINFO_EXTENSION);
        if ($w3_img_ext == '.svg') {
            list($img_size[0], $img_size[1], $alt) = $this->getSvgAttributes($this->drupal_speederGetContents($path));
        } else {
            $img_size = strlen($path) < 4097 && file_exists($path) ? @getimagesize($path) : array();
        }
        return $img_size;
    }

    function getImgRootPath($src)
    {
        if (!empty($this->addSettings['theme_root']) && strpos($src, $this->addSettings['theme_root']) !== false) {
            $img_root_path = rtrim($this->addSettings['theme_base_dir'], '/');
            $img_root_url = rtrim($this->addSettings['theme_base_url'], '/');
        } else {
            $img_root_path = $this->addSettings['upload_base_dir'];
            $img_root_url = $this->addSettings['upload_base_url'];
        }
        return array($img_root_path, $img_root_url);
    }

    function getResourceRootPath($src, $img_root_url, $img_root_path)
    {
        if ($this->addSettings['isMultisiteSubDomain']) {
            $src = str_replace($this->addSettings['siteUrl'], $this->addSettings['network_site_url'], $src);
        }
        if (strpos($src, $img_root_url) !== true) {
            $src = str_replace(array('https;//', 'http://'), $this->addSettings['siteUrlArr']['scheme'] . '://', $src);
        }
        $path = $img_root_path . str_replace($img_root_url, '', $src);
        if (strpos($path, '..') !== false) {
            $path = $this->removeDotPathSegments($path);
        }
        return $path;
    }
    function getResourceUrl($path)
    {
        if ($this->addSettings['isMultisiteSubDomain']) {
            return str_replace($this->addSettings['documentRoot'], $this->addSettings['network_site_url'], $path);
        } else {
            return str_replace($this->addSettings['documentRoot'], $this->addSettings['siteUrl'], $path);
        }
    }
    function getBlankImageUrl($img_size)
    {
        if (!empty($img_size[0]) && !empty($img_size[1])) {
            $blank_image = '/blank-' . (int)$img_size[0] . 'x' . (int)$img_size[1] . '.txt';
            $blank_image_url = $this->createBlankDataImage((int)$img_size[0], (int)$img_size[1]);
        } else {
            $blank_image_url = $this->addSettings['blank_image_url'];
        }
        return $blank_image_url;
    }
    function getSvgXml($data)
    {
        if (strpos($data, '<svg') !== false) {
            return simplexml_load_string($data);
        } elseif (file_exists($data)) {
            return simplexml_load_file($data);
        } else {
            return array();
        }
    }

    function getSvgAttributes($content)
    {
        $svg = $this->getSvgXml(html_entity_decode($content));
        if (!empty($svg['width'])) {
            if (strpos($svg['width'], 'em') !== false) {
                $width = (int)$svg['width'] * 16;
            } elseif (strpos($svg['width'], 'mm') !== false) {
                $width = (int)$svg['width'] * 3.7795275591;
            } else {
                $width = (int)$svg['width'];
            }
        } else {
            $width = '';
        }
        if (!empty($svg['height'])) {
            if (strpos($svg['height'], 'em') !== false) {
                $height = (int)$svg['height'] * 16;
            } else {
                $height = (int)$svg['height'];
            }
        } else {
            $height = '';
        }
        return array($width, $height, $this->getSvgTitle($svg));
    }
    function getSvgTitle($svg)
    {
        return (!empty($svg->title) ? (string)$svg->title : '');
    }
    function checkImageExcluded($img, $imgnn_arr = [])
    {
        $exclude_image = 0;
        if ($this->settings['lazy_load']) {
            foreach ($this->addSettings['excludedImg'] as $ex_img) {
                if (!empty($ex_img) && strpos($img, $ex_img) !== false) {
                    $exclude_image = 1;
                }
            }
            if (!empty($imgnn_arr['data-class']) && strpos($imgnn_arr['data-class'], 'LazyLoad') !== false) {
                $exclude_image = 1;
            }
        } else {
            $exclude_image = 1;
        }

        if (!empty($this->settings['hook_exclude_image_to_lazyload'])) {
            $code = str_replace(array('$exclude_image', '$img', '$imgnn_arr'), array('$args[0]', '$args[1]', '$args[2]'), $this->settings['hook_exclude_image_to_lazyload']);
            $exclude_image = $this->hookCallbackFunction($code, $exclude_image, $img, $imgnn_arr);
        }
        if (function_exists('ds_image_exclude_lazyload')) {
            $exclude_image = ds_image_exclude_lazyload($exclude_image, $img, $imgnn_arr);
        }
        return $exclude_image;
    }
    function convertSVGsToFile($svgs)
    {
        $convertedSvg = [];
        foreach ($svgs as $svg) {
            $path = $this->addSettings['rootCachePath'] . '/images/';
            $filename = md5($svg) . '.svg';
            if (!in_array($filename, $convertedSvg)) {
                $convertedSvg[] = $filename;
            } else {
                continue;
            }
            if ($this->checkImageExcluded($svg)) {
                continue;
            }
            if (!file_exists($path . $filename)) {
                $filePath = $this->createSVGImageFile($path . $filename, $svg);
            }
            if (file_exists($path . $filename)) {
                $newSvgArr = array();
                $newSvg = $svg;
                $newSvgArr['data-src'] = $this->addSettings['cacheUrl'] . '/images/' . $filename;
                list($newSvgArr['width'], $newSvgArr['height'], $newSvgArr['alt']) = $this->getSvgAttributes($svg);
                $newSvgArr['src'] = $this->getBlankImageUrl(array($newSvgArr['width'], $newSvgArr['height']));
                $newSvgArr['data-class'] = 'LazyLoad';
                $this->w3StrReplaceSetImg($svg, $this->w3ImplodeLinkArray('img', $newSvgArr));
            }
        }
    }
    function lazyload($all_links)
    {
        $this->lazyLoadIframe($all_links['iframe']);
        $this->lazyLoadVideo($all_links['video']);
        $this->lazyLoadAudio($all_links['audio']);
        $this->lazyLoadImg($all_links['picture'], $all_links['img']);
        if (!empty($all_links['svg'])) {
            $this->convertSVGsToFile($all_links['svg']);
        }
        $this->html = $this->w3ConvertArrRelativeToAbsolute($this->html, $this->addSettings['fullUrlWithoutParam'] . '/index.php', $all_links['url']);
    }
    function lazyLoadBackgroundImage()
    {
        $elements = array('<div ', '<section ', '<iframelazy ', '<iframe ');
        $Repelements = array('<div data-BgLz=1 ', '<section data-BgLz=1 ', '<iframelazy data-BgLz=1 ', '<iframe data-BgLz=1 ');
        $this->html = str_replace($elements, $Repelements, $this->html);
    }
    function DrupalSpeederCoreWebVitalsScript()
    {
        $script_content = '<script>
			(function () {
				var secureKey = \'' . $this->createSecureKey('cwvLog') . '\';
				var adminAjax = \'' . $this->getAjaxUrl() . '\';
				var device = /Mobi|Android/i.test(navigator.userAgent) ? "Mobile" : "Desktop" ;
				var script = document.createElement(\'script\');
				script.src = \'' . $this->assetUrl('assets/js/web-vitals.iife.js') . '\';
				script.onload = function () {
					webVitals.onCLS(handleVitalsCLS);
					webVitals.onFID(handleVitalsFID);
					webVitals.onLCP(handleVitalsLCP);
					webVitals.onINP(handleVitalsINP);
				};
				document.head.appendChild(script);
			
	
				function handleVitalsFID(metric) {
					console.log(metric);
				   if(metric.rating != \'good\'){
						var metricString = JSON.stringify(metric);
						var metricObject = JSON.parse(metricString);
						var index = 0;
						metric.entries.forEach(() => {
							 metricObject.entries[index].targetElement = metric.entries[index].target.className;
							index++;
						});
						var lastString = JSON.stringify(metricObject);
						w3Ajax(lastString,\'LCP\');
					}
				}
		
				function handleVitalsCLS(metric) {
				   console.log(metric);
				   if(metric.rating != \'good\'){
					var metricString = JSON.stringify(metric);
					var metricObject = JSON.parse(metricString);
					metric.entries.forEach((e,i) => {
						e.sources.forEach((j,k) => {
							metricObject.entries[i].sources[k].targetElement = j.node["className"];
						});
					});
					var lastString = JSON.stringify(metricObject);
					w3Ajax(lastString,\'CLS\');
				  }
				}
		
				function handleVitalsLCP(metric) {
					console.log(metric);
					if(metric.rating != \'good\'){
						var metricString = JSON.stringify(metric); // Serialize the metric object
						var metricObject = JSON.parse(metricString);
						var index = 0;
						metric.entries.forEach(() => {
							 metricObject.entries[index].targetElement = metric.entries[index].element.className;
							index++;
						});
						var lastString = JSON.stringify(metricObject);
						w3Ajax(lastString,\'LCP\');
					}
				} 
				function w3Ajax(lastString, issueType) {
					var xhr = new XMLHttpRequest();
					var url = adminAjax;  // Assuming `adminAjax` is defined elsewhere

					xhr.open(\'POST\', url, true);
					xhr.setRequestHeader(\'Content-Type\', \'application/x-www-form-urlencoded\');

					// Create the data string in the URL-encoded format
					var data = \'action=drupal_speederPutData\' +
								\'&_w3nonce=\'+encodeURIComponent(secureKey) +
							   \'&data=\' + encodeURIComponent(lastString) +
							   \'&url=\' + encodeURIComponent(window.location.href) +
							   \'&issueType=\' + encodeURIComponent(issueType) +
							   \'&deviceType=\' + encodeURIComponent(device); 

					xhr.onreadystatechange = function() {
						if (xhr.readyState === XMLHttpRequest.DONE) {
							if (xhr.status === 200) {
								console.log(\'data inserted\');
							} else {
								console.log(xhr.statusText);
							}
						}
					};

					xhr.onerror = function() {
						console.log(xhr.statusText);
					};

					xhr.send(data);
				}
				function handleVitalsINP(metric) {
					console.log(metric);
					if(metric.rating != \'good\'){
						var metricString = JSON.stringify(metric); 
						var metricObject = JSON.parse(metricString);
						var index = 0;
						metric.entries.forEach(() => {
							 metricObject.entries[index].targetElement = metric.entries[index].target.className;
							index++;
						});
						var lastString = JSON.stringify(metricObject);
						w3Ajax(lastString,\'LCP\');
					}
				}
			})();
		</script>';
        $webVitalspath = $this->w3GetCachePath('all-js') . '/webvital.js';
        if (!is_file($webVitalspath)) {
            $this->w3CreateFile($webVitalspath, $this->w3CompressJs($script_content));
        }
        return $this->drupal_speederGetContents($webVitalspath);
    }
    function w3CriticalCssDetails()
    {
        $preload_total = (int)$this->w3GetOption('ds_preload_css_total', 0);
        $que = count((array)$this->w3GetOption('dsPreloadCss'));
        $preload_created = $preload_total - ($que > 0 ? $que : 0);
        $preload_created = $preload_created < 0 ? 0 : $preload_created;
        return array($preload_total, $preload_created);
    }
    function doCurl($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
        curl_setopt($ch, CURLOPT_COOKIEFILE, $this->addSettings['documentRoot'] . '/tmp/cookies.txt');
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->addSettings['documentRoot'] . '/tmp/cookies.txt');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language: en-US,en;q=0.9',
        ]);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if (curl_errno($ch)) {
            return false;
        } elseif ($httpCode == 200) {
            return $response;
        } else {
            return false;
        }

        curl_close($ch);
    }
    function copyAssets()
    {
        $path = $this->w3GetCachePath();
        $fileArray = ['blank.png', 'blank.mp4', 'blank.mp3'];
        foreach ($fileArray as $value) {
            if (!file_exists($path . '/' . $value)) {
                copy(DRUPAL_SPEEDER_DIR . "assets/images/" . $value, $path . '/' . $value);
            }
        }
    }
    function w3IncrementPrioritizedImg($attach_id = '')
    {
        $opt_priority = $this->w3GetOption('ds_opt_priortize');
        if (empty($opt_priority) || !is_array($opt_priority)) {
            $opt_priority = array();
        }
        if (is_array($opt_priority) && count($opt_priority) > 50) {
            return true;
        }
        if (empty($opt_priority) || !in_array($attach_id, $opt_priority)) {
            $opt_priority[] = $attach_id;
        }
        $this->w3UpdateOption('ds_opt_priortize', $opt_priority, 'no');
        return true;
    }
    function insertCriticalCss()
    {
        $criticalCssInsertion = '';
        $criticalReplace = [];
        if (!$this->checkIgnoreCriticalCss()) {
            if (!empty($this->addSettings['w3_get']['w3_get_css_post_type'])) {
                $this->html .= 'rocket22' . DRUPAL_SPEEDER_VERSION . str_replace($this->addSettings['documentRoot'], '', $this->w3PreloadCssPath()) . '--' . $this->addSettings['critical_css'] . '--' . file_exists($this->w3PreloadCssPath() . '/' . $this->addSettings['critical_css']);
            }
            if (!empty($this->settings['load_critical_css'])) {
                if (!file_exists($this->w3PreloadCssPath() . '/' . $this->addSettings['critical_css']) || filesize($this->w3PreloadCssPath() . '/' . $this->addSettings['critical_css']) < 10) {
                    @unlink($this->w3PreloadCssPath() . '/' . $this->addSettings['critical_css']);
                    $this->w3AddPageCriticalCss();
                } else {
                    $critical_css = $this->drupal_speederGetContents($this->w3PreloadCssPath() . '/' . $this->addSettings['critical_css']);
                    if (!empty($critical_css)) {
                        $criticalCssInsertion = 1;
                        if (function_exists('ds_customize_critical_css')) {
                            $critical_css = ds_customize_critical_css($critical_css);
                        }
                        if (!empty($this->settings['hook_customize_critical_css'])) {
                            $code = str_replace(array('$critical_css'), array('$args[0]'), $this->settings['hook_customize_critical_css']);
                            $critical_css = $this->hookCallbackFunction($code, $critical_css);
                        }
                        if (!empty($this->settings['load_critical_css_style_tag'])) {
                            $criticalReplace[0] = array('data-css="1" ', '{{main_w3_critical_css}}');
                            $criticalReplace[1] = array('data-', '<style id="drupal_speeder-critical-css">' . $critical_css . '</style>');
                            $this->addSettings['preload_resources']['critical_css'] = 1;
                        } else {
                            $enableCdnCss = $this->checkEnableCdn('css');
                            $critical_css_url = str_replace($this->addSettings['documentRoot'], ($enableCdnCss ? $this->addSettings['css_cdn_url'] : $this->addSettings['siteUrl']), $this->w3PreloadCssPath() . '/' . $this->addSettings['critical_css']);
                            $criticalReplace[0] = array('data-css="1" ', '{{main_w3_critical_css}}');
                            $criticalReplace[1] = array('data-', '<link rel="stylesheet" href="' . $critical_css_url . '"/>');
                            $this->addSettings['preload_resources']['critical_css'] = $critical_css_url;
                        }
                    } else {
                        $this->w3AddPageCriticalCss();
                    }
                }
            }
        }
        return array($criticalCssInsertion, $criticalReplace);
    }
    function w3CompressJs($string)
    {
        include_once DRUPAL_SPEEDER_DIR . 'includes/W3jsMin.php';
        $string = \DsJsMin::minify($string);
        return $string;
    }
    function hookCallbackFunction($code, ...$args)
    {
        if (!empty($code)) {
            $code = stripcslashes($code);
            // @codingStandardsIgnoreLine
            eval($code);
            return $args[0];
        }
    }
    function safeEval($code)
    {
        $allowedFunctions = ['strpos', 'str_replace', 'preg_match', 'preg_replace', 'preg_match_all', 'strlen', 'if', 'wp_is_mobile', 'array'];
        $tokens = $this->extractPhpFunctions($code);
        foreach ($tokens as $token) {
            if (!is_numeric($token) && !in_array($token, $allowedFunctions) && strpos(strtolower($token), 'drupal_speeder') === false) {
                $parseErrorData = array('error' => "Use of function '$token' is not allowed.");
                return $parseErrorData;
            }
        }
        // @codingStandardsIgnoreLine
        return eval($code);
    }
    function extractPhpFunctions($code)
    {
        $pattern = '/\b([a-zA-Z_][a-zA-Z0-9_]*)\s*\(/';
        preg_match_all($pattern, $code, $matches);
        return array_unique($matches[1]);
    }

    function getWebCachePath($type, $cachePath)
    {
        if ($this->w3IsPluginActive('gtranslate/gtranslate.php')) {
            if (isset($_SERVER["HTTP_X_GT_LANG"])) {
                $cacheFilePath = $this->addSettings['rootCachePath'] . $type . "/" . $_SERVER["HTTP_X_GT_LANG"] . $cachePath;
            } else if (isset($_SERVER["REDIRECT_URL"]) && $_SERVER["REDIRECT_URL"] != "/index.php") {
                $cacheFilePath = $this->addSettings['rootCachePath'] . $type . "/" . $_SERVER["REDIRECT_URL"];
            } else if (isset($_SERVER["REQUEST_URI"])) {
                $cacheFilePath = $this->addSettings['rootCachePath'] . $type . "/" . $cachePath;
            }
        } else {
            $cacheFilePath = $this->addSettings['rootCachePath'] . $type . "/" . $cachePath;
        }
        return rtrim($cacheFilePath, '/');
    }

    function w3SpeedsterRemoveHtmlCacheCode()
    {
        $htaccessPath = $this->addSettings['documentRoot'] . "/.htaccess";
        $htaccessContent = $this->drupal_speederGetContents($htaccessPath);

        // @codingStandardsIgnoreLine
        if (is_file($this->addSettings['documentRoot'] . "/.htaccess") && is_writable($this->addSettings['documentRoot'] . "/.htaccess") && strpos($htaccessContent, '# BEGIN W3HTMLCACHE') !== false && strpos($htaccessContent, '# END W3HTMLCACHE') !== false) {
            $htaccess = preg_replace("/#\s?BEGIN\s?W3HTMLCACHE.*?#\s?END\s?W3HTMLCACHE\s*/s", "", $htaccessContent);
            $this->drupal_speederPutContents($htaccessPath, $htaccess);
        }
    }

    function w3InsertLbcRule($htaccess)
    {
        $data = "\n" . "# BEGIN W3LBC" . "\n" .
            '<FilesMatch "\.(webm|ogg|mp4|ico|pdf|flv|jpg|jpeg|png|gif|webp|js|css|swf|x-html|css|xml|js|woff|woff2|otf|ttf|svg|eot)(\.gz)?$">' . "\n" .
            '<IfModule mod_expires.c>' . "\n" .
            'AddType application/font-woff2 .woff2' . "\n" .
            'AddType application/x-font-opentype .otf' . "\n" .
            'ExpiresActive On' . "\n" .
            'ExpiresDefault A0' . "\n" .
            'ExpiresByType video/webm A10368000' . "\n" .
            'ExpiresByType video/ogg A10368000' . "\n" .
            'ExpiresByType video/mp4 A10368000' . "\n" .
            'ExpiresByType image/webp A10368000' . "\n" .
            'ExpiresByType image/gif A10368000' . "\n" .
            'ExpiresByType image/png A10368000' . "\n" .
            'ExpiresByType image/jpg A10368000' . "\n" .
            'ExpiresByType image/jpeg A10368000' . "\n" .
            'ExpiresByType image/ico A10368000' . "\n" .
            'ExpiresByType image/svg+xml A10368000' . "\n" .
            'ExpiresByType text/css A10368000' . "\n" .
            'ExpiresByType text/javascript A10368000' . "\n" .
            'ExpiresByType application/javascript A10368000' . "\n" .
            'ExpiresByType application/x-javascript A10368000' . "\n" .
            'ExpiresByType application/font-woff2 A10368000' . "\n" .
            'ExpiresByType application/x-font-opentype A10368000' . "\n" .
            'ExpiresByType application/x-font-truetype A10368000' . "\n" .
            '</IfModule>' . "\n" .
            '<IfModule mod_headers.c>' . "\n" .
            'Header set Expires "max-age=A10368000, public"' . "\n" .
            'Header unset ETag' . "\n" .
            'Header set Connection keep-alive' . "\n" .
            'FileETag None' . "\n" .
            '</IfModule>' . "\n" .
            '</FilesMatch>' . "\n" .
            "# END W3LBC" . "\n";

        $htaccess = preg_replace("/#\s?BEGIN\s?W3LBC.*?#\s?END\s?W3LBC/s", "", $htaccess);
        if (!empty($this->htaccessModifyKeys['lbc'])) {
            if ($this->checkHtaccessStatus($data)) {
                $htaccess = $data . $htaccess;
            } else {
                unset($this->settings['lbc']);
                $this->w3UpdateOption('ds_speedup_option', $this->settings, 'no');
                $this->w3AddError('danger', 'Server error: Unable to apply .htaccess LBC rules to the site.');
            }
        } else {
            $htaccess = $data . $htaccess;
        }
        return $htaccess;
    }

    function w3InsertGzipRule($htaccess)
    {
        $data = "\n" . "# BEGIN W3Gzip" . "\n" .
            "<IfModule mod_deflate.c>" . "\n" .
            "AddType x-font/woff .woff" . "\n" .
            "AddType x-font/ttf .ttf" . "\n" .
            "AddOutputFilterByType DEFLATE image/svg+xml" . "\n" .
            "AddOutputFilterByType DEFLATE text/plain" . "\n" .
            "AddOutputFilterByType DEFLATE text/html" . "\n" .
            "AddOutputFilterByType DEFLATE text/xml" . "\n" .
            "AddOutputFilterByType DEFLATE text/css" . "\n" .
            "AddOutputFilterByType DEFLATE text/javascript" . "\n" .
            "AddOutputFilterByType DEFLATE application/xml" . "\n" .
            "AddOutputFilterByType DEFLATE application/xhtml+xml" . "\n" .
            "AddOutputFilterByType DEFLATE application/rss+xml" . "\n" .
            "AddOutputFilterByType DEFLATE application/javascript" . "\n" .
            "AddOutputFilterByType DEFLATE application/x-javascript" . "\n" .
            "AddOutputFilterByType DEFLATE application/x-font-ttf" . "\n" .
            "AddOutputFilterByType DEFLATE x-font/ttf" . "\n" .
            "AddOutputFilterByType DEFLATE application/vnd.ms-fontobject" . "\n" .
            "AddOutputFilterByType DEFLATE font/opentype font/ttf font/eot font/otf" . "\n" .
            "</IfModule>" . "\n";

        $data = $data . "# END W3Gzip" . "\n";

        $htaccess = preg_replace("/\s*\#\s?BEGIN\s?W3Gzip.*?#\s?END\s?W3Gzip\s*/s", "", $htaccess);
        if (!empty($this->htaccessModifyKeys['gzip'])) {
            if ($this->checkHtaccessStatus($data)) {
                $htaccess = $data . $htaccess;
            } else {
                unset($this->settings['gzip']);
                $this->w3UpdateOption('ds_speedup_option', $this->settings, 'no');
                $this->w3AddError('danger', 'Server error: Unable to apply .htaccess Gzip rules to the site.');
            }
        } else {
            $htaccess = $data . $htaccess;
        }
        return $htaccess;
    }

    function w3Insert_404RedirectToFile($htaccess)
    {
        $data = "\n" . "# BEGIN W3404" . "\n" .
            "<IfModule mod_rewrite.c>" . "\n" .
            "RewriteEngine On" . "\n" .
            "RewriteBase /" . "\n" .
            "RewriteCond %{REQUEST_FILENAME} !-f" . "\n" .
            "RewriteRule (.*)/w3-cache/(css|js)/(\d)*(.*)[mob]*\.(css|js) $4.$5 [L]" . "\n" .
            "</IfModule>" . "\n";
        $data = $data . "# END W3404" . "\n";
        $htaccess = preg_replace("/\s*\#\s?BEGIN\s?W3404.*?#\s?END\s?W3404\s*/s", "", $htaccess);
        if(method_exists($this, 'checkHtaccess404Position')){
            return $this->checkHtaccess404Position($data, $htaccess);
        }
        return $data . $htaccess;
    }

    function w3InsertRewriteRule($htaccess)
    {
        if (!empty($this->settings['html_cache'])) {
            $htaccess = preg_replace("/#\s?BEGIN\s?W3Cache.*?#\s?END\s?W3Cache/s", "", $htaccess);
            $htaccess = $this->w3GetHtaccess() . $htaccess;
        } else {
            $htaccess = preg_replace("/#\s?BEGIN\s?W3Cache.*?#\s?END\s?W3Cache/s", "", $htaccess);
            $this->deleteCache();
        }
        return $htaccess;
    }

    public function get_operating_systems()
    {
        $operating_systems  = array(
            'Android',
            'blackberry|\bBB10\b|rim\stablet\sos',
            'PalmOS|avantgo|blazer|elaine|hiptop|palm|plucker|xiino',
            'Symbian|SymbOS|Series60|Series40|SYB-[0-9]+|\bS60\b',
            'Windows\sCE.*(PPC|Smartphone|Mobile|[0-9]{3}x[0-9]{3})|Window\sMobile|Windows\sPhone\s[0-9.]+|WCE;',
            'Windows\sPhone\s10.0|Windows\sPhone\s8.1|Windows\sPhone\s8.0|Windows\sPhone\sOS|XBLWP7|ZuneWP7|Windows\sNT\s6\.[23]\;\sARM\;',
            '\biPhone.*Mobile|\biPod|\biPad',
            'Apple-iPhone7C2',
            'MeeGo',
            'Maemo',
            'J2ME\/|\bMIDP\b|\bCLDC\b', // '|Java/' produces bug #135
            'webOS|hpwOS',
            '\bBada\b',
            'BREW'
        );
        return $operating_systems;
    }

    public function getMobileUserAgents()
    {
        return implode("|", $this->get_mobile_browsers()) . "|" . implode("|", $this->get_operating_systems());
    }

    public function excludeRules()
    {
        $htaccess_page_rules = "";
        if (!empty($this->settings['exclude_url_exclusions_html_cache'])) {
            $rules_json = !empty($exclude_setting) ? explode("\r\n", $exclude_setting) : array();
            if (count($rules_json) > 0) {
                foreach ($rules_json as $value) {
                    $htaccess_page_rules = $htaccess_page_rules . "RewriteCond %{REQUEST_URI} !" . trim($value) . " [NC]\n";
                }
            }
        }

        return "# Start W3 Exclude\n" . $htaccess_page_rules . "# End W3 Exclude\n";
    }

    public function http_condition_rule()
    {
        $http_host = preg_replace("/(http(s?)\:)?\/\/(www\d*\.)?/i", "", trim($this->addSettings['homeUrl'], "/"));

        if (preg_match("/\//", $http_host)) {
            $http_host = strstr($http_host, '/', true);
        }

        if (preg_match("/www\./", $this->addSettings['homeUrl'])) {
            $http_host = "www." . $http_host;
        }

        return "RewriteCond %{HTTP_HOST} ^" . $http_host;
    }

    public function isSubdirectoryInstall()
    {
        if (strlen($this->addSettings['siteUrl']) > strlen($this->addSettings['homeUrl'])) {
            return true;
        }
        return false;
    }

    public function query_string_rule()
    {
        $enableCachingGetParaRule = isset($this->settings['enable_caching_get_para']) ? 1 : '';
        if (!$enableCachingGetParaRule) {
            return "RewriteCond %{QUERY_STRING} !.+" . "\n";
        } else {
            return "RewriteCond %{QUERY_STRING} ^(.*)$" . "\n";
        }
    }
    public function w3HeaderCheck()
    {
        return $this->isAdmin()
            || $this->isSpecialContentType()
            || $this->isSpecialRoute()
            || (!empty($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST')
            || (!empty($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'PUT')
            || (!empty($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'DELETE')
            || $this->is_404()
            || $this->checkUrl()
            || $this->isAjaxRequest();
    }

    function isAjaxRequest()
    {
        return (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') ? true : false;
    }
    function checkUrl()
    {
        if (strpos($this->addSettings['fullUrlWithoutParam'], $this->addSettings['siteUrl']) !== false || strpos($this->addSettings['fullUrlWithoutParam'], $this->addSettings['homeUrl']) !== false) {
            return false;
        }
        return true;
    }

    public function set_current_page_content_type($html)
    {
        $content_type = false;
        if (function_exists("headers_list")) {
            $headers = headers_list();
            foreach ($headers as $header) {
                if (preg_match("/Content-Type\:/i", $header)) {
                    $content_type = preg_replace("/Content-Type\:\s(.+)/i", "$1", $header);
                }
            }
        }

        if (preg_match("/xml/i", $content_type)) {
            $this->current_page_content_type = "xml";
        } else if (preg_match("/json/i", $content_type)) {
            $this->current_page_content_type = "json";
        } else {
            $this->current_page_content_type = "html";
        }
    }

    function checkCacheWithQueryParams()
    {
        $path = $this->addSettings['full_url'];
        $parsed_url = $this->w3ParseUrl($path);
        $enableCachingGetPara = !empty($this->settings['enable_caching_get_para']) ? 1 : 0;
        if ($enableCachingGetPara == 0 && !empty($parsed_url['query'])) {
            return true;
        }
        return false;
    }

    public function checkIsPageExcluded()
    {
        $uri_exclusions = isset($this->settings['exclude_url_exclusions_html_cache']) ? explode("\r\n", $this->settings['exclude_url_exclusions_html_cache']) : array();
        $uri_exclusions = array_merge($uri_exclusions, array('login', '/admin', '/wp-admin', '/wp-login', 'json', 'sitemap'));
        if (!empty($uri_exclusions)) {
            foreach ($uri_exclusions as $element) {
                if (!empty($element) && strpos($this->addSettings['full_url'], $element) != false) {
                    return true;
                }
            }
        }
        return false;
    }

    public function checkHtml($buffer)
    {
        if (!$this->is_html()) {
            return false;
        }
        if (preg_match('/<html[^\>]*>/si', $buffer) && preg_match('/<body[^\>]*>/si', $buffer)) {
            return false;
        }
        return true;
    }

    public function w3NoHtmlCache($html)
    {
        $this->set_current_page_content_type($html);
        if ($this->checkFirewall()) {
            return "<!-- DONOTCACHEPAGE is defined as TRUE -->";
        } elseif ($this->checkIsPageExcluded()) {
            return true;
        } elseif ($this->w3HeaderCheck()) {
            return true;
        } elseif ($this->is_json() && (!defined('W3_CACHE_JSON') || (defined('W3_CACHE_JSON') && W3_CACHE_JSON !== true))) {
            return true;
        } else if (preg_match("/Mediapartners-Google|Google\sWireless\sTranscoder/i", $this->addSettings['HTTP_USER_AGENT'])) {
            return true;
        } elseif ($this->checkCacheWithQueryParams()) {
            return '<!-- not cached due to query parameter -->';
        } else if (empty($this->settings['enable_loggedin_user_caching']) && ($this->w3UserLoggedIn() || $this->isCommenter())) {
            return '<!--User logged In -->';
        } else if ($this->isPasswordProtected($html)) {
            return '<!-- Password protected content has been detected -->';
        } else if ($this->checkCaptcha($html)) {
            return '<!-- This page was not cached because captcha is present -->';
        } else if ($this->last_error($html)) {
            return true;
        } else if ($this->ignored()) {
            return true;
        } else if (isset($_GET["preview"])) {
            return '<!-- not cached -->';
        } else if ($this->checkHtml($html)) {
            return '<!-- html is corrupted -->';
        } else if ((function_exists("http_response_code")) && (http_response_code() == 301 || http_response_code() == 302)) {
            return '<!-- invalid reponse code ' . http_response_code() . ' -->';
        } else {
            return false;
        }
        return false;
    }

    function hookBeforeStartOptimization()
    {
        if (isset($_POST['_w3nonce']) && $this->checkSecurityKey($_POST['_w3nonce'], 'hook_callback')) {
            ini_set('display_errors', 0);
            if (strpos($_POST['script'], '\"') !== false) {
                $data = (array)json_decode(stripslashes($_POST['script']));
            } else {
                $data = (array)json_decode($_POST['script']);
            }
            foreach ($data as $key => $singleHook) {
                $num = 3;
                register_shutdown_function(function () use ($data, $num) {
                    $error = error_get_last();

                    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
                        // Handle the fatal error
                        $responseData = array(
                            'error' => "Fatal error occurred: {$error['message']}",
                            'additional_data' => $data[$num]->hookKey
                        );
                        echo $this->w3JsonEncode($responseData);
                        exit;
                    }
                });
                $script = !empty($singleHook->value) ? 'function drupal_speeder' . $key . '(){' . preg_replace('/[^\x20-\x7E]/', '', $singleHook->value) . 'return true;}' : '';
                try {
                    $response = $this->safeEval("$script");
                    if (!empty($response['error'])) {
                        $parseErrorData = array($singleHook->hookKey, $response);
                        echo $this->w3JsonEncode($parseErrorData);
                        exit;
                    }
                } catch (ParseError $p) {
                    // Handle parse error
                    $parseErrorData = array($singleHook->hookKey, ['error' => "Parse error occurred: {$p->getMessage()}"]);
                    echo $this->w3JsonEncode($parseErrorData);
                    exit;
                } catch (Exception $e) {
                    // Handle other exceptions
                    $exceptionError = array($singleHook->hookKey, ['error' => $e->getMessage()]);
                    echo $this->w3JsonEncode($exceptionError);
                    exit;
                }
            }
            exit;
        }
    }
    function w3GetCssResponse()
    {
        if (!isset($_POST['DsCssResponseKey']) || $this->w3GetOption('DsCssResponseKey') != $_POST['DsCssResponseKey']) {
            echo 'Request not valid';
            exit;
        }
        if (!empty($_POST['response_path']) && strpos($_POST['response_path'], '/critical-css/') !== false) {
            $data = json_encode($_POST);
            $path = $_POST['response_path'];
            $url = $_POST['url'];
            $this->w3CreateFolder($path);
            if (is_writable($path)) {
                $this->w3CreateFile($path . '/' . base64_encode($url) . '.json', $data);
                echo json_encode(array('w3-status-code' => 1, 'success' => 1));
                exit;
            }
        }
        echo json_encode(array('w3-status-code' => 1, 'error' => 1));
        exit;
    }

    function w3GetResourceUrl($css, $enable_cdn, $excluded = 0, $type = 'image')
    {
        $cssNew = $css;
        if ($enable_cdn && !$this->w3CheckExcludedPath($css, $this->addSettings[$type.'_exclude_cdn_path'] ?? [])) {
            $cssNew = str_replace($this->addSettings['siteUrlArr']['host'], $this->addSettings[$type.'UrlArr']['host'], (strpos($css, $this->addSettings['siteUrlArr']['host']) === false ? ($excluded ? $this->addSettings['siteUrl'] . '/' : $this->addSettings['cacheUrl'] . '/') . ltrim($css, '/') : $cssNew));
        } elseif (strpos($css, $this->addSettings['siteUrlArr']['host']) === false && !$this->w3IsExternal($css, [], $type)) {
            $cssNew = ($excluded ? $this->addSettings['siteUrl'] : $this->addSettings['cacheUrl']) . '/' . ltrim($css, '/');
        }
        $cssNew = $this->customizeResourceUrl($css, $enable_cdn, $cssNew);
        return $cssNew;
    }

    function w3PreloadCssPath($url = '')
    {
        $orgurl = $url = empty($url) ? $this->addSettings['fullUrlWithoutParam'] : $url;
        if (!empty($this->addSettings['preload_css_url'][$url])) {
            return $this->addSettings['preload_css_url'][$url];
        }
        $url = $this->w3PreloadCssCustomizePath($url);
        if (function_exists('dsCustomizeCriticalCssPath')) {
            $url = dsCustomizeCriticalCssPath($url);
        }
        if (!empty($this->settings['hook_customize_critical_css_url'])) {
            $code = str_replace(array('$url', '$orgurl'), array('$args[0]', '$args[1]'), $this->settings['hook_customize_critical_css_url']);
            $url = $this->hookCallbackFunction($code, $url, $orgurl);
        }
        $full_url = str_replace($this->addSettings['secure'], '', rtrim($url, '/'));
        $path = urldecode($this->w3GetCriticalCachePath($full_url));
        $this->addSettings['preload_css_url'][$orgurl] = $path;
        return $path;
    }

    function w3GetCacheUrl($path = '')
    {
        $current_blog = $this->getCurrentBlog();
        $cacheUrl = $this->addSettings['cacheUrl'] . $current_blog . (!empty($path) ? '/' . ltrim($path, '/') : '');
        return $cacheUrl;
    }

    function w3GetCachePath($path = '')
    {
        $current_blog = $this->getCurrentBlog();
        $cache_path = $this->addSettings['rootCachePath'] . $current_blog . (!empty($path) ? '/' . $path : '');
        $this->w3CreateFolder($cache_path);
        return $cache_path;
    }

    function w3GetCriticalCachePath($path = '')
    {
        $current_blog = $this->getCurrentBlog();
        $cache_path = $this->addSettings['criticalCssPath'] . $current_blog . (!empty($path) ? '/' . $path : '');
        $this->w3CreateFolder($cache_path);
        return $cache_path;
    }

    function allCriticalUrls()
    {
        $preload_css = $this->w3GetOption('dsPreloadCss');
        $urls['key'] = $this->getLicenseKey();
        $urls['data'] = array();
        $url = array();
        if (!empty($preload_css) && is_array($preload_css) && count($preload_css) > 0) {
            foreach ($preload_css as $key => $css) {
                $url[] = base64_decode($key);
            }
            $urls['data'] = json_encode($url);
        }
        echo json_encode($urls);
    }

    function getCriticalCssFilename($combined_css_files)
    {
        $file_name = count($combined_css_files);
        $file_name = $this->customizeCriticalCssFilename($file_name);
        $main_css_file_name = md5($file_name) . $this->addSettings['css_ext'];
        if (function_exists('ds_customize_critical_css_filename')) {
            $main_css_file_name = ds_customize_critical_css_filename($main_css_file_name, $combined_css_files);
        }
        if (!empty($this->settings['hook_customize_critical_css_filename'])) {
            $code = str_replace(array('$main_css_file_name', '$combined_css_files'), array('$args[0]', '$arg[1]'), $this->settings['hook_customize_critical_css_filename']);
            $main_css_file_name = $this->hookCallbackFunction($code, $main_css_file_name, $combined_css_files);
        }
        return $main_css_file_name;
    }

    function checkW3FolderPermissionErrors()
    {
        $w3Folders = [$this->addSettings['cache_path'], $this->addSettings['criticalCssPath'], $this->addSettings['webp_path'], $this->addSettings['w3OrgImgPath']];
        $w3FolderErrors = [];
        foreach ($w3Folders as $value) {
            if (!is_dir($value) && !mkdir($value, 0777, true)) {
                $w3FolderErrors[] = $value;
            } elseif (!is_writable($value)) {
                $w3FolderErrors[] = $value;
            }
        }
        return $w3FolderErrors;
    }

    function getActionHeading($key)
    {
        $actionHeading = [
            "html_caching" => "Enable HTML Caching",
            "enable_loggedin_user_caching" => "Enable caching for logged in user",
            "by_serve_cache_file" => "Serve html cache file by",
            "enable_caching_get_para" => "Enable caching page with GET parameters",
            "html_caching_expiry_time" => "Cache Expiry Time",
            "html_caching_for_mobile" => "Separate Cache For Mobile",
            "clear_cache_page_post_updated" => "Clear Cache when Page or Post is Updated",
            "preload_caching" => "Preload Caching",
            "preload_per_min" => "Preload page caching per minute",
            "lbc" => "Enable leverage browsing cache",
            "gzip" => "Enable Gzip compression",
            "remquery" => "Remove query parameters",
            "cache_path" => "Cache Path",
            "license_key" => "License Key",
            "main-basic-setting" => "Basic Settings",
            "main-opt-img" => "Optimize images and convert images to webp",
            "main-lazy-image" => "Lazyload Resources",
            "main-resp-img" => "Responsive images",
            "main-opt-css" => "Optimize css",
            "main-lazy-js" => "Lazyload javascript",
            "optimization_on" => "Turn ON optimization",
            "optimize_query_parameters" => "Optimize Pages with Query Parameters",
            "optimize_user_logged_in" => "Optimize pages when User Logged In",
            "separate_cache_for_mobile" => "Separate css cache for mobile",
            "enable_inp" => "Fix INP Issues",
            "cdn" => "CDN url",
            "exclude_cdn" => "Exclude file extensions from cdn",
            "image_exclude_cdn_path" => "Exclude Image path from cdn",
            "css_exclude_cdn_path" => "Exclude Css path from cdn",
            "js_exclude_cdn_path" => "Exclude Js path from cdn",
            "font_exclude_cdn_path" => "Exclude Font path from cdn",
            "audio_exclude_cdn_path" => "Exclude Audio path from cdn",
            "video_exclude_cdn_path" => "Exclude Video path from cdn",
            "opt_jpg_png" => "Optimize JPG/PNG Images",
            "keep_org_img" => "Keep Original Images",
            "img_quality" => "JPG PNG Image Quality",
            "webp_jpg" => "Convert to Webp",
            "webp_png" => "Convert to PNG",
            "webp_quality" => "Webp Image Quality",
            "lazy_load" => "Enable Lazy Load Image",
            "lazy_load_iframe" => "Enable Lazy Load Iframe",
            "lazy_load_video" => "Enable Lazy Load Video",
            "lazy_load_audio" => "Enable Lazy Load Audio",
            "lazy_load_px" => "Pixels To load Resources Below the Viewport",
            "inlineToUrlSVG" => "Load SVG Inline Tag as URL",
            "enable_background_optimization" => "Optimize Images via Cron",
            "opt_img_on_the_go" => "Optimize Images on the go",
            "opt_upload" => "Automatically Optimize Images on Upload",
            "resp_bg_img" => "Responsive Images",
            "css" => "Enable CSS Optimization",
            "google_fonts" => "Combine Google fonts",
            "localize_google_fonts" => "Localize Google fonts",
            "load_critical_css" => "Load Critical CSS",
            "load_critical_css_style_tag" => "Load Critical CSS in Style Tag",
            "enable_background_critical_css" => "Create Critical CSS via Cron",
            "load_style_tag_in_head" => "Load Style Tag in Head to Avoid CLS",
            "js" => "Enable Javascript Optimization",
            "load_combined_js" => "Lazyload Javascript",
            "load_script_tag_in_url" => "Load Inline Javascript as URL",
            "preload_resources" => "Preload Resources",
            "exclude_lazy_load" => "Exclude Resources from Lazy Loading",
            "exclude_background_lazy_load" => "Exclude Background Images from Lazy Loading",
            "exclude_css" => "Exclude Link Tag CSS from Optimization",
            "force_lazyload_css" => "Force Lazy Load Link Tag CSS",
            "force_lazy_load_inner_javascript" => "Force Lazy Load Javascript",
            "exclude_both_javascript" => "Exclude Javascript from Lazyload",
            "exclude_url_exclusions_html_cache" => "Exclude pages from HTML caching",
            "exclude_pages_from_optimization" => "Exclude Pages From Optimization",
            "exclude_page_from_load_combined_css" => "Exclude Pages from CSS Optimization",
            "exclude_page_from_load_combined_js" => "Exclude Pages from Javascript Optimization",
            "custom_css" => "Custom CSS to Load on Page Load",
            "custom_javascript" => "Custom Javascript to Load on Page Load",
            "custom_javascript_file" => "Custom Javascript Load as file",
            "custom_javascript_defer" => "Custom Javascript Load as Defer",
            "custom_js" => "Custom Javascript to Load After Page Load",
            "hook_pre_start_opt" => "W3speedster Pre Start Optimization",
            "hook_before_start_opt" => "W3speedster Before Start Optimization",
            "hook_after_opt" => "W3speedster After Optimization",
            "hook_inner_js_customize" => "W3speedster Inner JS Customize",
            "hook_inner_js_exclude" => "W3speedster Inner JS Exclude",
            "hook_internal_js_customize" => "W3speedster Internal JS Customize",
            "hook_internal_css_customize" => "W3speedster Internal Css Customize",
            "hook_internal_css_minify" => "W3speedster Internal Css Minify",
            "hook_no_critical_css" => "W3speedster No Critical Css",
            "hook_customize_critical_css" => "W3speedster Customize Critical Css",
            "hook_disable_htaccess_webp" => "W3speedster Disable Htaccess Webp",
            "hook_customize_addSettings" => "W3speedster Customize Add Settings",
            "hook_customize_main_settings" => "W3speedster Customize Main Settings",
            "hook_sep_critical_post_type" => "W3speedster Seprate Critical Css For Post Type",
            "hook_sep_critical_cat" => "W3speedster Seprate Critical Css For Category",
            "hook_video_to_videolazy" => "W3speedster Change Video To Videolazy",
            "hook_iframe_to_iframelazy" => "W3speedster Change Iframe To Iframlazy",
            "hook_exclude_image_to_lazyload" => "W3speedster Exclude Image To Lazyload",
            "hook_customize_image" => "W3speedster Customize Image",
            "hook_prevent_generation_htaccess" => "W3speedster Prevent Htaccess Generation",
            "hook_exclude_css_filter" => "W3speedster Exclude CSS Filter",
            "hook_customize_force_lazy_css" => "W3speedster Customize Force Lazyload Css",
            "hook_external_javascript_customize" => "W3speedster External Javascript Customize",
            "hook_external_javascript_filter" => "W3speedster External Javascript Filter",
            "hook_customize_script_object" => "W3speedster Customize Script Object",
            "hook_exclude_internal_js_w3_changes" => "W3speedster Exclude Internal Js W3 Changes",
            "hook_exclude_page_optimization" => "W3speedster Exclude Page Optimization",
            "hook_customize_critical_css_url" => "W3speedster Customize Critical Css Url",
            "hook_customize_critical_css_filename" => "W3speedster Customize Critical Css File Name",
            "webvitals_logs" => "Enable Core Web Vitals Logs",
            "import_text" => "Import Settings",
        ];
        return $actionHeading[$key] ?? "";
    }

    function w3SpeedsterGetDataAdvancedCacheFile()
    {
        $scheme = $this->addSettings['siteUrlArr']['scheme'] === "https" ? "on" : "off";
        $host = $this->addSettings['siteUrlArr']['host'] ?? "";
        $cachePath =  $this->addSettings['rootCachePath'] . '/html{{HASH}}' . '/' . $scheme . '-' . $host;
        $data = '<?php
        /**
         * Advanced Cache file
         * Added By Drupal Speeder v' . DRUPAL_SPEEDER_VERSION . '
         
         */
		$expiryTime = ' . ($this->settings['html_caching_expiry_time'] ? $this->settings['html_caching_expiry_time'] : 3600) . ';
		$loggedinCaching = ' . (!empty($this->settings['enable_loggedin_user_caching']) ? 1 : 0) . ';
		$enableCachingGetPara = ' . (!empty($this->settings['enable_caching_get_para']) ? 1 : 0) . ';
		$seprateMobileCaching  = ' . (!empty($this->settings['html_caching_for_mobile']) ? 1 : 0) . ';
		' . $this->exitDirectCall() . '
		if (!empty($_SERVER["QUERY_STRING"])) {
			if (strpos($_SERVER["QUERY_STRING"],"orgurl") !== false) {
				return;
			} 
		}
		if (!empty($_POST)) {
			return;
		}
		if (isAjaxRequest()) {
			return;
		}
		$queryPara = 0;
        $path = $_SERVER[\'REQUEST_URI\'];
        $parsed_url = parse_url($path);
		$queryPara = 0;
		if (!empty($parsed_url[\'query\'])) {
			$queryPara = 1;
			$query = $parsed_url[\'query\'];
		} 
		$hash = \'\';
		$userLoggedin = 0;
		 foreach ($_COOKIE as $name => $value) {
            if(preg_match("/^S?SESS/i", $name)){
                $userLoggedin = 1;
                $hash = substr($name, 0, 16);
                break;
            }
           
        }
        // Define the cache directory
        $path1 = trim($parsed_url[\'path\'],\'/\');
		if (!$enableCachingGetPara &&  $queryPara == 1) {
			return;
		}elseif(!empty($query)){
			$path1 .= \'/\'.$query;
		}
        $cachePath = "' . $cachePath . '";
        if($loggedinCaching == 1 && !empty($hash)){
           $cachePath = str_replace(\'{{HASH}}\', \'/\'.$hash, $cachePath);
        }else{
           $cachePath = str_replace(\'{{HASH}}\', \'\', $cachePath);
        }   
        $path1 = urldecode($path1);
		if($seprateMobileCaching){
			$cacheDirMobile = "$cachePath/$path1/w3mob";
			$cacheDirDesktop = "$cachePath/$path1";
			$userAgent = $_SERVER["HTTP_USER_AGENT"];
			$isMobile = dsIsMobileDevice($userAgent);
			$type = $isMobile ? "/w3mob/" : "";
			$cacheDir = $isMobile ? $cacheDirMobile : $cacheDirDesktop;
		}else{
			$cacheDir = "$cachePath/".$path1;
		}	
		if ($loggedinCaching == 0 &&  $userLoggedin == 1) {
			return;
		}
		// Define the cache filename
        $cacheFile = $cacheDir . "/index.html";
        // Check if the cache file exists and is not expired
        if (file_exists($cacheFile) && time() - filemtime($cacheFile) < $expiryTime) { // Adjust the expiration time as needed (3600 seconds = 1 hour)
            // Serve the cached HTML
            readfile($cacheFile);
            exit;
        }else{
			@unlink($cacheFile);
		}
		function isAjaxRequest() {
			return isset($_SERVER[\'HTTP_X_REQUESTED_WITH\']) && strtolower($_SERVER[\'HTTP_X_REQUESTED_WITH\']) === \'xmlhttprequest\';
		}
        function dsIsMobileDevice($userAgent) {
			// Regular expression to identify common mobile user agents
				$pattern = "/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i";
				return preg_match($pattern, $userAgent);
		}';
        return $data;
    }

    function w3CheckLicenseKey(){
		$res= $this->drupal_speederValidateLicenseKey();
		$response = !empty($res) ? json_decode($res) : array();
		if(!empty($response[0]) && $response[0] == 'fail' && strpos($response[1],'could not verify-1') !== false){
			$this->w3UpdateOption('ds_key_log',$this->w3JsonEncode($response),'no');
			$settings = $this->w3GetOption( 'ds_speedup_option', true );
			$settings['is_activated'] = '';
			$this->w3UpdateOption( 'ds_speedup_option', $settings,'no' );	
		}
	}

    function drupal_speederSetPreloadCache(){
	    $this->deleteExpiredCache();
		if(empty($this->settings['preload_caching'])){
	        return false;
	    }
		$urls = $this->getSiteUrls();
		$pages_per_minute = !empty($this->settings['preload_per_min']) ? $this->settings['preload_per_min'] : 1;
		$urls = $this->drupal_speederPreloadCache($urls,$pages_per_minute);
		$this->w3updateOption('dsPreloadUrls',$urls,"no");
	}
	
	function deleteExpiredCache(){
		$expiryTime = $this->settings['html_caching_expiry_time'] ?? 3600;
        $cachePath = $this->addSettings['rootCachePath'] . '/html';
		$this->deleteExpiredFiles($cachePath,$expiryTime);
	}

	function deleteExpiredFiles($dir,$expiryTime){
		if(!is_dir($dir)){
			return false;
		}
		$dir = new \RecursiveDirectoryIterator($dir, \RecursiveDirectoryIterator::SKIP_DOTS);
        foreach ($dir as $file) {
            if ($file->isDir()) {
                $this->deleteExpiredFiles($file->getPathname(),$expiryTime);
            } elseif ($file->isFile() && time() - $file->getCTime() > $expiryTime) {
                $this->w3DeleteFile($file->getPathname());
            }
        }
	}

	function getSiteUrls(){
		$link_urls = $this->w3GetOption('dsPreloadUrls',1);
		if(!empty($link_urls) && is_array($link_urls) && count($link_urls) > 0){
			return $link_urls;
		}
		$url = $this->addSettings['siteUrl'];
		$link_urls = [];
		if (!empty($url)) {
			$url = htmlspecialchars(strip_tags(trim($url)), ENT_QUOTES, 'UTF-8');
			$apiUrl = 'https://link-fusion.drupal-speeder.com/fetch-links/';
			$ch = curl_init($apiUrl);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['url' => $url]));
			curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
			$response = curl_exec($ch);
			if (curl_errno($ch) || strpos($response, 'error code') !== false) {
				return $link_urls;
			} else {
				$data = json_decode($response, true);
				if (isset($data['internal_links']) && is_array($data['internal_links'])) {
					foreach ($data['internal_links'] as $link) {
						$link_urls[] = $link['links_url'];
					}
				}
				$this->w3updateOption('dsPreloadUrls',$link_urls,"no");
				return $link_urls;
			}
		} else {
			return $link_urls;
		}
	}

    function checkEnableCdn($type = '')
    {
        $enableCdn = 0;
        $cdnUrl = [
            'image' => 'image_cdn_url',
            'js'    => 'js_cdn_url',
            'font'  => 'font_cdn_url',
            'css'   => 'css_cdn_url',
            'audio' => 'audio_cdn_url',
            'video' => 'video_cdn_url'
        ];
        if (array_key_exists($type, $cdnUrl) &&
            isset($this->addSettings['siteUrl'], $this->addSettings[$cdnUrl[$type]]) &&
            $this->addSettings['siteUrl'] != $this->addSettings[$cdnUrl[$type]]) {
            $enableCdn = 1;
        }
        return $enableCdn;
    }

    function convertCdnStringSettingsToMultiCdn(){
        $cdnExtension = [
                'image' => 'jpg,jpeg,png,gif,webp,svg,bmp,ico',
                'js'    => 'js',
                'font'  => 'woff,woff2,ttf,otf,eot',
                'css'   => 'css',
                'audio' => 'mp3,wav,ogg',
                'video' => 'mp4,webm,ogg,avi,mov'
        ];
        $cdn = [];
        if (!empty($this->settings['cdn']) && !is_array($this->settings['cdn']) && !empty($this->settings['exclude_cdn'])) {
            $cdn[1]['url'] = $this->settings['cdn'];
            $cdn[1]['exclude_path'] = $this->settings['exclude_cdn_path'] ?? '';
            $type = [];
            foreach ($cdnExtension as $key => $value) {
                $extensionArray = explode(',', $value);
                $exclude = false;
                foreach ($extensionArray as $item) {
                    if(strpos($this->settings['exclude_cdn'],$item) != false){
                        $exclude = true;
                        break;
                    }
                }
                if(!$exclude){
                    $type[] = $key;
                }
            }
            $cdn[1]['type'] = implode(',', $type);
            $this->settings['cdn'] = $cdn; 
        }
    }

    function mergeInlineNExternalJavascript() {
        if (!empty($this->settings['exclude_javascript']) || !empty($this->settings['exclude_inner_javascript'])) {
            $list1 = explode("\r\n", $this->settings['exclude_javascript'] ?? '');
            $list2 = explode("\r\n", $this->settings['exclude_inner_javascript'] ?? '');
            $list3 = explode("\r\n", $this->settings['exclude_both_javascript'] ?? '');
            $merged = array_filter(array_merge($list1, $list2, $list3), 'strlen');
            $this->settings['exclude_both_javascript'] = implode("\r\n", $merged);
            $this->settings['exclude_javascript'] = '';
            $this->settings['exclude_inner_javascript'] = '';
            $this->w3UpdateOption('ds_speedup_option', $this->settings,'no');
        }
    }

    function getSitemapUrls($siteUrl) {
        $robotsTxt = @file_get_contents($siteUrl . '/robots.txt');
        if (!$robotsTxt) {
            return [];
        }
        preg_match_all('/Sitemap:\s*(.+)/i', $robotsTxt, $matches);
        $sitemaps = $matches[1] ?? [];
        if (empty($sitemaps)) {
            $sitemaps[] = $siteUrl . '/sitemap.xml';
        }
        $allUrls = [];
        foreach ($sitemaps as $sitemapUrl) {
            $allUrls = array_merge($allUrls, $this->parseSitemap($sitemapUrl));
        }
        return $allUrls;
    }

    function parseSitemap($sitemapUrl) {
        $content = @file_get_contents($sitemapUrl);
        if (!$content) {
            return [];
        }
        $urls = [];
        $xml = @simplexml_load_string($content);
        if (!$xml) return [];
        if (isset($xml->sitemap)) {
            foreach ($xml->sitemap as $s) {
                $loc = (string)$s->loc;
                $urls = array_merge($urls, $this->parseSitemap($loc));
            }
        }
        if (isset($xml->url)) {
            foreach ($xml->url as $u) {
                $urls[] = (string)$u->loc;
            }
        }
        return $urls;
    }

    function createSiteMapJsonFile(){
        $urls = $this->getSitemapUrls($this->addSettings['siteUrl']);
        if(is_array($urls) && count($urls)){
            $jsonFilePath = $this->addSettings['rootCachePath'] .'/sitemap.json';
            $this->w3CreateFile($jsonFilePath, json_encode($urls));
        }
    }

    function w3CheckExcludedPath($string, $pathArray){
        return !empty(array_filter($pathArray, fn($word) => strpos($string, $word) !== false));
    }

    function checkHtaccessStatus($htaccess){
        $tempFolder = $this->addSettings['rootCachePath'].'/temp/';
        $tempHtaccessPath = $tempFolder.'.htaccess';
        $tempFilePath = $tempFolder.'index.php';
        $tempUrl = $this->addSettings['cacheUrl'].'/temp/index.php';
        $this->w3CreateFile($tempHtaccessPath, $htaccess);
        $this->w3CreateFile($tempFilePath, '<?php echo "drupal_speeder"; ?>');
        $headers = get_headers($tempUrl);
        $code = substr($headers[0], 9, 3);
        $this->w3Rmdir($tempFolder);
        if((int)$code >= 500){
            return false;
        }
        return true;
    }

    function w3AddError($type, $message){
        $errors = $this->w3GetOption('ds_errors', 1);
        $errors = is_array($errors) ? $errors : [];
        $errors[] = ['type' => $type, 'message' => $message];
        $this->w3UpdateOption('ds_errors', $errors);
    }

    function w3FlushErrors(){
        $this->w3UpdateOption('ds_errors', []);
    }

    function w3GetErrors(){
        $errors = $this->w3GetOption('ds_errors', 1);
        return is_array($errors) ? $errors : [];
    }

    function w3EnqueCriticalUrlsOnServer($urls=[]){
        $criticalUrls = [];
        if(count($urls) > 10){
            foreach ($urls as $key1 => $url) {
                if(!empty($url[1]) && $url[1] == 2){
                    $criticalUrls[] = base64_decode($key1);
                    $urls[$key1][1]= 1;
                }
            }
        }
        $key = $this->getLicenseKey() ?? '';
        if(!empty($this->settings['is_activated']) && !empty($key)){
            //$urls = $this->getSitemapUrls($this->addSettings['siteUrl']);
            $body = [
                'key' => $key,
                'urls' => (count($criticalUrls) > 2 ? $criticalUrls :[$this->addSettings['siteUrl']])
            ];
            $url = $this->addSettings['dsApiUrl'] . '/css/create.php';
            $this->w3RemotePost($url, $body);
            
        }
        return $urls;
    }
}

