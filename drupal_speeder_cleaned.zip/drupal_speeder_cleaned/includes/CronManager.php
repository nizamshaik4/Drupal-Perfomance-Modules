<?php

namespace DrupalSpeeder;

require_once(__DIR__ . '/ImageOptimize.php');

/**
 * Class Cron
 * Handles custom cron job registration and execution.
 */
class CronManager extends ImageOptimize
{
    public $cronJobs = [];
    
    public function __construct()
    {
        parent::__construct();
        $this->cronJobs = $this->w3GetOption('cron_jobs', 1);
        $preload_css = $this->w3GetOption('drupal_speederPreloadCss');
        if (!empty($preload_css) && is_array($preload_css) && count($preload_css) > 0 && !empty($this->settings['enable_background_critical_css'])) {
            $this->w3AddCronJob('w3GeneratePreloadCss', 'w3GeneratePreloadCss', 60);
        } else {
            $this->w3RemoveCronJob('w3GeneratePreloadCss');
        }

        list($img_to_opt, $img_remaining) = $this->getImageOptimizationDetails();
        if (!empty($this->settings['enable_background_optimization']) && $img_remaining > 0 && !(empty($this->settings['opt_jpg_png']) && empty($this->settings['webp_jpg']) && empty($this->settings['webp_png']))) {
            $this->w3AddCronJob('drupal_speederOptimizeImageCallback', 'drupal_speederOptimizeImageCallback', 60);
        } else {
            $this->w3RemoveCronJob('drupal_speederOptimizeImageCallback');
        }

        $this->w3AddCronJob('deleteCoreWebVitalsLog', 'deleteCoreWebVitalsLog', 86400);
        $this->w3AddCronJob('deleteSettingsChangeLog', 'deleteSettingsChangeLog', 86400);
        $this->w3AddCronJob('w3CheckLicenseKey', 'w3CheckLicenseKey', 86400);
        $this->w3AddCronJob('w3CacheSizeCallback', 'w3CacheSizeCallback', 3600);
        $this->w3AddCronJob('drupal_speederSetPreloadCache', 'drupal_speederSetPreloadCache', 60);
        $this->w3AddCronJob('createSiteMapJsonFile', 'createSiteMapJsonFile', 86400);
    }

    /**
     * Adds a cron job if it doesn't already exist.
     *
     * @param string $jobName
     * @param string $functionName
     * @param int $interval Duration in seconds between executions
     */
    public function w3AddCronJob(string $jobName, string $functionName, int $interval): void
    {
        $cronJobs = $this->cronJobs;
        if (!isset($cronJobs[$jobName]) || $cronJobs[$jobName]['function_name'] != $functionName || $cronJobs[$jobName]['duration'] != $interval) {
            $cronJobs[$jobName] = [
                'function_name' => $functionName,
                'duration' => $interval,
                'last_run' => 0
            ];
            $this->cronJobs = $cronJobs;
            $this->w3UpdateOption('cron_jobs', $this->cronJobs, 0, 1);
        }
    }

    /**
     * Removes a cron job by name.
     *
     * @param string $jobName
     */
    public function w3RemoveCronJob(string $jobName): void
    {
        $cronJobs = $this->cronJobs;
        if (isset($cronJobs[$jobName])) {
            unset($cronJobs[$jobName]);
            $this->cronJobs = $cronJobs;
            $this->w3UpdateOption('cron_jobs', $cronJobs, 0, 1);
        }
    }

    /**
     * Runs due cron jobs.
     */
    public function runCronJobs(): void
    {
        $cronJobs = $this->cronJobs;
        $currentTime = time();
        foreach ($cronJobs as $jobName => &$job) {
            if (($currentTime - $job['last_run']) >= $job['duration']) {
                $function = $job['function_name'] ?? null;
                if ($function && method_exists($this, $function)) {
                    try {
                        $this->$function();
                        $job['last_run'] = $currentTime;
                    } catch (\Throwable $e) {
                        error_log("[W3speedster Cron] Error running '$function': " . $e->getMessage());
                    }
                } else {
                    error_log("[W3speedster Cron] Method '$function' does not exist.");
                }
            }
        }
        unset($job);
        $this->cronJobs = $cronJobs;
        $this->w3UpdateOption('cron_jobs', $cronJobs, 0, 1);
    }
}