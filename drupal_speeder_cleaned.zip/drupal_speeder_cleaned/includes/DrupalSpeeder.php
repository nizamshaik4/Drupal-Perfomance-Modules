<?php

namespace DrupalSpeeder;

class DrupalSpeeder extends SpeedCore
{
	var $addSettings;
	var $settings;
	var $html = "";
	var $w3_images  = [];
	var $loggedInUser;
	public function __construct()
	{
		$this->loggedInUser = defined('CURRENT_LOGGEDIN_USER') ? CURRENT_LOGGEDIN_USER : "Unknown";
		$this->settings = $this->w3GetOption('ds_speedup_option', true);
		$this->settings = !empty($this->settings) && is_array($this->settings) ? $this->settings : array();
		$this->addSettings = array();
		$this->addSettings['HTTP_USER_AGENT'] = !empty($_SERVER["HTTP_USER_AGENT"]) ? $_SERVER["HTTP_USER_AGENT"] : '';
		$this->addSettings['w3_get'] = $_GET;

		// Detect scheme correctly — critical for localhost (http) vs production (https)
		$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
			|| (!empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
			|| (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
		$scheme = $isHttps ? 'https' : 'http';

		$this->addSettings['secure']  = $scheme . '://';
		$this->addSettings['homeUrl'] = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
		$this->addSettings['siteUrl'] = $this->addSettings['homeUrl'];

		if (strpos($this->addSettings['homeUrl'], '?') !== false) {
			$home_url_arr = explode('?', $this->addSettings['homeUrl']);
			$this->addSettings['homeUrl'] = $home_url_arr[0];
		}
		$this->addSettings['documentRoot']   = $_SERVER['DOCUMENT_ROOT'] ?? '';
		$this->addSettings['content_path']   = $this->addSettings['documentRoot'];
		$this->addSettings['siteUrlArr']     = $this->w3ParseUrl($this->addSettings['siteUrl']);
		$this->addSettings['isMultisiteSubDomain'] = false;
		$this->addSettings['is_multisite_networkadmin'] = false;
		$this->addSettings['theme_base_url'] = $this->addSettings['siteUrl'];
		$this->addSettings['theme_base_dir'] = $this->addSettings['documentRoot'];
		$this->setAdditionalSettings();
	}
	function w3UpdateOption($filename, $html, $autoload = null, $array = 1)
	{
		$folderPath = DRUPAL_SPEEDER_WEB_PATH . '/data/';
		if (!is_dir($folderPath)) {
			if (!@mkdir($folderPath, 0775, true) && !is_dir($folderPath)) {
				return false;
			}
		}
		$path = $folderPath . $filename . '.php';
		$content = $array ? json_encode($html) : $html;
		return @file_put_contents($path, $content) !== false;
	}
	function getAjaxUrl()
	{
		return $this->addSettings['siteUrl'];
	}
	function translate($text)
	{
		echo $text;
	}
	function checkAdvCacheFileExists()
	{
		return false;
	}
	function esc_attr($text)
	{
		return $text;
	}
	function translate_($text)
	{
		return $text;
	}
	function w3JsonEncode($array)
	{
		return json_encode($array);
	}
	function w3GetOption($filename, $is_array = 1)
	{
		$folderPath = DRUPAL_SPEEDER_WEB_PATH . '/data/';
		if (!is_dir($folderPath)) {
			@mkdir($folderPath, 0775, true);
		}
		$filePath = $folderPath . $filename . '.php';
		if (is_file($filePath)) {
			$content = @file_get_contents($filePath);
			if ($content === false) {
				return $is_array ? array() : '';
			}
			if ($is_array) {
				$decoded = json_decode($content, true);
				return is_array($decoded) ? $decoded : array();
			} else {
				return $content;
			}
		}
		return $is_array ? array() : '';
	}
	function w3CalcImages($dir)
	{
		if (is_dir($dir)) {
			$objects = scandir($dir);
			foreach ($objects as $object) {
				if ($object != "." && $object != "..") {
					if (filetype($dir . "/" . $object) != "dir") {
						if ((pathinfo($dir . "/" . $object, PATHINFO_EXTENSION) == "jpeg" || pathinfo($dir . "/" . $object, PATHINFO_EXTENSION) == "jpg" || pathinfo($dir . "/" . $object, PATHINFO_EXTENSION) == "png") && strpos($object, 'org.') === false) {
							$this->w3_images[] = $dir . "/" . $object;
						}
					} elseif (strpos($object, 'DrupalSpeeder') === false) {
						$this->w3CalcImages($dir . "/" . $object);
					}
				}
			}
			reset($objects);
		}
	}
	function getImageOptimizationDetails()
	{
		$img_arr = $this->w3GetOption("w3_images", 1);
		if (!empty($_REQUEST['calc_images']) || !empty($_REQUEST['reset'])) {
			$directory = !empty($this->settings['image_upload_directory']) ? $this->settings['image_upload_directory'] : $this->addSettings['content_path'];
			if (!empty($directory)) {
				$this->w3CalcImages($directory);
				$img_to_opt = count($this->w3_images);
				$this->w3UpdateOption("w3_images", $this->w3_images, 1);
				$this->w3UpdateOption("w3_images_count", $img_to_opt, 0);
			}
			$current_url = strtok($_SERVER["REQUEST_URI"], '?');
			$query_params = $_GET;
			unset($query_params['calc_images']);
			unset($query_params['reset']);
			$this->logSettingsChanges([['action' => 'Image Optimization Reset', 'old' => 'Images', 'new' => 'Clear']]);
			$new_query = http_build_query($query_params);
			$new_url = $current_url . (!empty($new_query) ? '?' . $new_query : '');
			header("Location: $new_url");
			exit;
		} else {
			$img_remaining = count($img_arr);
			$img_to_opt = $this->w3GetOption("w3_images_count", 0);
		}
		$img_to_opt = empty($img_to_opt) ? 1 : $img_to_opt;
		$img_remaining = count($img_arr);
		return array($img_to_opt, $img_remaining);
	}
	function enqueueScripts()
	{
?>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700">
		<link rel="stylesheet" id="w3-fonts" href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700">
		<link rel="stylesheet" id="w3-font-awesome" href="<?php echo DRUPAL_SPEEDER_URL . 'assets/css/font-awesome.min.css'; ?>">
		<link rel="stylesheet" id="w3-bootstrap" href="<?php echo DRUPAL_SPEEDER_URL . 'assets/css/bootstrap.min.css'; ?>">
		<link rel="stylesheet" id="w3-datatables" href="<?php echo DRUPAL_SPEEDER_URL . 'assets/css/jquery.dataTables.min.css'; ?>">
		<link rel="stylesheet" id="w3-admin-main" href="<?php echo DRUPAL_SPEEDER_URL . 'assets/css/ds-admin.css?ver=' . rand(); ?>">
		<link rel="stylesheet" id="w3-jquery-ui" href="<?php echo DRUPAL_SPEEDER_URL . 'assets/css/jquery-ui.css'; ?>">
		<link rel="stylesheet" id="w3-select2" href="<?php echo DRUPAL_SPEEDER_URL . 'assets/css/select2.min.css'; ?>">
		<link rel="stylesheet" id="w3-select2" href="<?php echo DRUPAL_SPEEDER_URL . 'assets/css/codemirror.min.css'; ?>">
		<script id="w3-jquery" src="<?php echo DRUPAL_SPEEDER_URL . 'assets/js/jquery.min.js'; ?>"></script>
		<script id="w3-datatables" src="<?php echo DRUPAL_SPEEDER_URL . 'assets/js/jquery.dataTables.min.js'; ?>"></script>
		<script id="w3-prefixfree" src="<?php echo DRUPAL_SPEEDER_URL . 'assets/js/prefixfree.min.js'; ?>"></script>
		<script id="w3-bootstrap" src="<?php echo DRUPAL_SPEEDER_URL . 'assets/js/bootstrap.min.js'; ?>"></script>
		<script id="w3-jquery-ui" src="<?php echo DRUPAL_SPEEDER_URL . 'assets/js/jquery-ui.js'; ?>"></script>
		<script id="w3-select2" src="<?php echo DRUPAL_SPEEDER_URL . 'assets/js/select2.min.js'; ?>"></script>
		<script id="ds-admin-core" src="<?php echo DRUPAL_SPEEDER_URL . 'assets/js/ds-admin-core.js?ver=' . rand(); ?>"></script>
		<script id="w3-codemirror" src="<?php echo DRUPAL_SPEEDER_URL . 'assets/js/codemirror.min.js'; ?>"></script>
		<script id="w3-diff" src="<?php echo DRUPAL_SPEEDER_URL . 'assets/js/diff.min.js'; ?>"></script>
		<script id="w3-codemirror-js" src="<?php echo DRUPAL_SPEEDER_URL . 'assets/js/codemirror.javascript.min.js'; ?>"></script>
		<script id="w3-custom-js" src="<?php echo DRUPAL_SPEEDER_URL . 'assets/js/ds-custom.js?ver=' . rand(); ?>"></script>
	<?php
	}
	function w3Mkdir($path, $permission, $recursive)
	{
		if (!file_exists($path)) {
			return mkdir($path, $permission, $recursive);
		}
		return true;
	}
	function drupal_speederPutContents($path, $content)
	{
		$file = file_put_contents($path, $content);
		return $file;
	}
	function w3CheckIfFolderExists($path)
	{
		if (is_dir($path)) {
			return $path;
		}
		try {
			mkdir($path, 0755, true);
		} catch (Exception $e) {
			echo 'Message: ' . $e->getMessage();
		}
		return $path;
	}
	function getCurlUrl($url)
	{
		if (!function_exists('curl_init')) {
			return file_get_contents($url);
		}
		$curl = curl_init();
		$headers = array(
			"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
		);
		curl_setopt_array($curl, array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 60,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => $headers,
		));
		$response = curl_exec($curl);
		if (curl_errno($curl)) {
			echo curl_error($curl) . $url;
			exit;
		}
		curl_close($curl);
		return $response;
	}


	function scheduleImageOptimizationCron($img_remaining) {}

	function w3CheckIfPageExcluded($exclude_setting)
	{
		$e_p_from_optimization = !empty($exclude_setting) ? explode("\r\n", $exclude_setting) : array();
		if (!empty($e_p_from_optimization)) {
			foreach ($e_p_from_optimization as $e_page) {
				if (empty($e_page)) {
					continue;
				}
				if (empty($_REQUEST['testing']) && $this->addSettings['homeUrl'] == $e_page) {
					return true;
				} else if ($this->addSettings['homeUrl'] != $e_page) {
					if (strpos($this->addSettings['full_url'], $e_page) !== false) {
						return true;
					}
				}
			}
		}
		return false;
	}
	public function w3IsPluginActive($plugin)
	{
		return false;
	}

	public function w3IsPluginActiveForNetwork($plugin)
	{
		// Not applicable for Drupal — always return false
		return false;
	}
	function drupal_speederGetContents($path)
	{
		$content = @file_get_contents($path);
		if (empty($content)) {
			return '';
		}
		return $content;
	}
	function w3RemoteGet($url, $params = array(), $method = 0)
	{
		$query = '';
		if (!empty($params) && is_array($params) && count($params) > 0) {
			$query = strpos($url, '?') !== false ? '&' : '?';
			foreach ($params as $key => $value) {
				$query .= $key . '=' . $value . '&';
			}
			$query = rtrim($query, '&');
		}
		$response = $this->getCurlUrl($url . $query);
		if (empty($response)) {
			$response = $this->w3Wget($url . $query);
		}
		if (!empty($response)) {
			if (!$this->addSettings['w3-wget']) {
				$this->w3UpdateOption('w3-wget', 1);
			}
			return $response;
		} else {
			return false;
		}
	}
	function createSecureKey($option)
	{
		$key = rand(10000, 100000);
		$this->w3UpdateOption($option, $key, 0);
		return $key;
	}

	function checkSecurityKey($key, $option)
	{
		$getKey = $this->w3GetOption($option, 0);
		if ($getKey == $key) {
			return true;
		}
		return false;
	}

	function checkHtmlCacheSettings()
	{
		$this->w3ModifyHtaccess();
		if (isset($_POST['html_caching']) && $_POST['html_caching'] == 'on' && $_POST['by_serve_cache_file'] == 'advanceCache') {
			$advancedCacheFile = DRUPAL_SPEEDER_WEB_PATH . '/cache.php';
			$this->w3SpeedsterRemoveHtmlCacheCode();
			if(file_exists($advancedCacheFile) && strpos($this->drupal_speederGetContents($advancedCacheFile),'Added By DrupalSpeeder Pro') === false){
				$this->addSettings['advanced_cache_exist'] = 1;
			}else{
				$this->createAdvanceCacheFile($advancedCacheFile);
			}
		} elseif (isset($_POST['html_caching']) && $_POST['html_caching'] == 'on' && $_POST['by_serve_cache_file'] == 'htaccess') {
			$htaccessPath = $this->addSettings['documentRoot'] . "/.htaccess";
			if($htaccessContent = $this->drupal_speederGetContents($htaccessPath)){
				$this->removeAdvanceCacheFile();
				$htaccess = preg_replace("/#\s?BEGIN\s?W3HTMLCACHE.*?#\s?END\s?W3HTMLCACHE/s", "", $htaccessContent);
				$data = $this->drupal_speederGetHtaccessData(); 
				if (!empty($this->htaccessModifyKeys['html_cache'])) {
					if ($this->checkHtaccessStatus($data)) {
						$htaccess = $data . $htaccess;
					} else {
						unset($this->settings['html_caching']);
						$this->w3UpdateOption('ds_speedup_option', $this->settings, 'no');
						$this->w3AddError('danger', 'Server error: Unable to apply .htaccess caching rules to the site.');
					}
				} else {
					$htaccess = $data . $htaccess;
				}
				$this->drupal_speederPutContents($htaccessPath, preg_replace('/^[ \t]*[\r\n]+/m', '', $htaccess));
			}else{
				return array("htaccess not writable", "drupal_speeder");
			}
		} elseif (empty($_POST['html_caching'])) {
			$this->removeAdvanceCacheFile();
			$this->w3SpeedsterRemoveHtmlCacheCode();
		}
	}
	function removeAdvanceCacheFile()
	{
		$advancedCacheFile = DRUPAL_SPEEDER_WEB_PATH . '/cache.php';
		if (file_exists($advancedCacheFile)) {
			$this->w3DeleteFile($advancedCacheFile);
		}
	}
	function createAdvanceCacheFile($advancedCacheFile)
	{
		$file_content = $this->w3SpeedsterGetDataAdvancedCacheFile();
		$this->drupal_speederPutContents($advancedCacheFile, $file_content);
	}
	function w3ModifyHtaccess()
	{
		$path = $this->addSettings['documentRoot'] . '/';
		if (!file_exists($path . ".htaccess")) {
			if (isset($_SERVER["SERVER_SOFTWARE"]) && $_SERVER["SERVER_SOFTWARE"] && (preg_match("/iis/i", $_SERVER["SERVER_SOFTWARE"]) || preg_match("/nginx/i", $_SERVER["SERVER_SOFTWARE"]))) {
				//
			} else {
				return array("<label>.htaccess was not found</label>", "drupal_speeder");
			}
		}
		$htaccess = $this->drupal_speederGetContents($path . ".htaccess");
		if (is_writable($path . ".htaccess")) {
			$change_in_htaccess = 0;
			if (!empty($this->settings['lbc'])) {
				if (strpos($htaccess, '# BEGIN W3LBC') === false || strpos($htaccess, '# END W3LBC') === false) {
					$htaccess = $this->w3InsertLbcRule($htaccess) . "\n";
					$change_in_htaccess = 1;
				}
			} elseif (strpos($htaccess, '# BEGIN W3LBC') !== false || strpos($htaccess, '# END W3LBC') !== false) {
				$htaccess = preg_replace("/#\s?BEGIN\s?W3LBC.*?#\s?END\s?W3LBC/s", "", $htaccess);
				$change_in_htaccess = 1;
			}
			if (!empty($this->settings['gzip'])) {
				if (strpos($htaccess, '# BEGIN W3Gzip') === false || strpos($htaccess, '# END W3Gzip') === false) {
					$htaccess = $this->w3InsertGzipRule($htaccess);
					$change_in_htaccess = 1;
				}
			} elseif (strpos($htaccess, '# BEGIN W3Gzip') !== false || strpos($htaccess, '# END W3Gzip') !== false) {
				$htaccess = preg_replace("/\s*\#\s?BEGIN\s?W3Gzip.*?#\s?END\s?W3Gzip\s*/s", "", $htaccess);
				$change_in_htaccess = 1;
			}
			$webp_disable_htaccess = function_exists('w3_disable_htaccess_wepb') ? w3_disable_htaccess_wepb() : 0;

			if (!empty($this->settings['hook_disable_htaccess_webp'])) {
				$disable_htaccess_webp = isset($this->addSettings['disable_htaccess_webp']) ? $this->addSettings['disable_htaccess_webp'] : 0;
				$code = str_replace(array('$disable_htaccess_webp'), array('$args[0]'), $this->settings['hook_disable_htaccess_webp']);
				$this->addSettings['disable_htaccess_webp'] = $this->hookCallbackFunction($code, $disable_htaccess_webp);
			}
			if (empty($webp_disable_htaccess) && $this->addSettings['image_cdn_url'] == $this->addSettings['siteUrl']) {
				if (!empty($this->settings['webp_png']) || !empty($this->settings['webp_jpg'])) {
					if (strpos($htaccess, '# BEGIN W3WEBP') === false || strpos($htaccess, '# END W3WEBP') === false) {
						$htaccess = $this->w3InsertWebp($htaccess) . "\n";
						$change_in_htaccess = 1;
					}
				} elseif (strpos($htaccess, '# BEGIN W3WEBP') !== false || strpos($htaccess, '# END W3WEBP') !== false) {
					$htaccess = preg_replace("/#\s?BEGIN\s?W3WEBP.*?#\s?END\s?W3WEBP/s", "", $htaccess);
					$change_in_htaccess = 1;
				}
			} elseif (strpos($htaccess, '# BEGIN W3WEBP') !== false || strpos($htaccess, '# END W3WEBP') !== false) {
				$htaccess = preg_replace("/#\s?BEGIN\s?W3WEBP.*?#\s?END\s?W3WEBP/s", "", $htaccess);
				$change_in_htaccess = 1;
			}
			if (strpos($htaccess, '# BEGIN W3404') === false || strpos($htaccess, '# END W3404') === false) {
				$htaccess = $this->w3Insert_404RedirectToFile($htaccess);
				$change_in_htaccess = 1;
			}
			if ($change_in_htaccess) {
				$this->drupal_speederPutContents($path . ".htaccess", $htaccess);
			}
		} else {
			return array($this->translate_("Options have been saved"), "updated");
		}
		return array($this->translate_("Options have been saved"), "updated");
	}
	function w3InsertWebp($htaccess)
	{
		$wp_content_arr = explode('/', trim($this->addSettings['content_path'], '/'));
		$wp_content = array_pop($wp_content_arr);
		$wp_content_webp = $wp_content . "/w3-webp/";
		$basename = $wp_content_webp . "$1w3.webp";
		if (preg_match("/https?\:\/\/[^\/]+\/(.+)/", $this->addSettings['siteUrl'], $siteurl_base_name)) {
			if (preg_match("/https?\:\/\/[^\/]+\/(.+)/", $this->addSettings['siteUrl'], $homeurl_base_name)) {
				$homeurl_base_name[1] = trim($homeurl_base_name[1], "/");
				$siteurl_base_name[1] = trim($siteurl_base_name[1], "/");

				if ($homeurl_base_name[1] == $siteurl_base_name[1]) {
					if (preg_match("/" . preg_quote($homeurl_base_name[1], "/") . "$/", trim($this->addSettings['documentRoot'], "/"))) {
						$basename = $homeurl_base_name[1] . "/" . $basename;
					}
				}
			} else {
				$siteurl_base_name[1] = trim($siteurl_base_name[1], "/");
				$basename = $siteurl_base_name[1] . "/" . $basename;
			}
		}

		if ($this->addSettings['documentRoot'] == "//") {
			$RewriteCond = "RewriteCond %{DOCUMENT_ROOT}/" . $basename . " -f" . "\n";
		} else {
			$tmp_ABSPATH = str_replace(" ", "\ ", $this->addSettings['documentRoot']);

			$RewriteCond = "RewriteCond %{DOCUMENT_ROOT}/" . $basename . " -f [or]" . "\n";
			$RewriteCond = $RewriteCond . "RewriteCond " . $tmp_ABSPATH . $wp_content_webp . "$1w3.webp -f" . "\n";
		}

		$data = "\n" . "# BEGIN W3WEBP" . "\n" .
			"<IfModule mod_rewrite.c>" . "\n" .
			"RewriteEngine On" . "\n" .
			"RewriteCond %{HTTP_ACCEPT} image/webp" . "\n" .
			"RewriteCond %{REQUEST_URI} \.(jpe?g|png)" . "\n" .
			$RewriteCond .
			"RewriteRule ^" . $wp_content . "/(.*) /" . $basename . " [L]" . "\n" .
			"</IfModule>" . "\n" .
			"<IfModule mod_headers.c>" . "\n" .
			"Header append Vary Accept env=REDIRECT_accept" . "\n" .
			"</IfModule>" . "\n" .
			"AddType image/webp .webp" . "\n" .
			"# END W3WEBP" . "\n";
		$htaccess = preg_replace("/#\s?BEGIN\s?W3WEBP.*?#\s?END\s?W3WEBP/s", "", $htaccess);
		if (!empty($this->htaccessModifyKeys['webp'])) {
			if ($this->checkHtaccessStatus($data)) {
				$htaccess = $data . $htaccess;
			} else {
				unset($this->settings['webp_png'], $this->settings['webp_jpg']);
				$this->w3UpdateOption('ds_speedup_option', $this->settings, 'no');
				$this->w3AddError('danger', 'Server error: Unable to apply .htaccess webp rules to the site.');
			}
		} else {
			$htaccess = $data . $htaccess;
		}
		return $htaccess;
	}
	function esc_html($text)
	{
		return $text;
	}
	function w3SpeedsterGetLogData()
	{
		$jsonFilePath = DRUPAL_SPEEDER_WEB_PATH . '/data/' . 'webvitals.json';
		$webvitals = [];
		$recordPerPage = $_POST['limit'] ?? 10;
		$currentPage = $_POST['paged'] ?? 1;
		$filterUrl = $_POST['url'] ?? "";
		$issueType = $_POST['issuetype'] ?? "";
		$deviceType = $_POST['deviceType'] ?? "";
		$startDate = !empty($_POST['start_date']) ? strtotime($_POST['start_date']) : null;
		$endDate = !empty($_POST['end_date']) ? strtotime($_POST['end_date']) : null;

		if (file_exists($jsonFilePath)) {
			$webvitals = json_decode(file_get_contents($jsonFilePath), true) ?? [];
		}

		$filteredData = array_filter($webvitals, function ($entry) use ($issueType, $filterUrl, $deviceType, $startDate, $endDate) {
			$entryTimestamp = strtotime($entry['timestamp']);
			if (!empty($issueType) && $entry['issuetype'] !== $issueType) return false;
			if (!empty($filterUrl) && $entry['url'] !== $filterUrl) return false;
			if (!empty($deviceType) && $entry['deviceType'] !== $deviceType) return false;
			if (!empty($startDate) && $entryTimestamp < $startDate) return false;
			if (!empty($endDate) && $entryTimestamp > $endDate) return false;
			return true;
		});

		$totalRecords = count($filteredData);
		$skip = ($currentPage - 1) * $recordPerPage;
		$totalPage = $totalRecords > 0 ? ceil($totalRecords / $recordPerPage) : 1;

		$paginatedData = array_slice($filteredData, $skip, $recordPerPage);

		$logData = '';
		if ($paginatedData) {
			$logData .= '<table class="webvitals-table"><thead><th>ID</th><th>Url</th><th>Issue Type</th><th>Device Type</th><th>Data</th><th>Time</th></thead><tbody>';
			foreach ($paginatedData as $entry) {
				$prettyJsonString = json_encode(json_decode(stripslashes($entry['data']), true), JSON_PRETTY_PRINT);
				$logData .= '<tr><td class="id_' . $entry['id'] . '">' . $entry['id'] . '</td><td class="url url_' . $entry['id'] . '">' . urldecode($entry['url']) . '</td><td class="issueType_' . $entry['id'] . '">' . $entry['issuetype'] . '</td><td class="deviceType_' . $entry['id'] . '">' . $entry['deviceType'] . '</td><td class="data_' . $entry['id'] . '"><div class="log-data">' . $prettyJsonString . '</div><button data-id="' . $entry['id'] . '" class="more_info" type="button" popovertarget="more_info" popovertargetaction="show">View More</button></td><td class="time_' . $entry['id'] . '">' . $entry['timestamp'] . '</td></tr>';
			}
			$logData .= '</tbody></table><div class="pagination" data-last="' . $totalPage . '">';
			if ($currentPage > 1) {
				$logData .= '<button type="button" class="page-prev" data-page="1"><<</button><button type="button" class="page-prev" data-page="' . ($currentPage - 1) . '"><</button>';
			}
			for ($i = 1; $i <= $totalPage; $i++) {
				$activeClass = $i == $currentPage ? 'active' : '';
				if (($currentPage <= 2 && $i <= 5) || ($currentPage >= 3 && $i >= ($currentPage - 2) && $i <= ($currentPage + 2))) {
					$logData .= '<button type="button" class="p-num ' . $activeClass . '" data-page="' . $i . '">' . $i . '</button>';
				}
			}
			if ($currentPage < $totalPage) {
				$logData .= '<button type="button" class="page-next" data-page="' . ($currentPage + 1) . '">></button><button type="button" class="page-next-last" data-page="' . $totalPage . '">>></button>';
			}
			$logData .= '</div>';
		} else {
			$logData = '<div class="no-data-found-log">No Data Found</div>';
		}

		if (isset($_POST['getBy'])) {
			echo $logData;
			exit;
		} else {
			return $logData;
		}
	}
	function deleteWebVitals()
	{
		$jsonFilePath = DRUPAL_SPEEDER_WEB_PATH . '/data/' . 'webvitals.json';
		if (!file_exists($jsonFilePath)) {
			return json_encode(['error' => 'Log file not found'], JSON_PRETTY_PRINT);
		}
		$webvitals = json_decode(file_get_contents($jsonFilePath), true) ?? [];
		$timeInterval = $_POST['time_interval'] ?? '';
		$now = time();

		switch ($timeInterval) {
			case 'last7days':
				$cutoffTimestamp = strtotime('-7 days', $now);
				break;
			case 'lastMonth':
				$cutoffTimestamp = strtotime('-30 days', $now);
				break;
			case 'last3months':
				$cutoffTimestamp = strtotime('-3 months', $now);
				break;
			case 'last6months':
				$cutoffTimestamp = strtotime('-6 months', $now);
				break;
			case 'lastYear':
				$cutoffTimestamp = strtotime('-1 year', $now);
				break;
			case 'all':
				$webvitals = [];
				break;
			default:
				return json_encode(['error' => 'Invalid time interval'], JSON_PRETTY_PRINT);
		}
		if ($timeInterval !== 'all') {
			$webvitals = array_filter($webvitals, function ($entry) use ($cutoffTimestamp) {
				return strtotime($entry['timestamp']) >= $cutoffTimestamp;
			});
		}
		file_put_contents($jsonFilePath, json_encode($webvitals, JSON_PRETTY_PRINT));
		return $this->w3SpeedsterGetLogData();
	}
	function is_404()
	{
		if (!empty($this->addSettings['title'][0]) && (strpos($this->addSettings['title'][0], '404') !== false || stripos($this->addSettings['title'][0], 'Page not found') !== false)) {
			return true;
		}
		return false;
	}
	function w3ParseUrl($url)
	{
		return parse_url($url);
	}
	function getCssResponseUrl()
	{
		return false;
	}
	function w3CheckNCreateFolder($cache_path)
	{
		return false;
	}
	function w3CheckNCreateFile($file, $content)
	{
		return false;
	}
	function assetUrl($path, $file = null)
	{
		return DRUPAL_SPEEDER_URL . $path;
	}
	function w3ScheduleEvent($event, $time)
	{
		return false;
	}
	function w3DeleteFile($file)
	{
		if (!is_string($file) || empty($file)) {
			return false;
		}
		if (file_exists($file)) {
			return @unlink($file);
		}
		return false;
	}
	function importData($data)
	{
		$import_text = json_decode($data);
		if ($import_text !== null) {
			$this->logSettingsChanges([['action' => 'Settings Imported', 'old' => json_encode($this->settings), 'new' => $data]]);
			$this->w3UpdateOption('ds_speedup_option',  $import_text, 'no');
			return true;
		} else {
			return false;
		}
	}
	function insertWebVitals()
	{
		$jsonFilePath = DRUPAL_SPEEDER_WEB_PATH . '/data/' . 'webvitals.json';
		$webvitals = [];
		if (file_exists($jsonFilePath)) {
			$webvitals = json_decode(file_get_contents($jsonFilePath), true) ?? [];
		}
		$maxId = 0;
		foreach ($webvitals as $entry) {
			if (isset($entry['id']) && $entry['id'] > $maxId) {
				$maxId = $entry['id'];
			}
		}
		$newId = $maxId + 1;
		$data = [];
		$data['id'] = $newId;
		$data['url'] = $_POST['url'] ?? '';
		$data['issuetype'] = $_POST['issueType'] ?? '';
		$data['data'] = $_POST['data'] ?? '';
		$data['timestamp'] = date('Y-m-d H:i:s');
		$data['deviceType'] = $_POST['deviceType'] ?? '';
		$webvitals[] = $data;
		file_put_contents($jsonFilePath, json_encode($webvitals, JSON_PRETTY_PRINT));
		return json_encode(['status' => 'success']);
	}
	function w3Rand()
	{
		return random_int(100, 1000);
	}
	public function set_current_page_type($html)
	{
		preg_match('/<\!--W3_PAGE_TYPE_([a-z]+)-->/i', $html, $out);
		$this->current_page_type = isset($out[1]) ? $out[1] : false;
	}
	public function is_json()
	{
		return $this->current_page_content_type == "json" ? true : false;
	}
	public function isPasswordProtected($html)
	{
		if (preg_match("/action\=[\'\"].+postpass.*[\'\"]/", $html)) {
			return true;
		}
		foreach ($_COOKIE as $key => $value) {
			if (preg_match("/wp\-postpass\_/", $key)) {
				return true;
			}
		}
		return false;
	}
	public function last_error($html = false)
	{
		if (function_exists("http_response_code") && (http_response_code() === 404)) {
			return true;
		}
		if ($this->is_404()) {
			return true;
		}
		if (preg_match("/<body id\=\"error-page\">\s*<p>[^\>]+<\/p>\s*<\/body>/i", $html)) {
			return true;
		}
	}
	public function is_html()
	{
		return $this->current_page_content_type == "html" ? true : false;
	}
	public function exitDirectCall()
	{
		return '';
	}

	public function drupal_speederGetHtaccessData()
	{
		$mobile = "";
		$loggedInUser = "";
		$ifIsNotSecure = "";
		$trailing_slash_rule = "";
		$consent_cookie = "";
		$cache_path = str_replace($this->addSettings['content_path'], '', $this->addSettings['cache_path']);
		$cache_path .= '/w3-cache/html/%{HTTPS}-%{HTTP_HOST}/';

		if (isset($_POST["html_caching_for_mobile"]) && $_POST["html_caching_for_mobile"] == "on") {
			$mobile = "RewriteCond %{HTTP_USER_AGENT} !^.*(" . $this->getMobileUserAgents() . ").*$ [NC]" . "\n";
			if (isset($_SERVER['HTTP_CLOUDFRONT_IS_MOBILE_VIEWER'])) {
				$mobile = $mobile . "RewriteCond %{HTTP_CLOUDFRONT_IS_MOBILE_VIEWER} false [NC]" . "\n";
				$mobile = $mobile . "RewriteCond %{HTTP_CLOUDFRONT_IS_TABLET_VIEWER} false [NC]" . "\n";
			}
		}

		if (empty($_POST["enable_loggedin_user_caching"])) {
			// Use Drupal session cookie (SESS prefix) to detect logged-in users
			$drupalCookieName = 'SESS';
			$loggedInUser = "RewriteCond %{HTTP:Cookie} !{$drupalCookieName}" . "\n";
		}

		if (!preg_match("/^https/i", $this->addSettings['siteUrl'])) {
			$ifIsNotSecure = "RewriteCond %{HTTPS} !=on";
		}

		$trailing_slash_rule = "RewriteCond %{REQUEST_URI} $" . "\n";

		$data = "# BEGIN W3HTMLCACHE" . "\n" .
			"<IfModule mod_rewrite.c>" . "\n" .
			"RewriteEngine On" . "\n" .
			"RewriteBase /" . "\n" .
			$this->prefixRedirect() .
			$this->excludeRules() . "\n" .
			$this->http_condition_rule() . "\n" .
			"RewriteCond %{HTTP_USER_AGENT} !(" . $this->get_excluded_useragent() . ")" . "\n" .
			"RewriteCond %{HTTP_USER_AGENT} !(W3\sCache\sPreload(\siPhone\sMobile)?\s*Bot)" . "\n" .
			"RewriteCond %{REQUEST_METHOD} !POST" . "\n" .
			"RewriteCond %{HTTP:X-Requested-With} !^XMLHttpRequest$ [NC]" . "\n" .
			$ifIsNotSecure . "\n" .
			"RewriteCond %{REQUEST_URI} !(\/){2}$" . "\n" .
			$trailing_slash_rule .
			$this->query_string_rule() .
			$loggedInUser .
			$consent_cookie .
			"RewriteCond %{HTTP:Cookie} !comment_author_" . "\n" .
			"RewriteCond %{HTTP:Cookie} !safirmobilswitcher=mobil" . "\n" .
			'RewriteCond %{HTTP:Profile} !^[a-z0-9\"]+ [NC]' . "\n" . $mobile;

		$data .= "RewriteCond %{DOCUMENT_ROOT}" . $this->getRewriteBase(true) . $cache_path . $this->getRewriteBase(true) . "$1%{QUERY_STRING}/index.html -f [OR]" . "\n";
		$data .= "RewriteCond " . $this->addSettings['documentRoot'] . $cache_path . $this->getRewriteBase(true) . "$1%{QUERY_STRING}/index.html -f" . "\n";

		$data .= 'RewriteRule ^(.*) "/' . rtrim($this->getRewriteBase(true), '/') . $cache_path . $this->getRewriteBase(true) . '$1%{QUERY_STRING}/index.html" [L]' . "\n";
		if (!empty($this->settings['html_caching_for_mobile'])) {
			$this->set_wptouch(false);
			$data = $data . "\n\n\n" . $this->update_htaccess_mob($data);
		}

		$data = $data . "</IfModule>" . "\n" .
			"<FilesMatch \"index\.(html|htm)$\">" . "\n" .
			"AddDefaultCharset UTF-8" . "\n" .
			"<ifModule mod_headers.c>" . "\n" .
			"FileETag None" . "\n" .
			"Header unset ETag" . "\n" .
			"Header set Cache-Control \"max-age=0, no-cache, no-store, must-revalidate\"" . "\n" .
			"Header set Pragma \"no-cache\"" . "\n" .
			"Header set Expires \"Mon, 29 Oct 1923 20:30:00 GMT\"" . "\n" .
			"</ifModule>" . "\n" .
			"</FilesMatch>" . "\n" .
			"# END W3HTMLCACHE" . "\n";

		return preg_replace("/\n+/", "\n", $data);
	}
	public function set_wptouch($status)
	{
		$this->addSettings['wptouch'] = $status;
	}
	public function prefixRedirect()
	{
		$forceTo = "";
		if (preg_match("/^https:\/\//", $this->addSettings['siteUrl'])) {
			if (preg_match("/^https:\/\/www\./", $this->addSettings['siteUrl'])) {
				$forceTo = "\nRewriteCond %{HTTPS} =on" . "\n" .
					"RewriteCond %{HTTP_HOST} ^www." . str_replace("www.", "", $_SERVER["HTTP_HOST"]) . "\n";
			} else {
				$forceTo = "\nRewriteCond %{HTTPS} =on" . "\n" .
					"RewriteCond %{HTTP_HOST} ^" . str_replace("www.", "", $_SERVER["HTTP_HOST"]) . "\n";
			}
		} else {
			if (preg_match("/^http:\/\/www\./", $this->addSettings['siteUrl'])) {
				$forceTo = "\nRewriteCond %{HTTP_HOST} ^" . str_replace("www.", "", $_SERVER["HTTP_HOST"]) . "\n" .
					"RewriteRule ^(.*)$ " . preg_quote($this->addSettings['siteUrl'], "/") . "\/$1 [R=301,L]" . "\n";
			} else {
				$forceTo = "\nRewriteCond %{HTTP_HOST} ^www." . str_replace("www.", "", $_SERVER["HTTP_HOST"]) . " [NC]" . "\n" .
					"RewriteRule ^(.*)$ " . preg_quote($this->addSettings['siteUrl'], "/") . "\/$1 [R=301,L]" . "\n";
			}
		}
		return $forceTo;
	}
	public function is_subdirectory_install()
	{
		return false;
	}
	public function getRewriteBase($sub = "")
	{
		if ($sub && $this->is_subdirectory_install()) {
			$trimedProtocol = preg_replace("/http:\/\/|https:\/\//", "", trim($this->addSettings['siteUrl'], "/"));
			$path = strstr($trimedProtocol, '/');
			if ($path) {
				return trim($path, "/") . "/";
			} else {
				return "";
			}
		}
		$url = rtrim($this->addSettings['siteUrl'], "/");
		preg_match("/https?:\/\/[^\/]+(.*)/", $url, $out);
		return "";
	}
	public function update_htaccess_mob($data)
	{
		preg_match("/RewriteEngine\sOn(.+)/is", $data, $out);
		$htaccess = "\n##### mobile #####\n";
		$htaccess .= $out[0];
		if ($this->addSettings['wptouch']) {
			$wptouch_rule = "RewriteCond %{HTTP:Cookie} !wptouch-pro-view=desktop";
			$htaccess = str_replace("RewriteCond %{HTTP:Profile}", $wptouch_rule . "\n" . "RewriteCond %{HTTP:Profile}", $htaccess);
		}
		$htaccess = str_replace("RewriteCond %{HTTP:Cookie} !safirmobilswitcher=mobil", "RewriteCond %{HTTP:Cookie} !safirmobilswitcher=masaustu", $htaccess);
		$htaccess = str_replace("RewriteCond %{HTTP_USER_AGENT} !^.*", "RewriteCond %{HTTP_USER_AGENT} ^.*", $htaccess);
		$htaccess = preg_replace("/\/index.html/", "/w3mob/index.html", $htaccess);
		$htaccess .= "\n##### mobile #####\n";
		return $htaccess;
	}
	protected function get_excluded_useragent()
	{
		return "facebookexternalhit|Twitterbot|LinkedInBot|WhatsApp|Mediatoolkitbot";
	}

	public function getCustomCss()
	{
		return $this->settings['custom_css'];
	}
	public function checkJsonCachingRequired()
	{
		return false;
	}
	public function isAdmin()
	{
		return false;
	}
	public function isSpecialRoute()
	{
		return false;
	}
	public function isAmpEndpoint()
	{
		return false;
	}
	public function w3UserLoggedIn()
	{
		return false;
	}
	public function checkAdminUser()
	{
		return false;
	}
	public function addShutdownFunction()
	{
		return false;
	}
	public function getTransientKey($key)
	{
		return $this->w3GetOption($key, false);
	}
	public function setTransientKey($key, $value, $time = 0): void
	{
		$this->w3UpdateOption($key, $value, null, 0);
	}
	function w3GetUploadsBasepath()
	{
		$base_url = $this->addSettings['siteUrl'];
		$base_dir =  $this->addSettings['documentRoot'];
		return array($base_url, $base_dir);
	}
	function includeHeader()
	{
		// Ensure DRUPAL_SPEEDER_URL is always defined when rendering admin
		if (!defined('DRUPAL_SPEEDER_URL')) {
			$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
				|| (!empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);
			$scheme  = $isHttps ? 'https' : 'http';
			$host    = $_SERVER['HTTP_HOST'] ?? 'localhost';
			$base    = $scheme . '://' . $host . '/';
			define('DRUPAL_SPEEDER_URL', $base . 'sites/default/files/drupal_speeder/');
		}
		include DRUPAL_SPEEDER_DIR . "/admin/index.php";
	}

	// Alias methods to match EventSubscriber calls
	function w3RemoveCriticalCssCache()
	{
		return $this->w3RemoveCriticalCssCacheFiles();
	}
	function esc_url($url)
	{
		$url = filter_var($url, FILTER_SANITIZE_URL);
		return filter_var($url, FILTER_VALIDATE_URL) === false ? '' : $url;
	}
	function checkFirewall()
	{
		return false;
	}
	public function checkCaptcha($html)
	{
		return false;
	}
	public function ignored()
	{
		return false;
	}
	function createHtmlfile($html)
	{
		$userAgent = $this->addSettings['HTTP_USER_AGENT'];
		$isMobile = $this->drupal_speederIsMobileDevice($userAgent);
		$mob_msg = '';
		if (!empty($this->settings['html_caching_for_mobile']) && $isMobile) {
			$mob_msg = 'Mobile';
		}
		$this->setCacheFilePath();
		$fileName = $this->cacheFilePath;
		$endtime = $this->microtime_float();
		$current_time = date("Y-m-d H:i:s");
		$html .= '<!--' . $mob_msg . ' Cache Created By DrupalSpeeder Pro at ' . $current_time . ' in ' . number_format($endtime - $this->addSettings['starttime'], 2) . ' secs-->';
		$this->w3CreateFile($fileName, $html);
		return $html;
	}
	public function isCommenter()
	{
		return  false;
	}
	function customizeResourceUrl($css, $enable_cdn, $cssNew)
	{
		return $cssNew;
	}
	function w3PreloadCssCustomizePath($url = "")
	{
		return $url;
	}
	function getCurrentBlog()
	{
		return "";
	}

	function userProfileData()
	{
	}

	private function arrayToShortSyntax(array $array): string
	{
		$export = var_export($array, true);
		$export = preg_replace('/^(\s*)array\s*\(/m', '$1[', $export);
		$export = preg_replace('/\)(,?)$/m', ']$1', $export);
		return $export;
	}
	function w3changeProfilesettings()
	{
	  
	}
	function customizeCriticalCssFilename($filename)
	{
		return $filename;
	}
	function pageReload()
	{
		$url = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http')
		     . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost')
		     . ($_SERVER['REQUEST_URI'] ?? '/');
		// AJAX save: return JSON so JS can redirect without ob_start conflicts
		if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) || !empty($_POST['_ajax_save'])) {
			header('Content-Type: application/json');
			echo json_encode(['success' => true, 'redirect' => $url]);
			exit;
		}
		// Normal POST redirect
		header('Location: ' . $url, true, 302);
		exit;
	}
	function logSettingsChanges($changes)
	{
		$jsonFilePath = DRUPAL_SPEEDER_WEB_PATH . '/data/' . 'changeLogs.json';
		$changeLogs = [];
		if (file_exists($jsonFilePath)) {
			$changeLogs = json_decode(file_get_contents($jsonFilePath), true) ?? [];
		}
		$time = date('Y-m-d H:i:s');
		$ip = $this->getUserIP();
		$currentUser = $this->loggedInUser;
		$maxId = count($changeLogs) + 1;
		foreach ($changes as $change) {
			$changeLogs[] =
				[
					'id'     => $maxId,
					'time'   => $time,
					'user'   => $currentUser,
					'ip'     => $ip,
					'action' => $change['action'],
					'old'    => is_array($change['old']) ? json_encode($change['old'], JSON_PRETTY_PRINT) : $change['old'],
					'new'    => is_array($change['new']) ? json_encode($change['new'], JSON_PRETTY_PRINT) : $change['new']
				];
			++$maxId;
		}
		file_put_contents($jsonFilePath, json_encode($changeLogs, JSON_PRETTY_PRINT));
	}
	function getUserIP()
	{
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			return $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
		} else {
			return $_SERVER['REMOTE_ADDR'];
		}
	}

	function w3SpeedsterGetChangeLogData()
	{
		$jsonFilePath = DRUPAL_SPEEDER_WEB_PATH . '/data/' . 'changeLogs.json';
		$changeLogs = [];
		$recordPerPage = $_POST['limit'] ?? 10;
		$currentPage = $_POST['paged'] ?? 1;
		$startDate = !empty($_POST['start_date']) ? strtotime($_POST['start_date']) : null;
		$endDate = !empty($_POST['end_date']) ? strtotime($_POST['end_date']) : null;

		if (file_exists($jsonFilePath)) {
			$changeLogs = json_decode(file_get_contents($jsonFilePath), true) ?? [];
		}

		$filteredData = array_filter($changeLogs, function ($entry) use ($startDate, $endDate) {
			$entryTimestamp = strtotime($entry['time']);
			if (!empty($startDate) && $entryTimestamp < $startDate) return false;
			if (!empty($endDate) && $entryTimestamp > $endDate) return false;
			return true;
		});

		$filteredData = array_reverse($filteredData);

		$totalRecords = count($filteredData);
		$skip = ($currentPage - 1) * $recordPerPage;
		$totalPage = $totalRecords > 0 ? ceil($totalRecords / $recordPerPage) : 1;

		$paginatedData = array_slice($filteredData, $skip, $recordPerPage);

		$logData = '';
		if ($paginatedData) {
			$logData .= '<table class="w3changelogs-table"><thead><th>ID</th><th>Time</th><th>User</th><th>Ip</th><th>Action</th><th>Previous</th><th>New</th></thead><tbody>';
			foreach ($paginatedData as $entry) {
				$oldContent = (strlen($entry['old']) > 20) ? substr($entry['old'], 0, 20) . '...' : $entry['old'];
				$newContent = (strlen($entry['new']) > 20) ? substr($entry['new'], 0, 20) . '...' : $entry['new'];
				$oldShowMoreButton = (strlen($entry['old']) > 20) ? '<button class="show-more" type="button" data-target="old_' . $entry['id'] . '">Show More</button>' : '';
				$newShowMoreButton = (strlen($entry['new']) > 20) ? '<button class="show-more" type="button" data-target="new_' . $entry['id'] . '">Show More</button><button class="show-diff" type="button" data-target-new="new_' . $entry['id'] . '" data-target-old="old_' . $entry['id'] . '">Show Difference</button>' : '';
				$logData .= '<tr>
								<td class="id_' . $entry['id'] . '">' . $entry['id'] . '</td>
								<td class="time_' . $entry['id'] . '">' . $entry['time'] . '</td>
								<td class="time_' . $entry['id'] . '">' . $entry['user'] . '</td>
								<td class="time_' . $entry['id'] . '">' . $entry['ip'] . '</td>
								<td class="time_' . $entry['id'] . '">' . $entry['action'] . '</td>
								<td class="time_' . $entry['id'] . '">
									<div id="old_' . $entry['id'] . '" style="display:none;"><pre>' . $entry['old'] . '</pre></div>
									<div class="old-content"><pre class="change-log-pre">' . $oldContent . '</pre></div>
									' . $oldShowMoreButton . '
								</td>
								<td class="time_' . $entry['id'] . '">
									<div id="new_' . $entry['id'] . '" style="display:none;"><pre>' . $entry['new'] . '</pre></div>
									<div class="new-content" id="new_' . $entry['id'] . '"><pre class="change-log-pre">' . $newContent . '</pre></div>
									' . $newShowMoreButton . '
								</td>
							</tr>';
			}

			$logData .= '</tbody></table><div class="pagination" data-last="' . $totalPage . '">';
			if ($currentPage > 1) {
				$logData .= '<button type="button" class="change-page-prev" data-page="1"><<</button><button type="button" class="change-page-prev" data-page="' . $currentPage . '"><</button>';
			}
			for ($i = 1; $i <= $totalPage; $i++) {
				if ($currentPage == 1) {
					$activeClass = $i == 1 ? 'active' : '';
				} else {
					$activeClass = $i == $currentPage ? 'active' : '';
				}
				if (($currentPage <= 2 && $i <= 5) || ($currentPage >= 3 && $i >= ($currentPage - 2) && $i <= ($currentPage + 2))) {
					$logData .= '<button type="button" class="change-p-num ' . $activeClass . '" data-page="' . $i . '">' . $i . '</button>';
				}
			}
			if ($currentPage < $totalPage) {
				$logData .= '<button type="button" class="change-page-next" data-page=' . $currentPage . '>></button><button type="button" class="change-page-next-last" data-page=' . $totalPage . '>>></button>';
			}
			$logData .= '</div>';
		} else {
			$logData = '<div class="no-data-found-log">No Data Found</div>';
		}
		if (isset($_POST['getBy'])) {
			// @codingStandardsIgnoreLine
			echo $logData;
			exit;
		} else {
			return $logData;
		}
	}

	function w3SpeedsterDeleteChangeLogData()
	{
		$jsonFilePath = DRUPAL_SPEEDER_WEB_PATH . '/data/' . 'changeLogs.json';
		if (!file_exists($jsonFilePath)) {
			echo "No Data Found";
			exit;
		}
		$changeLogs = json_decode(file_get_contents($jsonFilePath), true) ?? [];
		$timeInterval = $_POST['time_interval'] ?? '';
		$now = time();

		switch ($timeInterval) {
			case 'last7days':
				$cutoffTimestamp = strtotime('-7 days', $now);
				break;
			case 'lastMonth':
				$cutoffTimestamp = strtotime('-30 days', $now);
				break;
			case 'last3months':
				$cutoffTimestamp = strtotime('-3 months', $now);
				break;
			case 'last6months':
				$cutoffTimestamp = strtotime('-6 months', $now);
				break;
			case 'lastYear':
				$cutoffTimestamp = strtotime('-1 year', $now);
				break;
			case 'all':
				$changeLogs = [];
				break;
			default:
				echo $this->w3SpeedsterGetChangeLogData();
				exit;
		}
		if ($timeInterval !== 'all') {
			$changeLogs = array_filter($changeLogs, function ($entry) use ($cutoffTimestamp) {
				return strtotime($entry['time']) >= $cutoffTimestamp;
			});
		}
		file_put_contents($jsonFilePath, json_encode($changeLogs, JSON_PRETTY_PRINT));
		echo $this->w3SpeedsterGetChangeLogData();
	}

	function w3SpeddsterShowUrlSuggestions()
	{
		$jsonFilePath = DRUPAL_SPEEDER_WEB_PATH . '/data/' . 'webvitals.json';
		$search_term = trim($_POST['s_text'] ?? '');
		$urlArray = [];
		if (file_exists($jsonFilePath)) {
			$webvitals = json_decode(file_get_contents($jsonFilePath), true) ?? [];
			foreach ($webvitals as $entry) {
				$url = $entry['url'] ?? '';
				if (stripos($url, trim($search_term)) !== false) {
					if (!in_array($url, $urlArray)) {
						$urlArray[] = $url;
					}
				}
			}
		}
		echo json_encode($urlArray);
		exit;
	}

	function getUserHash(){
		$hash = '';
		return $hash;
	}

	function drupal_speederOptimizeImageCallback()
	{
		$total_count = (int)$this->w3GetOption("w3_images_count", 0);
		$offset_limit = !empty($_REQUEST['w3_limit']) && (int)$_REQUEST['w3_limit'] > 0 ? (int)$_REQUEST['w3_limit'] : 2;
		$attach_arr = $this->w3GetOption("w3_images", 1);
		$images = array();
		if (!empty($attach_arr) && count($attach_arr) > 0) {
			$i = 0;
			foreach ($attach_arr as $key => $attach_id) {
				$imgUrl = str_replace($this->addSettings['documentRoot'], $this->addSettings['siteUrl'], $attach_id);
				$image_size = getimagesize($imgUrl);
				$this->w3OptimizeAttachment($imgUrl);
				$this->w3OptimizeAttachmentWebp($imgUrl);
				$images[] = $attach_id;
				$attach_arr = array_diff($attach_arr, array($attach_id));
				if ($i >= $offset_limit) {
					break;
				}
				$i++;
			}
			$this->w3UpdateOption('ds_images', $attach_arr, 1);
		}
		return json_encode(array_merge(array('offset' => $total_count - count($attach_arr)), $images));
	}

	function w3speedserRestoreOriginalImages() {
		$source_root = rtrim($this->addSettings['w3OrgImgPath'], '/') . '/';
		$destination_root = rtrim($this->addSettings['uploadPath'], '/') . '/';

		if (!is_dir($source_root)) {
			return [
				'error' => true,
				'message' => 'Source root directory does not exist.'
			];
		}

		$image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
		$iterator = new \RecursiveIteratorIterator(
			new \RecursiveDirectoryIterator($source_root, \RecursiveDirectoryIterator::SKIP_DOTS),
			\RecursiveIteratorIterator::SELF_FIRST
		);

		$files = [];
		foreach ($iterator as $file) {
			if ($file->isFile()) {
				$ext = strtolower(pathinfo($file->getFilename(), PATHINFO_EXTENSION));
				if (in_array($ext, $image_extensions)) {
					$files[] = $file;
				}
			}
		}

		$limit = 10;
		$processed = 0;
		for ($i = 0; $i < min($limit, count($files)); $i++) {
			$file = $files[$i];
			$relative_path = str_replace($source_root, '', $file->getPathname());
			$destination_path = $destination_root . $relative_path;
			$destination_dir = dirname($destination_path);

			if (!is_dir($destination_dir)) {
				mkdir($destination_dir, 0755, true);
			}

			if (copy($file->getPathname(), $destination_path)) {
				unlink($file->getPathname());
				$processed++;
			}
		}

		header('Content-Type: application/json');
		echo json_encode([
			'processed' => $processed,
			'total'     => count($files),
			'pending'   => max(0, count($files) - $processed),
		]);
		exit;
	}

	function deleteCoreWebVitalsLog(){
		$jsonFilePath = DRUPAL_SPEEDER_WEB_PATH . '/data/' . 'webvitals.json';
		if (!file_exists($jsonFilePath)) {
			return true;
		}
		$webvitals = json_decode(file_get_contents($jsonFilePath), true) ?? [];
		$now = time();
		$cutoffTimestamp = strtotime('-3 months', $now);
		$webvitals = array_filter($webvitals, function ($entry) use ($cutoffTimestamp) {
			return strtotime($entry['timestamp']) >= $cutoffTimestamp;
		});
		file_put_contents($jsonFilePath, json_encode($webvitals, JSON_PRETTY_PRINT));
		return true;
	}

	function deleteSettingsChangeLog(){
		$jsonFilePath = DRUPAL_SPEEDER_WEB_PATH . '/data/' . 'changeLogs.json';
		if (!file_exists($jsonFilePath)) {
			return true;
		}
		$changeLogs = json_decode(file_get_contents($jsonFilePath), true) ?? [];
		$now = time();
		$cutoffTimestamp = strtotime('-3 months', $now);
		$changeLogs = array_filter($changeLogs, function ($entry) use ($cutoffTimestamp) {
			return strtotime($entry['time']) >= $cutoffTimestamp;
		});
		file_put_contents($jsonFilePath, json_encode($changeLogs, JSON_PRETTY_PRINT));
		return true;
	}

	function drupal_speederPreloadCssCallback()
	{
		$response = $this->w3GeneratePreloadCss();
		if (!empty($response) && $response == "exists") {
			$response = $this->drupal_speederPreloadCssCallback();
		}
		return $response;
	}

	function drupal_speederPreloadCss(){
		$this->w3UpdateOption('w3speedup_critical_css_error', '', 'no');
		$response = $this->drupal_speederPreloadCssCallback();
		$error = $this->w3GetOption('w3speedup_critical_css_error');
		$total = (int)$this->w3GetOption('ds_preload_css_total', 0);
		$que = $this->w3GetOption('dsPreloadCss');
		$created = $total - count(is_array($que) ? $que : []);
		$runningUrl = $this->w3GetOption('w3speedup_critical_running_url', 0);
		if (is_array($error) && (empty($error[0]) || $error[0] == "")) {
			$error = [];
		}
		if (!empty($error) && is_array($error) && count($error) > 0) {
			return json_encode(['error', $error, $total, $created, $runningUrl]);
		} else {
			return json_encode(['success', $response, $total, $created, $runningUrl]);
		}
	}

	function w3RemotePost($url, $body) {
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Content-Type: application/json',
			'Content-Length: ' . strlen(json_encode($body))
		]);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		$response = curl_exec($ch);
		if (curl_errno($ch)) {
			curl_close($ch);
			return '';
		}
		curl_close($ch);
		return $response;
	}
}
