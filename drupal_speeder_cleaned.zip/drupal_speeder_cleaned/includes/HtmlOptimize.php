<?php

namespace DrupalSpeeder;

class HtmlOptimize extends JsOptimize
{
	public $current_page_content_type = '';
	public $cacheFilePath = "";
	public $cacheMsg = "";
	function dsSpeedster($html){
		$this->html = $html;
		$this->statusCode = http_response_code();
		$this->addSettings['title'] = $this->w3GetTagsData($this->html,'<title>','</title>');
		$this->w3DebugTime('start optimization');
		if(function_exists('w3speedup_pre_start_optimization')){
            $this->html = w3speedup_pre_start_optimization($this->html);
        }
		//$this->html .= 'w3speed';
		if(!empty($this->settings['hook_pre_start_opt'])){
			$code = str_replace('$html','$args[0]',$this->settings['hook_pre_start_opt']);
            $this->html = $this->hookCallbackFunction($code,$html);
        }
        $upload_dir = $this->addSettings['upload_base_dir'];
		if(!file_exists($upload_dir.'/w3test.html') && !empty($this->html)){
			$this->drupal_speederPutContents($upload_dir.'/w3test.html',$this->html);
		}
		if($this->w3NoOptimization()){
			if(!empty($this->settings['html_caching'])){
				$this->html = $this->w3SpeedsterCreateHTMLCacheFile($this->html);
			}
            return $this->html;
        }
		
		if(!empty($this->settings['hook_customize_addSettings'])){
			$addSettings = $this->addSettings;
			$code = str_replace('$addSettings','$args[0]',$this->settings['hook_customize_addSettings']);
			$this->addSettings = $this->hookCallbackFunction($code,$this->addSettings);
		}
		if(function_exists('w3speedup_customize_addSettings')){
			$this->addSettings = w3speedup_customize_addSettings($this->addSettings);
		}
		
		if(function_exists('w3speedup_customize_main_settings')){
			$this->settings = w3speedup_customize_main_settings($this->settings);
		}
		
		if(!empty($this->settings['hook_customize_main_settings'])){
			$settings = $this->settings;
			$code = str_replace('$settings','$args[0]',$this->settings['hook_customize_main_settings']);
			$this->addSettings = $this->hookCallbackFunction($code,$this->addSettings);
		}
		$this->addSettings['disable_htaccess_webp'] = function_exists('w3_disable_htaccess_wepb') ? w3_disable_htaccess_wepb() : 1;

		if(!empty($this->settings['hook_disable_htaccess_webp'])){
			$disable_htaccess_webp = $this->addSettings['disable_htaccess_webp'];
			$code = str_replace(array('$disable_htaccess_webp'),array('$args[0]'),$this->settings['hook_disable_htaccess_webp']);
			$this->addSettings['disable_htaccess_webp'] = $this->hookCallbackFunction($code,$disable_htaccess_webp);
		}
		if(!empty($this->settings['js'])){
			$this-> w3CustomJsEnqueue();
		}
        //$this->html = str_replace(array('<script type="text/javascript"',"<script type='text/javascript'",'<style type="text/css"',"<style type='text/css'"),array('<script','<script','<style','<style'),$this->html);
        if(function_exists('w3speedup_before_start_optimization')){
            $this->html = w3speedup_before_start_optimization($this->html);
        }
		if(!empty($this->settings['hook_before_start_opt'])){
			$code = str_replace('$html','$args[0]',$this->settings['hook_before_start_opt']);
            $this->html = $this->hookCallbackFunction($code,$this->html);
        }
        if(!empty($this->settings['lazy_load'])){
			$this->lazyLoadBackgroundImage();
		}
		$this->w3DebugTime('before create all links');
		$lazyload = array('script','link','img','url','picture');
		if(!empty($this->settings['inlineToUrlSVG'])){
			$lazyload[] = 'svg';
		}
		if(!empty($this->settings['lazy_load_iframe'])){
			$lazyload[] = 'iframe';
		}
		if(!empty($this->settings['lazy_load_video'])){
			$lazyload[] = 'video';
		}
		if(!empty($this->settings['lazy_load_audio'])){
			$lazyload[] = 'audio';
		}
		$this->w3DebugTime('parse all links');
		$allLinks = $this->w3SetAllLinks($this->html,$lazyload);
		$this->w3DebugTime('after create all links');
		if(!empty($allLinks['script'])){
			$this->minify($allLinks['script']);
		}
		$this->w3DebugTime('minify script');
		$this->lazyload(array('iframe'=>$allLinks['iframe'],'video'=>$allLinks['video'],'audio'=>$allLinks['audio'],'img'=>$allLinks['img'],'picture'=>$allLinks['picture'],'url'=>$allLinks['url'], 'svg'=>$allLinks['svg'] ) );
		$this->w3DebugTime('lazyload images');
		$this->minifyCss($allLinks['link']);
		$this->w3DebugTime('minify css');
		if(!empty($this->settings['load_style_tag_in_head'])){
			$this->loadStyleTagInHead($allLinks['style']);
		}
		$insertLink = $this->getW3contentsInsertLink($allLinks);
		$google_fonts = $this->w3LoadGoogleFonts();
		$this->w3InsertContentHead($google_fonts,2,$insertLink);
		$this->w3InsertContentHead('<script>'.$this->w3LazyLoadJavascript().'</script>',2,$insertLink);
		$this->w3StrReplaceBulk();
		$this->w3DebugTime('after javascript insertion');
		list($criticalCssInsertion,$criticalReplace) = $this->insertCriticalCss();

		if (!empty($this->settings['custom_css'])) {
			$fontfaces = $this->w3GetTagsData($this->settings['custom_css'], '@font-face', '}');
			$preferredFormats = ['woff2', 'woff', 'ttf', 'eot', 'svg'];
			foreach ($fontfaces as $fontface) {
				$urls = $this->w3GetTagsData($fontface, 'url(', ')');
				$fontAdded = false;
				$fontUrl = '';
				foreach ($preferredFormats as $format) {
					foreach ($urls as $url) {
						$url = str_replace(array('url(',')',"url('","')",')',"'",'"','&#039;', '\\'), '', $url);
						$fontUrl = $url = trim($url);
						if (stripos($url, $format) !== false) {
							$this->addSettings['preload_resources']['font'][] = $url;
							$fontAdded = true;
							break 2;
						}
					}
				}
				if (!$fontAdded && count($urls)) {
					$this->addSettings['preload_resources']['font'][] = $fontUrl;
				}
			}
		}
		
		$preload_html = $this->w3PreloadResources();
		$this->w3InsertContentHead("\n".$preload_html,2,$google_fonts);
		if($criticalCssInsertion){
			$this->w3InsertContentHead("\n".'{{main_w3_critical_css}}',2,$google_fonts);
			$this->html = str_replace($criticalReplace[0],$criticalReplace[1],$this->html);
		}
		if(!empty($this->settings['webvitals_logs'])){
			$this->w3InsertContentHead($this->DrupalSpeederCoreWebVitalsScript(),4);
		}
        $position = strrpos($this->html,'</body>');
		if($position){
			$this->html = substr_replace( $this->html, '<script>'.$this->w3LazyLoadImages().'</script>', $position, 0 );
		}else{
			$this->html .= '<script>'.$this->w3LazyLoadImages().'</script>';
		}
		$this->w3DebugTime('w3 script');
		
        if(function_exists('w3speedup_after_optimization')){
            $this->html = w3speedup_after_optimization($this->html);
        }
		if(!empty($this->settings['hook_after_opt'])){
			$code = str_replace('$html','$args[0]',$this->settings['hook_after_opt']);
            $this->html = $this->hookCallbackFunction($code,$this->html);
        }
		if(isset($this->settings['html_caching']) && $this->settings['html_caching'] == "on"){
			$this->html = $this->w3SpeedsterCreateHTMLCacheFile($this->html);
		}
		
		$this->w3DebugTime('before final output');
        return $this->html;
    }
	
    function w3NoOptimization(){
        if(!empty($this->addSettings['w3_get']['orgurl']) || strpos($this->html,'<body') === false){
            return true;
        }elseif($this->ignored()){
            return true;
        }elseif($this->isAmpEndpoint()){
            return true;
        }elseif($this->w3HeaderCheck()){
			return true;
		}elseif(empty($this->settings['optimization_on']) && empty($this->addSettings['w3_get']['w3_get_css_post_type']) && empty($this->addSettings['w3_get']['tester']) && empty($this->addSettings['w3_get']['testing'])){
             return true;
        }elseif(function_exists('w3speedup_exclude_page_optimization') && w3speedup_exclude_page_optimization($this->html)){
			return true;
        }elseif(empty($this->settings['optimize_user_logged_in']) && $this->w3UserLoggedIn()){
			return true;
		}elseif(empty($this->settings['optimize_query_parameters']) && $this->addSettings['full_url'] != $this->addSettings['fullUrlWithoutParam'] && empty($this->addSettings['w3_get']['tester'])){
			return true;
		}elseif(!empty($this->settings['exclude_pages_from_optimization']) && $this->w3CheckIfPageExcluded($this->settings['exclude_pages_from_optimization'])){
            return true;
        }elseif($this->is_404()){
            return true;
        }elseif($this->checkAdminUser()){
			return true;
		}
		if(!empty($this->settings['hook_exclude_page_optimization'])){
			$exclude_page_optimization = 0;
			$code = str_replace(array('$exclude_page_optimization','$html'),array('$args[0]','$args[1]'),$this->settings['hook_exclude_page_optimization']);
			$exclude_page_optimization = $this->hookCallbackFunction($code,$exclude_page_optimization,$this->html);
			if($exclude_page_optimization){
				return true;
			}
		}
        return false;
    }
    
    function w3StartOptimizationCallback(){
		ob_start(array($this,"w3Speedster") );
	}
    
    function w3ObEndFlush() {
    
        if (ob_get_level() != 0) {
    
            ob_end_flush();
    
         }
    
    }
	
	public function setCacheFilePath(){
		$userAgent = $this->addSettings['HTTP_USER_AGENT'];
		$isMobile = !empty($this->settings['html_caching_for_mobile']) && $this->drupal_speederIsMobileDevice($userAgent) ? 1 : 0;
		$url = $this->addSettings['full_url'];
		$this->cacheFilePath = $this->w3GetHtmlCacheFilePath($url,$isMobile);
	}
	
	function drupal_speederPreloadCache($urls, $pagesPerMinute) {
		$newUrls = $urls;
		foreach ($urls as $key => $url) {
			$this->w3RemoteGet($url);
			if(!empty($this->settings['separate_cache_for_mobile'])){
				$this->w3RemoteGet($url,[],0, 1);
			}
			if($pagesPerMinute-1 <=$key){
				break;
			}else{
				unset($newUrls[$key]);
			}
		}
		return $newUrls;
	}
}