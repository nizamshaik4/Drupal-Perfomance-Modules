<?php

namespace DrupalSpeeder;

class JsOptimize extends CssOptimize
{

    
	function w3ModifyFileCacheJs($string, $path){
		$src_array = explode('/',$path);
		$count = count($src_array);
		unset($src_array[$count-1]);
		if(!empty($this->settings['load_combined_js'])){
			$exclude_from_w3_changes = 0;
			if(function_exists('w3speedup_exclude_internal_js_w3_changes')){
				$exclude_from_w3_changes = w3speedup_exclude_internal_js_w3_changes($path,$string);
			}
			
			if(!empty($this->settings['hook_exclude_internal_js_w3_changes'])){
				$code = str_replace(array('$exclude_from_w3_changes','$path','$string'),array('$args[0]','$args[1]','$args[2]'),$this->settings['hook_exclude_internal_js_w3_changes']);
				$exclude_from_w3_changes = $this->hookCallbackFunction($code,$exclude_from_w3_changes,$path,$string);
			}
			
			if(/*stripos($string,'holdready') === false &&*/ !$exclude_from_w3_changes){
				$string = $this->w3ChangesInJs($string,$path);
			}
		}
		if(function_exists('w3speedup_internal_js_customize')){
			$string = w3speedup_internal_js_customize($string,$path);
		}
		
		if(!empty($this->settings['hook_internal_js_customize'])){
		   $code = $code = str_replace(array('$string','$path'),array('$args[0]','$args[1]'),$this->settings['hook_internal_js_customize']);
           $string = $this->hookCallbackFunction($code,$string,$path);
        }
		return $string;
	}
	function unlazyLoadBackgroundImageJavascript($string){
		if(strpos($string,'data-BgLz=1 ') !== false){
			$string = str_replace('data-BgLz=1 ','',$string);
		}
		return $string;
	}
	
	function w3ChangesInJs($string,$path=''){
		$string = str_replace('document.readyState','document.w3readyState',$string);
		return $string;
	}
    function w3CreateFileCacheJs($path){
		$file_name = $this->w3GetOption('w3_rand_key',0);
        $cache_file_path = $this->w3GetCachePath('js').'/'.$file_name.'/'.ltrim($path,'/');
        if( !file_exists($cache_file_path) ){
			$path1 = explode('/',$path);
			array_pop($path1);
			$path1 = implode('/',$path1);
            $string = $this->drupal_speederGetContents($this->addSettings['documentRoot'].$path);
            $string = $this->w3ModifyFileCacheJs($string, $path);
			$string = !empty($string) ? $this->w3CompressJs($string) : $string;
            $this->w3CreateFile($cache_file_path, $string );
        }
		if(file_exists($cache_file_path)){
			return str_replace($this->addSettings['rootCachePath'],'',$cache_file_path);
		}else{
			return $path;
		}
	    
    }
    function w3CreateFileCacheJsUrl($url){
		$parsedUrlArray = $this->w3ParseUrl($url);
		$cacheFilePath = $this->w3GetCachePath('js').'/'.ltrim($parsedUrlArray['path'], '/');
		if(!file_exists($cacheFilePath)){
			$string = $this->w3RemoteGet($url);
			if (empty($string)) {
				return false;
			}
			$string = $this->w3ModifyFileCacheJs($string, $path);
			$string = !empty($string) ? $this->w3CompressJs($string) : $string;
			$this->w3CreateFile($cacheFilePath, $string);
		}
		return str_replace($this->addSettings['rootCachePath'],'',$cacheFilePath);
	}
    function minify($script_links){
		if(!empty($this->settings['exclude_page_from_load_combined_js']) && $this->w3CheckIfPageExcluded($this->settings['exclude_page_from_load_combined_js'])){
			return ;
        }
		
		if(!empty($script_links) && !empty($this->settings['js'])){
			$lazy_load_js = !empty($this->settings['load_combined_js']) && $this->settings['load_combined_js'] == 'after_page_load' ? 1 : 0;
			$force_innerjs_to_lazy_load  = !empty($this->settings['force_lazy_load_inner_javascript']) ? explode("\r\n", $this->settings['force_lazy_load_inner_javascript']) : array();
            $exclude_js_arr_split  = $exclude_inner_js = !empty($this->settings['exclude_both_javascript']) ? explode("\r\n", $this->settings['exclude_both_javascript']) : array();
			foreach($exclude_js_arr_split as $key => $value){
				if(strpos($value,' defer') !== false){
					$exclude_js_arr[$key]['string'] = str_replace(' defer','',$value);
					$exclude_js_arr[$key]['defer'] = 1;
				}elseif(strpos($value,' full') !== false){
					$exclude_js_arr[$key]['string'] = str_replace(' full','',$value);
					$exclude_js_arr[$key]['full'] = 1;
				}else{	
					$exclude_js_arr[$key]['string'] = $value;
					$exclude_js_arr[$key]['defer'] = 0;
				}
			}
            $enable_cdn = $this->checkEnableCdn('js');
			
			for($si=0; $si < count($script_links); $si++){
                $script = $script_links[$si];
				$script_obj = $this->w3ParseLink('script',str_replace($this->addSettings['js_cdn_url'],$this->addSettings['siteUrl'],$script_links[$si]));
				$script_text = '';
				if(!array_key_exists('src',$script_obj)){
                    $script_text = $this->w3ParseScript('script',$script);
                }else{
					$script_obj['src'] = trim($script_obj['src']);
				}
				$scriptExcludeTypeArray = ['application/javascript', 'module', 'text/javascript', 'text/jsx;harmony=true'];
                if(!empty($script_obj['type']) && !in_array(strtolower($script_obj['type']), $scriptExcludeTypeArray)){
					if(!empty($script_text) && strpos($script_text,'data-BgLz') !== false){
						$script_modified = $this->unlazyLoadBackgroundImageJavascript($script_text);
						$this->w3StrReplaceSetJs($script_text,$script_modified);
					}
                    continue;
                }
				if(function_exists('w3speedup_customize_script_object')){
					$script_obj = w3speedup_customize_script_object($script_obj, $script);
				}
				if(!empty($this->settings['hook_customize_script_object'])){
					$code = str_replace(array('$script_obj','$script'),array('$args[0]','$args[1]'),$this->settings['hook_customize_script_object']);
					$script_obj = $this->hookCallbackFunction($code,$script_obj, $script);
				}
				
                if(!empty($script_obj['src'])){
				    $url_array = $this->w3CustomParseUrl($script_obj['src']);
					$url_array['path'] = !empty($url_array['path']) ? $url_array['path'] : '';
					if(strpos($url_array['path'],'/version') !== false){
						$url_array['path'] = preg_replace('/version(\d)*\//', '', $url_array['path']);
					}
					if(strpos($this->addSettings['documentRoot'],'/pub') !== false && strpos($url_array['path'],'/pub') !== false){
						$url_array['path'] = str_replace('/pub/', '/', $url_array['path']);
					}
					$url_array['path'] = '/'.ltrim($url_array['path'],'/');
                    $exclude_js = 0;
					$enable_cdn_path = 0;
                    if(!empty($exclude_js_arr) && is_array($exclude_js_arr)){
						foreach($exclude_js_arr as $ex_js){
							if(!empty($ex_js['string']) && strpos($script,$ex_js['string']) !== false){
								if(!empty($ex_js['defer'])){
									$exclude_js = 2;
								}elseif(!empty($ex_js['full'])){
									$exclude_js = 3;
								}else{
									$exclude_js = 1;
								}
							}
						}
					}
					if(function_exists('w3speedup_exclude_javascript_filter')){
						$exclude_js = w3speedup_exclude_javascript_filter($exclude_js,$script_obj,$script,$this->html);
					}
					if(!empty($this->settings['hook_external_javascript_filter'])){
						$code = str_replace(array('$exclude_js','$script_obj','$script','$html'),array('$args[0]','$args[1]','$args[2]','$args[3]'),$this->settings['hook_external_javascript_filter']);
						$exclude_js = $this->hookCallbackFunction($code,$exclude_js,$script_obj,$script,$this->html);
					}
					
					if($exclude_js){
						$this->addSettings['js_is_excluded'] = 1;
					}
					if($this->w3CheckEnableCdnPath($script_obj['src'], 'js')){
						$enable_cdn_path = 1;
					}
					if(strpos($url_array['path'],'./') !== false || strpos($url_array['path'],'../') !== false){
                    	$url_array['path'] = $this->removeDotPathSegments($url_array['path']);
                    }
					
					if(!$this->w3IsExternal($script_obj['src'], [], 'js') && $this->w3Endswith($url_array['path'], '.js') && $exclude_js != 1 && $exclude_js != 3){
                        $old_path = $url_array['path'];
						if(file_exists($this->addSettings['documentRoot'].$url_array['path'])){
							$url_array['path'] = $this->w3CreateFileCacheJs($url_array['path']);
							$script_obj['src'] = $this->w3GetResourceUrl($url_array['path'], $enable_cdn && $enable_cdn_path, 0, 'js');
						}elseif(!file_exists($this->addSettings['documentRoot'].$url_array['path'])){
							if($this->w3Endswith($script_obj['src'] , '.js') || strpos($script_obj['src'] , '.js?') !== false ){
								$hrefUrl = $script_obj['src'] ;
								if(strpos($script_obj['src'] ,$this->addSettings['siteUrl']) === false){
									$hrefUrl = $this->addSettings['siteUrl'].'/'.ltrim($script_obj['src'] ,'/');
								}
								//$this->html .= "w3speed3".$hrefUrl.$this->addSettings['documentRoot'].$url_array['path'].'exists=0';
								$responsePath = $this->w3CreateFileCacheJsUrl($hrefUrl);
								if(!$responsePath){
									//$this->w3StrReplaceSetCss($css,'');
									$return = 0;
								}else{
									$url_array['path'] = $responsePath;
									$script_obj['src']  = $this->w3GetResourceUrl($url_array['path'], $enable_cdn && $enable_cdn_path, 0, 'js');
								}
							}
							
						}
					}
					if($exclude_js){
                        if( $exclude_js == 3 || $exclude_js == 1){
							$script_obj['src'] = $enable_cdn && $enable_cdn_path ? str_replace($this->addSettings['siteUrl'],$this->addSettings['js_cdn_url'] ,$script_obj['src']) : $script_obj['src'];
							$this->addSettings['preload_resources']['all'][] = $script_obj['src'];
							$this->w3StrReplaceSetJs($script,$this->w3ImplodeLinkArray('script',$script_obj));
							continue;
						}
						if( $exclude_js == 2){
							$this->addSettings['preload_resources']['all'][] = $script_obj['src'];
                            $script_obj['defer'] = 'defer';
						}
						$script_obj['src'] = $enable_cdn && $enable_cdn_path ? str_replace($this->addSettings['siteUrl'],$this->addSettings['js_cdn_url'] ,$script_obj['src']) : $script_obj['src'];
						$this->preconnectExternalUrl($script_obj['src']);
						$this->w3StrReplaceSetJs($script,$this->w3ImplodeLinkArray('script',$script_obj));
                        continue;
                    }
                    $exclude_js_bool=0;
					if(!empty($force_innerjs_to_lazy_load)){
                        foreach($force_innerjs_to_lazy_load as $js){
                            if( !empty($js) && strpos($script,$js) !== false){
                                $exclude_js_bool=1;
                                break;
                            }
                        }
                    }
					
                    $val = $script_obj['src'];
                    if(!empty($val) && !$this->w3IsExternal($val, [], 'js') && strpos($script, '.js') && empty($exclude_js_bool)){
						if(!empty($script_obj['type']) && $script_obj['type'] != 'text/javascript'){
							$script_obj['data-w3-type']= $script_obj['type'];
						}
						$script_obj['type'] = 'lazyJs';
						$this->w3StrReplaceSetJs($script,$this->w3ImplodeLinkArray('script',$script_obj));
					}elseif($this->w3IsExternal($val, [], 'js') && empty($exclude_js_bool) ){
						if(!empty($script_obj['type']) && $script_obj['type'] != 'text/javascript'){
							$script_obj['data-w3-type']= $script_obj['type'];
						}
						$script_obj['type'] = 'lazyJs';
						$this->preconnectExternalUrl($script_obj['src']);
						$this->w3StrReplaceSetJs($script,$this->w3ImplodeLinkArray('script',$script_obj));
					}elseif($exclude_js_bool){
						if(!empty($script_obj['type']) && $script_obj['type'] != 'text/javascript'){
							$script_obj['data-w3-type']= $script_obj['type'];
						}
						$script_obj['src'] = $enable_cdn && $enable_cdn_path ? str_replace($this->addSettings['siteUrl'],$this->addSettings['js_cdn_url'] ,$script_obj['src']) : $script_obj['src'];
						$script_obj['type'] = 'lazyExJs';
						if(function_exists('w3_external_javascript_customize')){
							$script_obj = w3_external_javascript_customize($script_obj, $script);
						}
						if(!empty($this->settings['hook_external_javascript_customize'])){
							$code = str_replace(array('$script_obj','$script'),array('$args[0]','$args[1]'),$this->settings['hook_external_javascript_customize']);
							$script_obj = $this->hookCallbackFunction($code,$script_obj, $script);
						}
						$this->preconnectExternalUrl($script_obj['src']);
						$this->w3StrReplaceSetJs($script,$this->w3ImplodeLinkArray('script',$script_obj));
                    }
                }else{
                    
                    $inner_js = $script_text;
                    $exclude_js_bool = 0;
					$force_js_bool = 0;
                    $exclude_js_bool = $this->w3CheckJsIfExcluded($inner_js, $exclude_inner_js);
					if(!empty($force_innerjs_to_lazy_load)){
                        foreach($force_innerjs_to_lazy_load as $js){
                            if(strpos($script_text,$js) !== false){
                                $exclude_js_bool=0;
								$force_js_bool = 1;
                                break;
                            }
                        }
                    }
					$script_modified = $this->getModifiedScriptTag($script,$script_obj,$script_text,$si,$exclude_js_bool,$force_js_bool);
					$this->w3StrReplaceSetJs($script,$script_modified);
                }
            }
			if(!empty($this->settings['custom_javascript'])){
			   if(!empty($this->settings['custom_javascript_file'])){    
					$custom_js_path = $this->w3GetCachePath('all-js').'/wnw-custom-js.js';
					if(!is_file($custom_js_path)){
						$this->w3CreateFile($custom_js_path, stripslashes($this->settings['custom_javascript']));
					}
					$custom_js_url = $this->w3GetCacheUrl('all-js').'/wnw-custom-js.js';
					$custom_js_url = $enable_cdn && $enable_cdn_path ? str_replace($this->addSettings['siteUrl'],$this->addSettings['js_cdn_url'] ,$custom_js_url) : $custom_js_url;
					$position = strrpos($this->html,'</body>');
					$rand = random_int(100,1000);
					$this->html = substr_replace( $this->html, '<script '.(!empty($this->settings['custom_javascript_defer']) ? 'defer="defer"' : '').' id="wnw-custom-js" src="'.$custom_js_url.'?ver='.$rand.'"></script>', $position, 0 );
				}else{
					$position = strrpos($this->html,'</body>');
					$this->html = substr_replace( $this->html, '<script>'.stripslashes($this->settings['custom_javascript']).'</script>', $position, 0 ); 
				}
			}
		}
        
        
    }

	function getModifiedScriptTag($script,$script_obj,$script_text,$si,$exclude_js_bool,$force_js_bool){
		if(function_exists('w3speedup_inner_js_customize')){
			$script_text = w3speedup_inner_js_customize($script_text);
		}
		
		if(!empty($this->settings['hook_inner_js_customize'])){
			$code = str_replace('$script_text','$args[0]',$this->settings['hook_inner_js_customize']);
			$script_text = $this->hookCallbackFunction($code,$script_text);
		}
		if($tag = $this->loadScriptTagInUrl($script_text,$si)){
			$this->getUrlFromInlineScript($script);
			return $tag;
		}
		if(!empty($script_obj['type']) && $script_obj['type'] != 'text/javascript'){
			$script_obj['data-w3-type']= $script_obj['type'];
		}
		if(!empty($exclude_js_bool) && $exclude_js_bool != 2){
			$script_modified = '<script ';
		}elseif($exclude_js_bool == 2){
			$script_modified = '<script type="lazyJs" ';
		}elseif($force_js_bool){
			$script_modified = '<script type="lazyExJs" ';
		}else{
			$script_modified = '<script type="lazyJs" ';
		}
		if(!empty($script_obj) && is_array($script_obj) && count($script_obj) > 0){
			foreach($script_obj as $key => $value){
				if($key != 'type' && $key != 'html'){
					$script_modified .= $key.'="'.$value.'" ';
				}
			}
		}
		$script_text = $this->unlazyLoadBackgroundImageJavascript($script_text);
		if(!empty($exclude_js_bool) && $exclude_js_bool != 2){
			$script_modified = $script_modified.'>'.$script_text.'</script>';
		}else{
			if(!empty($this->settings['load_combined_js']) && $this->settings['load_combined_js'] == 'after_page_load'){
				$script_text = $this->w3ChangesInJs($script_text);
			}
			$script_modified = $script_modified.'>'.$script_text.'</script>';
		}
		return $script_modified;
	}
	function getUrlFromInlineScript($script){
		if ($script){
			$script = str_replace(["\r", "\n", "\t"," "], '', $script);
			preg_match_all('/src\=[\'|\"](h?t?t?p?s?:?\/\/[^\s"\']+)/i', $script, $matches);
			if(!empty($matches[1])){
				foreach ($matches[1] as $url) {
					$parsedUrl = $this->w3ParseUrl($url);
					if (!isset($parsedUrl['host']) || strpos($parsedUrl['host'], $this->addSettings['siteUrlArr']['host']) === false) {
						$this->preconnectExternalUrl((!empty($parsedUrl['scheme']) ? $parsedUrl['scheme'] : 'https').'://'.$parsedUrl['host']);
					}
				}
			}
		}
	}

	function preconnectExternalUrl($src){
		if(empty($this->addSettings['preload_resources']['preconnect'])){
			$this->addSettings['preload_resources']['preconnect'] = [];
		}
		if(!empty($this->settings['enable_inp']) && $this->w3IsExternal($src, [], 'js')){
			$srcArr = $this->w3ParseUrl($src);
			$domain = (!empty($srcArr['scheme']) ? $srcArr['scheme'] : 'https').'://'.(!empty($srcArr['host']) ? $srcArr['host'] : '');
			if(!in_array($domain,$this->addSettings['preload_resources']['preconnect'])){
				$this->addSettings['preload_resources']['preconnect'][] = $domain;
			}
		}
	}
	function w3CheckJsIfExcluded($inner_js, $exclude_inner_js){
		$exclude_js_bool=0;
		if(strpos($inner_js,'moment.') === false && strpos($inner_js,'wp.') === false && strpos($inner_js,'.noConflict') === false && strpos($inner_js,'wp.i18n') === false){
			$exclude_js_bool=2;
		}
		if(strpos($inner_js,'DOMContentLoaded') !== false || strpos($inner_js,'jQuery(') !== false || strpos($inner_js,'$(') !== false || strpos($inner_js,'jQuery.') !== false || strpos($inner_js,'$.') !== false){
			$exclude_js_bool=2;
		}
		
		if(!empty($exclude_inner_js)){
			foreach($exclude_inner_js as $js){
				if(!empty($js) && strpos($inner_js,$js) !== false){
					return 1;
					break;
				}
			}
		}
		if(function_exists('w3_inner_js_excluded')){
			$exclude_js_bool = w3_inner_js_excluded($exclude_js_bool,$inner_js);
		}
		
		
		if(!empty($this->settings['hook_inner_js_exclude'])){
			$code = str_replace(array('$exclude_js_bool','$inner_js'),array('$args[0]','$args[1]'),$this->settings['hook_inner_js_exclude']);
			$exclude_js_bool = $this->hookCallbackFunction($code,$exclude_js_bool,$inner_js);
		}
		return $exclude_js_bool;
	}
	
	function w3CreateJsCombinedCacheFile($final_merge_js, $enable_cdn){
		$file_name = is_array($final_merge_js) ? $this->addSettings['w3_rand_key'].'-'.implode('-', $final_merge_js) : '';
		if(!empty($file_name)){
			$js_file_name = md5($file_name).$this->addSettings['js_ext'];
			if(!is_file($this->w3GetCachePath('all-js').'/'.$js_file_name)){
				$all_js = '';
				foreach($final_merge_js as $key => $script_path){
					$all_js .= $this->drupal_speederGetContents($this->addSettings['documentRoot'].$script_path).";\n";
				}
				$this->w3CreateFile($this->w3GetCachePath('all-js').'/'.$js_file_name, $all_js);
			}
			$main_js_url = $this->w3GetCacheUrl('all-js').'/'.$js_file_name;
			$main_js_url = $enable_cdn ? str_replace($this->addSettings['siteUrl'],$this->addSettings['js_cdn_url'] ,$main_js_url) : $main_js_url;
			return $main_js_url;
		}
	}
    function w3LazyLoadJavascript(){
		$lazy_load_by_px = !empty($this->settings['lazy_load_px']) ? (int)$this->settings['lazy_load_px'] : 200;
        $script = 'var w3elem = window.innerWidth<768?\'touchstart\':\'click\';var w3LazyloadByPx='.$lazy_load_by_px.', w3LazyloadJs = '.((!empty($this->settings['load_combined_js']) && $this->settings['load_combined_js'] == 'after_page_load') && !empty($this->settings['js']) ? 1 : 0).', w3JsIsExcluded = '.(!empty($this->addSettings['js_is_excluded']) ? 1 : 0).', w3Inp = '.(!empty($this->settings['enable_inp']) ? 1 : 0).',';
		if((!empty($this->settings['exclude_page_from_load_combined_js']) && $this->w3CheckIfPageExcluded($this->settings['exclude_page_from_load_combined_js'])) || empty($this->settings['js']) ){
			$script.='w3ExcludedJs=1;';
        }else{
			$script.='w3ExcludedJs=0;'; 
		}
		return $script.$this->drupal_speederGetContents(DRUPAL_SPEEDER_DIR.'assets/js/script-load.min.js');
	}
	function w3LazyLoadImages(){
		return $this->drupal_speederGetContents(DRUPAL_SPEEDER_DIR.'assets/js/img-lazyload.js');
    }
	function loadScriptTagInUrl($script_tag,$i){
		$load_script_tag_in_url= !empty($this->settings['load_script_tag_in_url']) ? explode("\r\n", $this->settings['load_script_tag_in_url']) : array();
		$scriptContentFile = array();
		$file_name = $this->w3GetOption('w3_rand_key',0).$i;
		foreach($load_script_tag_in_url as $ex_script){
			if(!empty($ex_script) && !empty($script_tag) && strpos($script_tag, $ex_script) !== false){
				$file_name .= $ex_script;
				$scriptContentFile = $script_tag;
				break;
			}
		}
		if(!empty($scriptContentFile)){
			$file_name_cache = md5($file_name).'.js';
			if(!file_exists($this->w3CheckFullUrlCachePath().'/'.$file_name_cache)){
				$this->w3CreateFile($this->w3CheckFullUrlCachePath().'/'.$file_name_cache,$scriptContentFile);
			}
			$defer = 'type="lazyJs" src=';
			return '<script '.$defer.'"'.$this->w3GetFullUrlCache('js').'/'.$file_name_cache.'"></script>';
		}
		return false;
	}
}