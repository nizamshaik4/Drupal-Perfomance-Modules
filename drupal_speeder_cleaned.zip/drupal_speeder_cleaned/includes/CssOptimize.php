<?php

namespace DrupalSpeeder;
include_once(DRUPAL_SPEEDER_PATH . '/includes/DrupalSpeeder.php');

class CssOptimize extends DrupalSpeeder
{
    
    function w3RemoveCssComments( $minify ){
		$minify = preg_replace( '!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $minify );
		return $minify;
	}
	function w3CssCompress( $minify ){
    	$minify = str_replace( array("\r\n", "\r", "\n", "\t",'  ','    ', '    '), ' ', $minify );
		$minify = str_replace( array(": ", ":: "), array(':','::'), $minify );
    	return $minify;
    }
	function w3RelativeToAbsolutePath($url, $string){
		
		$url_new = $url;
		$url_arr = $this->w3CustomParseUrl($url);
        $url = $this->addSettings['siteUrl'].$url_arr['path'];
        
        if(strpos($string,'@import "') !== false || strpos($string,"@import '") !== false){
           $string = preg_replace('/(@import\s*)[\"|\'](.*)(\.css)[\"|\']/', '$1url("$2$3")', $string);
        }
        $matches = $this->w3GetTagsData($string,'url(',')');
		return $this->w3ConvertArrRelativeToAbsolute($string, $url, $matches);
    
    }
	function w3ConvertArrRelativeToAbsolute($string, $url, $matches){
		$webp_enable = $this->addSettings['webp_enable'];
		$replace_array = explode('/',str_replace('\'','/',$url));
		array_pop($replace_array);
		$url_parent_url = implode('/',$replace_array);
		if($this->addSettings['isMultisiteSubDomain']){
			$url_parent_url = str_replace($this->addSettings['siteUrl'],$this->addSettings['network_site_url'], $url_parent_url);
		}
		$theme_root_array = explode('/',$this->addSettings['theme_base_url']);
		$theme_root = array_pop($theme_root_array);
		foreach($matches as $match){
			if(strpos($match,'{{') !== false || strpos($match,'data:') !== false || strpos($match,'chrome-extension:') !== false){
                continue;
    		}
		    $org_match = $match;
            $match1 = str_replace(array('url(',')',"url('","')",')',"'",'"','&#039;'), '', html_entity_decode($match));
            $match1 = trim($match1);
	        if(strpos($match1,'//') > 7){
                $match1 = substr($match1, 0, 7).str_replace('//','/', substr($match1, 7));
            }
            if(empty($match1) || strpos(substr($match1, 0, 1),'#') !== false){
				continue;
			}
			if($this->addSettings['isMultisiteSubDomain'] && strpos($match1,$this->addSettings['siteUrl']) != false){
				$match1 = str_replace($this->addSettings['siteUrl'],$this->addSettings['network_site_url'],$match1);
			}
			if(strpos($match,'cdnjs.cloudflare.com') !== false){
				$img_arr = explode('?',$match1 );
				$ext = pathinfo($img_arr[0], PATHINFO_EXTENSION);
                if(strpos($url,'index.php') === false && $ext == 'css'){
					$response = $this->w3RemoteGet($match1);
					if(!empty($response)){
						$string = str_replace('@import '.$match.';',$response, $string);
					}
					continue;
				}
            }
			if(strpos($match,'fonts.gstatic.com') !== false){
				$match1 = $this->esc_url($match1);
				$cssUrl = $this->localizeGoogleFont($match1);
				if(!empty($cssUrl)){
					$string = str_replace($match1,$cssUrl, $string);
				}
			}
			if(strpos($match,'fonts.googleapis.com') !== false){
				$match1 = $this->esc_url($match1);
                if(strpos($url,'index.php') !== false){
					if($this->w3CombineGoogleFonts($match1)){
						$string = str_replace('@import '.$match.';','', $string);
					}elseif(!empty($this->settings['localize_google_fonts'])) {
						$cssUrl = $this->localizeGoogleFont($match1);
						if(!empty($cssUrl)){
							$string = str_replace('@import '.$match.';','@import url('.$cssUrl.')', $string);
						}
					}
				}else{
					$match1 = html_entity_decode($match1);
					$match_arr = $this->w3CustomParseUrl($match1);
					$match_arr['scheme'] = empty($match_arr['scheme']) ? 'https' : $match_arr['scheme'];
					$match_arr['query'] = empty($match_arr['query']) ? '' : '?'.$match_arr['query'];
					$match_arr['host'] = empty($match_arr['host']) ? $this->addSettings['siteUrlArr']['host'] : $match_arr['host'];
					$response = $this->w3RemoteGet($match_arr['scheme'].'://'.$match_arr['host'].$match_arr['path'].$match_arr['query']);
					if(!empty($response)){
						$string = str_replace('@import '.$match.';',$response, $string);
					}
				}
                continue;
			}
			$match1 = str_replace($this->addSettings['css_cdn_url'],$this->addSettings['siteUrl'],$match1);
			if($this->w3IsExternal($match1, [], 'css')){
                continue;
			}
			$match_arr = $this->w3CustomParseUrl($match1);
			if(substr($match1, 0, 1) == '/' || strpos($match1,'http') !== false){
				if($this->addSettings['isMultisiteSubDomain']){
					$match1 = file_exists($this->addSettings['documentRoot'].'/'.trim($match_arr['path'],'/')) ? $this->addSettings['network_site_url'].'/'.trim($match_arr['path'],'/') : $match1;
				}else{
					$match1 = file_exists($this->addSettings['documentRoot'].'/'.trim($match_arr['path'],'/')) ? $this->addSettings['siteUrl'].'/'.trim($match_arr['path'],'/') : $match1;
				}
				$import_match = $match1;
			}else{
				$match1 = $url_parent_url.'/'.trim($match_arr['path'],'/');
				$import_match = $url_parent_url.'/'.trim($match_arr['path'],'/');
				$match_arr = $this->w3CustomParseUrl($match1);
			}
			if(strpos($match1,'..') !== false){
				$match1 = $this->removeDotPathSegments($match1);
			}
			if(strpos($match1,'.css')!== false && strpos($string,'@import '.$match)!== false && $url != $this->addSettings['fullUrlWithoutParam'].'/index.php'){
                $string = str_replace('@import '.$match.';',$this->w3RelativeToAbsolutePath($this->removeDotPathSegments($import_match),$this->drupal_speederGetContents($this->removeDotPathSegments(str_replace($this->addSettings['siteUrl'],$this->addSettings['documentRoot'],$import_match)))), $string);
                continue;
			}
			$img_arr = explode('?',$match1 );
			$ext = '.'.pathinfo($img_arr[0], PATHINFO_EXTENSION);
			if($ext == '.'){
                continue;
			}
			list($img_root_path, $img_root_url) = $this->getImgRootPath($img_arr[0]);
			$webp_enable = $this->addSettings['webp_enable'];
			$imgsrc_filepath = $this->getResourceRootPath($match1, $img_root_url, $img_root_path);
			if($this->addSettings['is_mobile'] && !empty($this->settings['resp_bg_img']) && (strpos($url,'index.php') !== false || !empty($this->settings['separate_cache_for_mobile']) ) && strpos($imgsrc_filepath,$ext) !== false && file_exists(str_replace($ext,'-595xh'.$ext,$imgsrc_filepath))){
				$match1 = str_replace($ext,'-595xh'.$ext,$match1);
				$imgsrc_filepath = str_replace($ext,'-595xh'.$ext,$imgsrc_filepath);
			}
			$imgsrc_webpfilepath = $this->getImgWebpPath($img_root_path, $imgsrc_filepath);
			if(in_array($ext, $webp_enable) && !empty($imgsrc_webpfilepath)){
				if(file_exists($imgsrc_webpfilepath) && (!empty($this->addSettings['disable_htaccess_webp']) || !file_exists($this->addSettings['documentRoot']."/.htaccess") || $this->addSettings['image_cdn_url'] != $this->addSettings['siteUrl'] )){
					$match1 = $this->getResourceUrl($imgsrc_webpfilepath);
				}else{
					if(!empty($this->settings['opt_img_on_the_go'])){
						$response = $this->w3IncrementPrioritizedImg(str_replace($this->addSettings['siteUrl'],$this->addSettings['documentRoot'],$img_arr[0]));
					}
				}
			}
			if(substr($match1, 0, 1) == '/' || substr($match1, 0, 4) == 'http'){
				if($this->addSettings['image_cdn_url'] == $this->addSettings['siteUrl']){
					if($this->addSettings['isMultisiteSubDomain']){
						$match1 = str_replace($this->settings['network_site_url'],$this->settings['siteUrl'],$match1);
					}
					$replacement = 'url(\''.$match1.'\')';
				}
				else{
					$match_arr = $this->w3CustomParseUrl($match1);
					$replacement = 'url(\''.$this->addSettings['siteUrl'].'/'.trim($match_arr['path'],'/').'\')';
				}
			}else{
				if($this->addSettings['isMultisiteSubDomain']){
					$match1 = str_replace($this->settings['network_site_url'],$this->settings['siteUrl'],$match1);
				}
				$match_arr = $this->w3CustomParseUrl($match1);
				$replacement = 'url(\''.$url_parent_url.'/'.trim($match_arr['path'],'/').'\')';
			}
			if (in_array(strtolower($ext), array('.otf', '.ttf', '.woff', '.woff2', '.gtf', '.mmm', '.pea', '.tpf', '.ttc', '.wtf', '.eot', '.pfb', '.pfm', '.fon', '.fnt')) && $this->checkEnableCdn('font') && !$this->w3CheckExcludedPath($replacement, $this->addSettings['font_exclude_cdn_path'])) {
                $replacement  = str_replace($this->addSettings['siteUrlArr']['host'], $this->addSettings['fontUrlArr']['host'],$replacement );
            }
			if(in_array($ext, array('.jpeg', '.jpg', '.png', '.gif', '.webp', '.svg', '.tiff', '.psd', '.raw', '.bmp', '.heif', '.indd')) && $this->checkEnableCdn('image') && !$this->w3CheckExcludedPath($replacement, $this->addSettings['image_exclude_cdn_path'])){
				$replacement  = str_replace($this->addSettings['siteUrlArr']['host'], $this->addSettings['imageUrlArr']['host'],$replacement );
			}
			if(strpos($url,'index.php') !== false){
				$this->w3StrReplaceSetImg($org_match, $replacement);
			}else{
            	$string = str_replace($org_match, $replacement, $string);
			}
        }
		return $string;
	}
	
	function w3CreateFileCacheCss($path){
		$file_name = $this->w3GetOption('w3_rand_key',0);
		$new_path = $this->addSettings['css_ext'] != '.css' ? $this->rightReplace($path,'.css',$this->addSettings['css_ext']) : $path ;
        $cache_file_path = $this->w3GetCachePath('css').'/'.$file_name.'/'.ltrim($new_path,'/');
        if( !file_exists($cache_file_path) ){
			$css = $this->drupal_speederGetContents($this->addSettings['documentRoot'].$path);
			$css = str_replace(array('@charset "utf-8";','@charset "UTF-8";'),'',$css);
			
			if(function_exists('w3speedup_internal_css_customize')){
				$css = w3speedup_internal_css_customize($css,$path);
			}
			
			if(!empty($this->settings['hook_internal_css_customize'])){
				$code = str_replace(array('$css','$path'),array('$args[0]','$args[1]'),$this->settings['hook_internal_css_customize']);
				$css = $this->hookCallbackFunction($code,$css,$path);
			}
			$css = $this->w3RemoveCssComments($css);
			$minify = $this->w3RelativeToAbsolutePath($this->addSettings['siteUrl'].$path,$css);
			$css_minify = 1;
			if(function_exists('w3speedup_internal_css_minify')){
				$css_minify = w3speedup_internal_css_minify($path,$css);
			} 
			
			if(!empty($this->settings['hook_internal_css_minify'])){
				//$css_minify = $this->w3SpeedsterInternalCssMinify($css,$path,$css_minify);
				$code = str_replace(array('$css_minify','$css','$path'),array('$args[0]','$args[1]','$args[2]'),$this->settings['hook_internal_css_minify']);
				
				$css_minify = $this->hookCallbackFunction($code,$css_minify,$css,$path);
			}
			
			if($css_minify){
				$minify = $this->w3CssCompress($minify);
			}
			$this->w3CreateFile($cache_file_path, $minify);
		}
        if(!file_exists($cache_file_path)){
			return $path;
		}else{
			return str_replace($this->addSettings['rootCachePath'],'',$cache_file_path);
		}
    }
    
    function minifyCss($css_links){ 
		if(!empty($this->settings['exclude_page_from_load_combined_css']) && $this->w3CheckIfPageExcluded($this->settings['exclude_page_from_load_combined_css'])){
			return $this->html;
		}
		$combined_css_files = [];
		if(!empty($css_links) && !empty($this->settings['css'])){
			$excludeCssFromMinify = !empty($this->settings['exclude_css']) ? explode("\r\n", $this->settings['exclude_css']) : array();
			$excludeCssFromMinifyArr = array();
			foreach($excludeCssFromMinify as $key => $value){
				if(strpos($value,' 1') !== false){
					$excludeCssFromMinifyArr[$key]['string'] = str_replace(' 1','',$value);
					$excludeCssFromMinifyArr[$key]['cache'] = 1;
				}else{	
					$excludeCssFromMinifyArr[$key]['string'] = $value;
					$excludeCssFromMinifyArr[$key]['cache'] = 0;
				}
			}
			$force_lazyload_css	= !empty($this->settings['force_lazyload_css']) ? explode("\r\n", $this->settings['force_lazyload_css']) : array();
			$force_lazyload_css = function_exists('w3_customize_force_lazyload_css') ? w3_customize_force_lazyload_css($force_lazyload_css) : $force_lazyload_css;
			
			if(!empty($this->settings['hook_customize_force_lazy_css'])){
			$code = str_replace('$force_lazyload_css','$args[0]',$this->settings['hook_customize_force_lazy_css']);
			$force_lazyload_css = $this->hookCallbackFunction($code,$force_lazyload_css);
			}
			$enable_cdn = $this->checkEnableCdn('css');
			
			$css_links_arr = array();
			foreach($css_links as $key => $css){
				$css_obj = $this->w3ParseLink('link',str_replace($this->addSettings['css_cdn_url'],$this->addSettings['siteUrl'],$css));
				if( !empty($css_obj['rel']) && strpos($css_obj['rel'],'stylesheet') !== false && !empty($css_obj['href']) ){
					$css_obj['rel'] = 'stylesheet';
					$css_links_arr[] = array('arr'=>$css_obj,'css'=>$css);
				}elseif(empty($css_obj['rel'])){
					$css_links_arr[] = array('arr'=>array(),'css'=>$css);
				}
			}
			foreach($css_links_arr as $key => $link_arr){
				$css = $link_arr['css'];
				$css_obj = $link_arr['arr'];
				$enable_cdn_path = 0;
				if(!empty($css_obj['rel']) && $css_obj['rel'] == 'stylesheet' && !empty($css_obj['href'])){
					if(!empty($css_obj['media']) && strtolower($css_obj['media']) == 'print'){
						continue;
					}
					
					$org_css = '';
					$media = '';
					if($this->w3CheckEnableCdnPath($css_obj['href'], 'css')){
						$enable_cdn_path = 1;
					}
					$url_array = $this->w3ParseCssUrl($css_obj['href']);
					$url_array = $this->modifyCssUrlArray($url_array);
					if($this->checkCssExcluded($excludeCssFromMinifyArr, $css, $css_obj, $css_links_arr, $enable_cdn, $enable_cdn_path)){
						continue;
					}
					if($this->checkForceLazyLoad($force_lazyload_css,$css,$url_array,$css_obj,$link_arr, $enable_cdn, $enable_cdn_path)){
						continue;
					}
					if(!empty($css_obj['media']) && $css_obj['media'] != 'all' && $css_obj['media'] != 'screen'){
						$media = $css_obj['media'];
					}
					
					list($css_obj,$url_array,$return) = $this->getOptimizedCssUrl($css_obj,$url_array,$css, $enable_cdn, $enable_cdn_path);
					//$this->html .= "w3speed2".$css_obj['href'];
					//continue;
					if($return){
						continue;
					}
					$combined_css_files = $this->getCssCacheUrl($combined_css_files,$key,$css_obj,$url_array,$css, $enable_cdn, $enable_cdn_path);
				}
			}
			if(!empty($remove_css_tags)){
				foreach($remove_css_tags as $css){
					$this->w3StrReplaceSetCss($css,'');
				}
			}
			if(!$this->checkIgnoreCriticalCss()){
				if(is_array($combined_css_files) && count($combined_css_files) > 0){
					$this->addSettings['critical_css'] = $this->getCriticalCssFilename($combined_css_files);
				}
			}
			$all_inline_css = (!empty($this->settings['custom_css']) ? $this->w3CssCompress($this->getCustomCss()) : '');
			$this->w3InsertContentHead('<style id="w3_bg_load"></style><style>'.$this->excludeLazyLoadBackgroundImages().'</style><style id="drupal_speeder-custom-css">'.$all_inline_css.'</style>',4);
			$this->w3RenderCss($combined_css_files,$css_links_arr,0);
		}
		
	}
	function excludeLazyLoadBackgroundImages(){
		$exclusions = !empty($this->settings['exclude_background_lazy_load']) ? explode("\r\n", $this->settings['exclude_background_lazy_load']) : [];
		$content = [];
		$attrs = array('#','.');
		foreach($exclusions as $exclusion){
			foreach($attrs as $attr){
				if(strpos($exclusion,$attr) !== false){
					$exclusionArr = explode($attr,$exclusion);
					$content[$exclusionArr[0]][] = $exclusion;
				}
			}
		}
		$style = '';
		$tagnames = array(['div',''],['div','::before'],['div','::before'],['section',''],['section','::before'],['section','::after'],['iframelazy',''],['iframe','']);
		foreach($tagnames as $tagname){
			$style .= $tagname[0]."[data-BgLz=1]";
			if(!empty($content[$tagname[0]])){
				foreach($content[$tagname[0]] as $attr){
					$style .= ':not('.$attr.')';
				} 
			}
			$style .=$tagname[1].',';
		}
		return rtrim($style,',').'{background-image:none !important;}';
	}
	function getCssCacheUrl($combined_css_files,$key,$css_obj,$url_array,$css, $enable_cdn, $enable_cdn_path){
		$src = $css_obj['href'];
		if(!empty($src) && !$this->w3IsExternal($src, [], 'css') && $this->w3Endswith($src, '.css')){
			$filename = $this->addSettings['rootCachePath'].$url_array['path'];
			if(file_exists($filename) && filesize($filename) > 0){
				$combined_css_file = $this->w3GetResourceUrl($url_array['path'], $enable_cdn && $enable_cdn_path, 0, 'css');
				$this->w3StrReplaceSetCss($css,'{{'.$combined_css_file.'}}');
				$combined_css_files[$key] = $combined_css_file;
			} else {
				$filename  = $this->addSettings['content_path'].$url_array['path'];
				if(file_exists($filename) && filesize($filename) > 0){
					$url_array['path'] = $this->strReplaceFirst('/cache/w3-cache', '', $url_array['path']);
					$combined_css_file = $this->w3GetResourceUrl($url_array['path'], $enable_cdn && $enable_cdn_path, 0, 'css');
					$this->w3StrReplaceSetCss($css,'{{'.$combined_css_file.'}}');
					$combined_css_files[$key] = $combined_css_file;
				}
			}
		}elseif($this->w3Endswith($src, '.css') || strpos($src, '.css?')){
			$this->w3StrReplaceSetCss($css,'{{'.$css_obj['href'].'}}');
			$combined_css_files[$key] = $css_obj['href'];
		}
		return $combined_css_files;
	}
	function getOptimizedCssUrl($css_obj,$url_array,$css, $enable_cdn, $enable_cdn_path){
		$return = 0;
		if(!$this->w3IsExternal($css_obj['href'], [], 'css')){
			
			if($this->w3Endswith($css_obj['href'], '.php') || strpos($css_obj['href'], '.php?') !== false ){
				$url_array['path'] = $css_obj['href'];
				$css_obj['href'] = $this->addSettings['siteUrl'].$url_array['path'];
			}elseif(!file_exists($this->addSettings['documentRoot'].$url_array['path'])){
				if($this->w3Endswith($css_obj['href'], '.css') || strpos($css_obj['href'], '.css?') !== false ){
					$hrefUrl = $css_obj['href'];
					if(strpos($css_obj['href'],$this->addSettings['siteUrl']) === false){
						$hrefUrl = $this->addSettings['siteUrl'].'/'.ltrim($css_obj['href'],'/');
					}
					//$this->html .= "w3speed3".$hrefUrl.$this->addSettings['documentRoot'].$url_array['path'].'exists=0';
					$responsePath = $this->w3CreateFileCacheCssUrl($hrefUrl);
					if(!$responsePath){
						//$this->w3StrReplaceSetCss($css,'');
						$return = 0;
					}else{
						$url_array['path'] = $responsePath;
						$css_obj['href'] = $this->w3GetResourceUrl($url_array['path'], $enable_cdn && $enable_cdn_path, 0, 'css');
					}
				}
				
			}elseif(filesize($this->addSettings['documentRoot'].$url_array['path']) > 0){
				
				$url_array['path'] = $this->w3CreateFileCacheCss($url_array['path']);
				$css_obj['href'] = $this->w3GetResourceUrl($url_array['path'], $enable_cdn && $enable_cdn_path, 0, 'css');
				
			}else{
				if($this->w3Endswith($css_obj['href'], '.php') || strpos($css_obj['href'], '.php?') !== false || filesize($this->addSettings['documentRoot'].$url_array['path']) < 1 ){
					$this->w3StrReplaceSetCss($css,'');
				}
				$return = 1;
			}
		}
		if(!empty($css_obj['href']) && strpos($css_obj['href'],'fonts.googleapis.com') !== false){
			$response = $this->w3CombineGoogleFonts($css_obj['href']);
			if(!$response && !empty($this->settings['localize_google_fonts'])) {
				$cssArr = $this->localizeGoogleFonts(array($css_obj['href']));
				if(!empty($cssArr) && !empty($cssArr[0])){
					$css_obj['href'] = $url_array['path'] = str_replace($this->addSettings['siteUrl'],'',$cssArr[0]);
				}
			}elseif($response){
				$this->w3StrReplaceSetCss($css,'');
				$return = 1;
			}
			
		}
		
		return array($css_obj,$url_array,$return);
	}
	function checkCssExcluded($excludeCssFromMinifyArr, $css, $css_obj, $css_links_arr, $enable_cdn, $enable_cdn_path){
		$exclude_css = 0;
		if(!empty($excludeCssFromMinifyArr)){
			foreach($excludeCssFromMinifyArr as $ex_css){
				if(!empty($ex_css['string']) && strpos($css, $ex_css['string']) !== false){
					$exclude_css = 1;
					if(!empty($ex_css['cache'])){
						$cache_css = 1;
					}
				}
			}
		}
		if(function_exists('w3speedup_exclude_css_filter')){
			$exclude_css = w3speedup_exclude_css_filter($exclude_css,$script_obj,$script,$this->html);
		}
		if(!empty($this->settings['hook_exclude_css_filter'])){
			$code = str_replace(array('$exclude_css','$css_obj','$css','$html'),array('$args[0]','$args[1]','$args[2]','$args[3]'),$this->settings['hook_exclude_css_filter']);
			$exclude_css = $this->hookCallbackFunction($code,$exclude_css,$css_obj,$css,$this->html);
		}
		if($exclude_css){
			if($this->w3Endswith($css_obj['href'], '.css')){
				if(!empty($cache_css)){
					$url_array = $this->w3ParseCssUrl($css_obj['href']);
					$url_array['path'] = $this->w3CreateFileCacheCss($url_array['path']);
					$css_obj['href'] = $url_array['path'];
				}
				$css_obj['href'] = $this->w3GetResourceUrl($css_obj['href'], $enable_cdn && $enable_cdn_path, 1, 'css');
				$this->w3StrReplaceSetCss($css,'{{'.$css_obj['href'].'}}');
				$this->w3RenderCss(array($css_obj['href']),$css_links_arr, 1);
			}
			$this->addSettings['preload_resources']['all'][] = $css_obj['href'];
			return true;
		}
		return false;
	}
	
	function checkForceLazyLoad($force_lazyload_css,$css,$url_array,$css_obj,$link_arr, $enable_cdn, $enable_cdn_path){
		$force_lazy_load = 0;
		if(!empty($force_lazyload_css)){
			foreach($force_lazyload_css as $ex_css){
				if(!empty($ex_css) && strpos($css, $ex_css) !== false){
					$force_lazy_load = 1;
				}
			}
		}
		if($force_lazy_load){
			$path = $url_array['path'];
			list($css_obj,$url_array,$return) = $this->getOptimizedCssUrl($css_obj,$url_array,$css, $enable_cdn, $enable_cdn_path);
			$css_link = $this->getCssAttribute($link_arr['arr']);
			$this->w3StrReplaceSetCss($css,'<link data-href="'.$css_obj['href'].'"'.$css_link.'>');
			return true;
		}
		return false;
	}

	function modifyCssUrlArray($url_array){
		if(strpos($url_array['path'],'./') !== false || strpos($url_array['path'],'../') !== false){
			$url_array['path'] = $this->removeDotPathSegments($url_array['path']);
		}
		if(strpos($url_array['path'],'/version') !== false){
			$url_array['path'] = preg_replace('/version(\d)*\//', '', $url_array['path']);
		}
		if(strpos($this->addSettings['documentRoot'],'/pub') !== false && strpos($url_array['path'],'/pub') !== false){
			$url_array['path'] = str_replace('/pub/', '/', $url_array['path']);
		}
		return $url_array;
	}
	
	function w3RenderCss($combined_css_files,$css_links_arr, $exclude=0){
		if(!empty($combined_css_files) && is_array($combined_css_files)){
			foreach($combined_css_files as $key=>$css){
				$this->addSettings['preload_resources']['css'][] = $css;
				if(!empty($css_links_arr[$key]['arr']) && count((array)$css_links_arr[$key]['arr']) > 0){
					$css_link = '';
					$css_link = $this->getCssAttribute($css_links_arr[$key]['arr']);
				}
				$excludeCss = !$exclude ? ' data-css="1"' : '';
				$this->w3StrReplaceSetCss('{{'.$css.'}}','<link'.$excludeCss.' href="'.$css.'"'.$css_link.'>');
			}
		}
	}
	function getCssAttribute($cssArr){
		$css_link = '';
		foreach((array)$cssArr as $attr => $attr_value){
			if($attr != 'href' && $attr != 'data-href' && $attr != 'onload' && $attr != 'onerror' && $attr != 'type' && $attr != 'html' ){
				$css_link .= " $attr='$attr_value'";
			}
		}
		return $css_link;
	}
	function w3ParseCssUrl($css_href){
		$url_array = $this->w3CustomParseUrl(str_replace($this->addSettings['siteUrl'],'',$css_href));
		$url_array['path'] = !empty($url_array['path']) ? '/'.ltrim($url_array['path'],'/') : '';
		return $url_array;
	}
	function w3CreateFileCacheCssUrl($url){
		$parsedUrlArray = $this->w3ParseCssUrl($url);
		$cacheFilePath = $this->w3GetCachePath('css').'/'.ltrim($parsedUrlArray['path'], '/');
		if(!file_exists($cacheFilePath)){
			$css = $this->w3RemoteGet($url);
			if (empty($css)) {
				return false;
			}
			if(function_exists('w3speedup_internal_css_customize')){
				$css = w3speedup_internal_css_customize($css,$url);
			}
			$minify = $this->w3CssCompress($css);
			$this->w3CreateFile($cacheFilePath, $minify);
		}
		return str_replace($this->addSettings['rootCachePath'],'',$cacheFilePath);
	}
	
}