<?php

namespace DrupalSpeeder;

class ImageOptimize extends DrupalSpeeder
{

	public function __construct()
	{
		parent::__construct();
	}

	function w3OptimizeAttachment($image_url)
	{
		$optimize_image = !empty($this->settings['opt_jpg_png']) ? 1 : 0;
		$type = pathinfo($image_url, PATHINFO_EXTENSION);
		list($img_root_path, $img_root_url) = $this->getImgRootPath($image_url);
		$image_url_path = $this->getResourceRootPath($image_url, $img_root_url, $img_root_path);
		$image_size = @getimagesize($image_url_path) ?? [0, 0];
		$image_type = array('gif', 'jpg', 'png', 'jpeg', 'webp');
		$orgImgPath = $this->addSettings['w3OrgImgPath'] . str_replace($this->addSettings['uploadPath'], "", $image_url_path);

		if (!empty($this->settings['remove_org_img']) && $this->settings['remove_org_img'] == "on") {
			$removeOrg = true;
		} else {
			$removeOrg = false;
		}

		if ($optimize_image && in_array($type, $image_type) && !is_file($orgImgPath)) {
			if ($image_size[0] > 3000) {
				$return['img'] = 3;
				return $return;
			}
			$optmize_image = $this->optimizeImage($image_size[0], $image_url);
			if (function_exists('imagecreatefromstring')) {
				$optimize_image_size = @imagecreatefromstring($optmize_image);
			}
			if (empty($optimize_image_size)) {
				$return['img'] = 2;
			} else {
				if (!is_file($orgImgPath) && !$removeOrg) {
					$destinationFolder = dirname($orgImgPath);
					if (!file_exists($destinationFolder)) {
						$this->w3CreateFolder($destinationFolder);
					}
					@copy($image_url_path, $orgImgPath);
				}
				$this->w3DeleteFile($image_url_path);
				$this->w3CreateFile($image_url_path, $optmize_image);
				$return['img'] = 1;
			}
		} else {
			$return['img'] = 0;
		}
		return $return;
	}

	function w3OptimizeAttachmentWebp($image_url)
	{
		$type = pathinfo($image_url, PATHINFO_EXTENSION);
		list($img_root_path, $img_root_url) = $this->getImgRootPath($image_url);
		$image_url = str_replace('\\', '/', $image_url);
		$imgsrc_filepath = $this->getResourceRootPath($image_url, $img_root_url, $img_root_path);
		$image_size = @getimagesize($imgsrc_filepath) ?? [0, 0];
		$imgsrc_webpfilepath = $this->getImgWebpPath($img_root_path, $imgsrc_filepath);
		if (!file_exists($imgsrc_webpfilepath) && file_exists($imgsrc_filepath)) {
			$optmize_image = $this->optimizeImage($image_size[0], $image_url, 1);
			$this->w3CreateFile($imgsrc_webpfilepath, $optmize_image);
			if (filesize($imgsrc_webpfilepath) < 1024) {
				$this->w3DeleteFile($imgsrc_webpfilepath);
				$return['webp'] = 0;
			} else {
				$return['webp'] = 1;
			}
		}
	}
}
