<?php

namespace Drupal\drupal_speeder\EventSubscriber;

use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Response;

class DrupalSpeederSubscriber implements EventSubscriberInterface {

  public static function getSubscribedEvents(): array {
    return [
      KernelEvents::REQUEST  => ['onRequest', 0],
      KernelEvents::RESPONSE => ['onRespond', -10],
    ];
  }

  public function onRequest(RequestEvent $event): void {
    if (!$event->isMainRequest()) return;

    $this->defineConstants($event->getRequest());
    $this->loadCoreClasses();
    $this->copyAssetsIfNeeded();

    // Handle AJAX actions (authenticated users only)
    if (!empty($_REQUEST['action']) && \Drupal::currentUser()->isAuthenticated()) {
      $this->handleAction($_REQUEST['action']);
    }

    // Handle critical CSS save from front-end JS
    if (!empty($_REQUEST['dsPutPreloadCss'])) {
      $speeder = new \DrupalSpeeder\DrupalSpeeder();
      $speeder->w3PutPreloadCss();
      exit;
    }

    // Handle web vitals insert (public endpoint, no auth needed)
    if (!empty($_REQUEST['dsInsertWebVitals'])) {
      $speeder = new \DrupalSpeeder\DrupalSpeeder();
      echo $speeder->insertWebVitals();
      exit;
    }
  }

  public function onRespond(ResponseEvent $event): void {
    if (!$event->isMainRequest()) return;

    $response = $event->getResponse();
    if (!($response instanceof Response)) return;

    $request = $event->getRequest();
    $path    = $request->getPathInfo();

    // Never touch admin pages
    if (strpos($path, '/admin') === 0) return;
    // Never touch AJAX/action requests
    if (!empty($_REQUEST['action']) || !empty($_REQUEST['dsPutPreloadCss'])) return;
    // Never run on CLI (drush etc.)
    if (PHP_SAPI === 'cli') return;

    // Only process HTML
    $contentType = $response->headers->get('Content-Type', 'text/html');
    if (strpos($contentType, 'text/html') === false) return;

    // Skip for logged-in admins
    if (\Drupal::currentUser()->hasPermission('administer site configuration')) return;

    try {
      require_once DRUPAL_SPEEDER_PATH . '/includes/CssOptimize.php';
      require_once DRUPAL_SPEEDER_PATH . '/includes/JsOptimize.php';
      require_once DRUPAL_SPEEDER_PATH . '/includes/HtmlOptimize.php';
      $htmlOpt   = new \DrupalSpeeder\HtmlOptimize();
      $optimized = $htmlOpt->dsSpeedster($response->getContent());
      if (!empty($optimized)) {
        $response->setContent($optimized);
      }
    }
    catch (\Throwable $e) {
      // Never break the site on optimization error
      \Drupal::logger('drupal_speeder')->error('Optimization error: @msg', ['@msg' => $e->getMessage()]);
    }
  }

  // -------------------------------------------------------------------------
  // Private helpers
  // -------------------------------------------------------------------------

  private function defineConstants($request): void {
    if (!defined('DRUPAL_SPEEDER_PATH')) {
      define('DRUPAL_SPEEDER_PATH', dirname(__DIR__, 2));
    }
    if (!defined('DRUPAL_SPEEDER_DIR')) {
      define('DRUPAL_SPEEDER_DIR', dirname(__DIR__, 2) . '/');
    }
    if (!defined('DRUPAL_SPEEDER_WEB_PATH')) {
      $public = \Drupal::service('file_system')->realpath('public://');
      define('DRUPAL_SPEEDER_WEB_PATH', $public . '/drupal_speeder');
    }
    if (!defined('DRUPAL_SPEEDER_VERSION')) {
      define('DRUPAL_SPEEDER_VERSION', '1.0.0');
    }
    if (!defined('DRUPAL_SPEEDER_URL')) {
      $base = $request->getSchemeAndHttpHost() . base_path();
      define('DRUPAL_SPEEDER_URL', $base . 'sites/default/files/drupal_speeder/');
    }
    if (!defined('CURRENT_LOGGEDIN_USER')) {
      define('CURRENT_LOGGEDIN_USER', \Drupal::currentUser()->getDisplayName() ?? 'Anonymous');
    }
  }

  private function loadCoreClasses(): void {
    require_once DRUPAL_SPEEDER_PATH . '/includes/SpeedCore.php';
    require_once DRUPAL_SPEEDER_PATH . '/includes/DrupalSpeeder.php';
  }

  private function handleAction(string $action): void {
    $speeder = new \DrupalSpeeder\DrupalSpeeder();

    switch ($action) {
      case 'dsGetLogData':
        echo $speeder->w3SpeedsterGetLogData();
        exit;

      case 'dsDeleteLogData':
        echo $speeder->deleteWebVitals();
        exit;

      case 'dsShowUrlSuggestions':
        $speeder->w3SpeddsterShowUrlSuggestions();
        exit;

      case 'dsGetChangeLogData':
        $speeder->w3SpeedsterGetChangeLogData();
        exit;

      case 'dsDeleteChangeLogData':
        $speeder->w3SpeedsterDeleteChangeLogData();
        exit;

      case 'hookBeforeStartOptimization':
        $speeder->hookBeforeStartOptimization();
        exit;

      case 'ds_cache_purge':
        $speeder->w3RemoveCacheFilesHourlyEventCallback();
        $speeder->logSettingsChanges([['action' => 'JS/CSS Cache Flushed', 'old' => 'Cache', 'new' => 'Cleared']]);
        echo json_encode(['status' => 'success', 'message' => 'JS/CSS cache cleared successfully']);
        exit;

      case 'ds_html_cache_purge':
        $speeder->w3RemoveCacheFilesHourlyEventCallback();
        $htmlCachePath = DRUPAL_SPEEDER_WEB_PATH . '/cache/ds-cache/html';
        if (is_dir($htmlCachePath)) {
          $speeder->w3Rmdir($htmlCachePath);
        }
        $speeder->logSettingsChanges([['action' => 'HTML Cache Flushed', 'old' => 'Cache', 'new' => 'Cleared']]);
        echo json_encode(['status' => 'success', 'message' => 'HTML cache cleared successfully']);
        exit;

      case 'ds_critical_cache_purge':
        $speeder->w3RemoveCriticalCssCacheFiles();
        $speeder->logSettingsChanges([['action' => 'Critical CSS Cache Flushed', 'old' => 'Cache', 'new' => 'Cleared']]);
        echo json_encode(['status' => 'success', 'message' => 'Critical CSS cache cleared successfully']);
        exit;

      case 'ds_restore_original_images':
        $speeder->w3speedserRestoreOriginalImages();
        exit;

      case 'ds_optimize_image':
        echo $speeder->drupal_speederOptimizeImageCallback();
        exit;

      case 'ds_preload_css':
        echo $speeder->drupal_speederPreloadCss();
        exit;
    }
  }

  private function copyAssetsIfNeeded(): void {
    $source = DRUPAL_SPEEDER_DIR . 'assets';
    $dest   = DRUPAL_SPEEDER_WEB_PATH . '/assets';

    if (!is_dir($source)) return;

    // Use a version-based sentinel so any module update re-copies assets
    $sentinel     = DRUPAL_SPEEDER_WEB_PATH . '/.assets_copied';
    $version      = DRUPAL_SPEEDER_VERSION . '-' . filemtime($source);
    $storedVersion = file_exists($sentinel) ? trim(file_get_contents($sentinel)) : '';

    if ($storedVersion === $version) return;

    foreach ([DRUPAL_SPEEDER_WEB_PATH, $dest] as $dir) {
      if (!is_dir($dir)) @mkdir($dir, 0775, true);
    }

    $iter = new \RecursiveIteratorIterator(
      new \RecursiveDirectoryIterator($source, \RecursiveDirectoryIterator::SKIP_DOTS),
      \RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($iter as $item) {
      $rel = str_replace($source, '', $item->getPathname());
      $to  = $dest . $rel;
      if ($item->isDir()) {
        if (!is_dir($to)) @mkdir($to, 0775, true);
      } else {
        // Always overwrite — ensures updated JS/CSS/PHP files deploy correctly
        @copy($item->getPathname(), $to);
      }
    }
    @file_put_contents($sentinel, $version);
  }

}
