<?php

namespace Drupal\drupal_speeder\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;

class DrupalSpeederController extends ControllerBase {

  public function adminPage(): Response {
    $this->defineConstants();

    require_once DRUPAL_SPEEDER_PATH . '/includes/SpeedCore.php';
    require_once DRUPAL_SPEEDER_PATH . '/includes/DrupalSpeeder.php';
    require_once DRUPAL_SPEEDER_PATH . '/admin/AdminInit.php';

    $account = \Drupal::currentUser();
    if (!defined('CURRENT_LOGGEDIN_USER')) {
      define('CURRENT_LOGGEDIN_USER', $account->getDisplayName());
    }

    $admin = new \DrupalSpeeder\AdminInit();

    // ----------------------------------------------------------------
    // AJAX save: POST with _ajax_save=1 → save settings → return JSON
    // This avoids header()/ob_start() conflicts entirely
    // ----------------------------------------------------------------
    $request = \Drupal::request();
    $isAjaxSave = $request->request->get('_ajax_save') === '1';
    if ($isAjaxSave && $request->isMethod('POST')) {
      $nonce = $request->request->get('_w3nonce', '');
      if ($admin->checkSecurityKey($nonce, 'w3_settings')) {
        $admin->w3SaveOptions();
        // w3SaveOptions calls pageReload() which calls exit with JSON
        // If we reach here, ws_action wasn't 'cache' - return error
        return new JsonResponse(['success' => false, 'error' => 'Nothing to save']);
      }
      return new JsonResponse(['success' => false, 'error' => 'Security check failed']);
    }

    // ----------------------------------------------------------------
    // Normal page render
    // ----------------------------------------------------------------
    ob_start();
    $admin->launch();
    $output = ob_get_clean();

    $response = new Response($output);
    $response->headers->set('Content-Type', 'text/html; charset=UTF-8');
    return $response;
  }

  private function defineConstants(): void {
    if (!defined('DRUPAL_SPEEDER_PATH')) {
      define('DRUPAL_SPEEDER_PATH', dirname(__DIR__, 2));
    }
    if (!defined('DRUPAL_SPEEDER_DIR')) {
      define('DRUPAL_SPEEDER_DIR', dirname(__DIR__, 2) . '/');
    }
    if (!defined('DRUPAL_SPEEDER_WEB_PATH')) {
      $public = \Drupal::service('file_system')->realpath('public://');
      define('DRUPAL_SPEEDER_WEB_PATH', $public . '/drupal_speeder');
    }
    if (!defined('DRUPAL_SPEEDER_VERSION')) {
      define('DRUPAL_SPEEDER_VERSION', '1.0.0');
    }
    if (!defined('DRUPAL_SPEEDER_URL')) {
      $req      = \Drupal::request();
      $base_url = $req->getSchemeAndHttpHost() . base_path();
      define('DRUPAL_SPEEDER_URL', $base_url . 'sites/default/files/drupal_speeder/');
    }
  }

}
