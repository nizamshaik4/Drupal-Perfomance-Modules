<?php
/**
 * Drupal Speeder Admin Entry Point
 * Included via DrupalSpeeder::includeHeader()
 */
$drupal_speeder_admin = $this;
$drupal_speeder = $this;
?>
<script>
var ds_html_cache_purge = '<?php echo $this->createSecureKey('ds_html_cache_purge');?>';
var ds_cache_purge = '<?php echo $this->createSecureKey('ds_cache_purge');?>';
var ds_critical_cache_purge = '<?php echo $this->createSecureKey('ds_critical_cache_purge');?>';
</script>
<?php include __DIR__ . "/admin.php"; ?>
