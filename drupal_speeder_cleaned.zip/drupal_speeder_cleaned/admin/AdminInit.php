<?php
namespace DrupalSpeeder;

class AdminInit extends DrupalSpeeder
{
    function launch()
    {
        // Handle settings import
        if (!empty($_POST['import_text']) && isset($_POST['_w3nonce']) && $this->checkSecurityKey($_POST['_w3nonce'], 'w3_settings_import')) {
            $this->importData($_POST['import_text']);
        }

        // Handle settings save - works on the new admin path
        if (isset($_POST['_w3nonce']) && $this->checkSecurityKey($_POST['_w3nonce'], 'w3_settings')) {
            $this->w3SaveOptions();
            // w3SaveOptions calls pageReload() which calls exit, so we never reach here
            // unless ws_action was not 'cache' - in that case just fall through and render
        }

        // Render the admin page
        $this->includeHeader();
    }

    function w3SaveOptions()
    {
        if (isset($_POST['ws_action']) && $_POST['ws_action'] == 'cache') {
            unset($_POST['ws_action'], $_POST['temp_input']);
            $keysToCheck = [
                'preload_resources', 'exclude_lazy_load', 'exclude_pages_from_optimization',
                'exclude_css', 'force_lazyload_css', 'load_style_tag_in_head',
                'exclude_page_from_load_combined_css', 'exclude_javascript',
                'force_lazy_load_inner_javascript', 'exclude_inner_javascript',
                'exclude_page_from_load_combined_js', 'load_script_tag_in_url',
                'exclude_url_html_cache', 'exclude_url_exclusions_html_cache',
                'exclude_background_lazy_load', 'exclude_both_javascript'
            ];
            $oldSettings = $this->settings;
            $newSettings = [];
            foreach ($_POST as $key => $value) {
                if (in_array($key, $keysToCheck)) {
                    if ($key === "preload_resources") {
                        $value = str_replace('####', 'https', $value);
                        $value = str_replace('###', 'http', $value);
                    }
                    $newSettings[$key] = implode("\r\n", (array)$value);
                } else {
                    $newSettings[$key] = $value;
                }
            }

            // Remove license key logic entirely - always treat as activated
            $newSettings['is_activated'] = 'yes';
            unset($newSettings['license_key']);

            $changes = [];
            foreach ($oldSettings as $key => $value) {
                if (!array_key_exists($key, $newSettings)) {
                    $newSettings[$key] = '';
                }
            }
            foreach ($newSettings as $key => $value) {
                if ((!isset($oldSettings[$key]) || $oldSettings[$key] != $value) && $key != "_w3nonce") {
                    $action    = empty($this->getActionHeading($key)) ? $key : $this->getActionHeading($key);
                    $changes[] = [
                        'action' => $action,
                        'new'    => !empty($value) ? $value : 'Not Set',
                        'old'    => !empty($oldSettings[$key]) ? $oldSettings[$key] : 'Not Set',
                    ];
                }
            }
            if (!empty($changes)) {
                $this->logSettingsChanges($changes);
            }

            if (!empty($newSettings['html_caching']) && !empty($newSettings['by_serve_cache_file']) && $newSettings['by_serve_cache_file'] == 'htaccess'
                && (empty($oldSettings['by_serve_cache_file']) || $oldSettings['by_serve_cache_file'] != 'htaccess' || empty($oldSettings['html_caching']))) {
                $this->htaccessModifyKeys['html_cache'] = 1;
            }
            if (!empty($newSettings['gzip']) && (empty($oldSettings['gzip']) || $oldSettings['gzip'] != $newSettings['gzip'])) {
                $this->htaccessModifyKeys['gzip'] = 1;
            }
            if (!empty($newSettings['lbc']) && (empty($oldSettings['lbc']) || $oldSettings['lbc'] != $newSettings['lbc'])) {
                $this->htaccessModifyKeys['lbc'] = 1;
            }
            if ((!empty($newSettings['webp_png']) && empty($oldSettings['webp_png'])) || (!empty($newSettings['webp_jpg']) && empty($oldSettings['webp_jpg']))) {
                $this->htaccessModifyKeys['webp'] = 1;
            }

            $this->w3UpdateOption('ds_speedup_option', $newSettings, 'no');
            $this->settings = $this->w3GetOption('ds_speedup_option', true);
            $this->checkHtmlCacheSettings();
            $this->pageReload();
        }
    }

    function w3SpeedsterCachePurgeCallback()
    {
        if (!isset($this->addSettings['w3_get']['_w3nonce']) || !$this->checkSecurityKey($this->addSettings['w3_get']['_w3nonce'], 'purge_cache')) {
            echo 'Request not valid'; exit;
        }
        $drupal_speeder_init = new DrupalSpeeder();
        $response            = round((int) $drupal_speeder_init->w3RemoveCacheFilesHourlyEventCallback(), 2);
        echo $this->esc_html($response);
        exit;
    }

    function w3SpeedsterHtmlCachePurgeCallback()
    {
        if (isset($this->addSettings['w3_get']['_w3nonce']) && $this->checkSecurityKey($this->addSettings['w3_get']['_w3nonce'], 'purge_html_cache')) {
            if (function_exists('exec')) {
                exec('rm -rf ' . $this->w3GetCachePath() . '/html', $output, $retval);
                echo 'Cache Delete Successfully';
            }
        }
        exit;
    }
}
