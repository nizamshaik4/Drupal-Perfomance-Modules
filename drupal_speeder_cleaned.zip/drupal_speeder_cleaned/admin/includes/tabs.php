<?php
// Drupal Speeder - Sidebar Navigation
$nav_sections = [
    'main' => [
        ['section' => 'general',        'label' => 'General',           'icon' => 'fa-cog',         'tab' => ''],
        ['section' => 'htmlCache',      'label' => 'HTML Cache',        'icon' => 'fa-database',    'tab' => 'htmlCache'],
        ['section' => 'w3-cdn',         'label' => 'CDN',               'icon' => 'fa-cloud',       'tab' => 'w3-cdn'],
        ['section' => 'opt_img',        'label' => 'Image Optimization','icon' => 'fa-picture-o',   'tab' => 'opt_img'],
        ['section' => 'css',            'label' => 'CSS',               'icon' => 'fa-paint-brush', 'tab' => 'css'],
        ['section' => 'js',             'label' => 'JavaScript',        'icon' => 'fa-code',        'tab' => 'js'],
    ],
    'advanced' => [
        ['section' => 'exclusions',     'label' => 'Exclusions',        'icon' => 'fa-filter',      'tab' => 'exclusions'],
        ['section' => 'w3_custom_code', 'label' => 'Custom Code',       'icon' => 'fa-terminal',    'tab' => 'w3_custom_code'],
        ['section' => 'hooks',          'label' => 'Hooks',             'icon' => 'fa-plug',        'tab' => 'hooks'],
    ],
    'tools' => [
        ['section' => 'cache',          'label' => 'Clear Cache',       'icon' => 'fa-trash-o',     'tab' => 'cache'],
        ['section' => 'webvitalslogs',  'label' => 'Web Vitals',        'icon' => 'fa-line-chart',  'tab' => 'webvitalslogs'],
        ['section' => 'import',         'label' => 'Import / Export',   'icon' => 'fa-exchange',    'tab' => 'import'],
        ['section' => 'w3ChangeLog',    'label' => 'Change Log',        'icon' => 'fa-history',     'tab' => 'w3ChangeLog'],
    ],
];

$section_labels = ['main' => 'Optimization', 'advanced' => 'Advanced', 'tools' => 'Tools'];

foreach ($nav_sections as $group => $items) {
    if (!empty($result['manage_site_separately']) && $group !== 'main') continue;

    echo '<div class="ds-nav-section">' . htmlspecialchars($section_labels[$group]) . '</div>' . "\n";

    foreach ($items as $item) {
        if (!empty($result['manage_site_separately']) && $item['section'] !== 'general') continue;

        $is_active = ($item['tab'] === '' && (empty($tab) || $tab === 'general'))
            || ($item['tab'] !== '' && $tab === $item['tab']);

        echo '<a class="ds-nav-item' . ($is_active ? ' active' : '') . '" '
           . 'href="javascript:void(0)" '
           . 'data-section="' . htmlspecialchars($item['section']) . '">';
        echo '<span class="ds-nav-icon"><i class="fa ' . $item['icon'] . '"></i></span>';
        echo '<span class="ds-nav-label">' . htmlspecialchars($item['label']) . '</span>';
        echo '</a>' . "\n";
    }

    echo '<div class="ds-nav-divider"></div>' . "\n";
}
?>
