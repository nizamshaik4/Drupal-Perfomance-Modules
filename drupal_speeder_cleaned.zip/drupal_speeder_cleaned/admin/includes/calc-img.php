<div class="w3d-flex gap20 <?php echo $hidden_class; ?>">
    <label><?php $admin->translate('Upload Directory Path for Images'); ?><span
            class="w3info"></span><span
            class="w3info-display"><?php $admin->translate('Specify the upload directory path for images, which is utilized during the image optimization process.'); ?></span></label>
    <div class="input_box">
        <input type="text" name="image_upload_directory"
            value="<?php echo !empty($result['image_upload_directory']) ? $admin->esc_attr($result['image_upload_directory']) : $admin->addSettings['content_path']; ?>"
            id="image_upload_directory" placeholder="<?= $admin->addSettings['content_path']; ?>">
    </div>
</div>
<button class="btn" id="calculate_images" type="button">Calculate Images</button>
<script>
    let calculate_images_btn = document.getElementById('calculate_images');
    calculate_images_btn.addEventListener('click', function() {
        let currentUrl = window.location.href;
        if (currentUrl.indexOf('calc_images=1') === -1) {
            if (currentUrl.indexOf('?') === -1) {
                window.location.href = currentUrl + '?calc_images=1';
            } else {
                window.location.href = currentUrl + '&calc_images=1';
            }
        }else{
            window.location.reload();
        }
    });
</script>
<hr>