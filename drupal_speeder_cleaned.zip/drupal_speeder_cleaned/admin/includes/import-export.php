<section id="import" class="tab-pane fade<?php echo $tab == 'import' ? ' active in' : ''; ?>">
	<div class="header w3d-flex gap20">
		<div class="heading_container">
			<h4 class="w3heading">
				<?php $admin->translate('Import / Export'); ?>
			</h4>
		</div>
		<div class="icon_container"> <img
				src="<?php echo DRUPAL_SPEEDER_URL; ?>assets/images/import-export-icon.webp"></div>
	</div>
	<hr>
	<div class="import_form">
		<label><?php $admin->translate('Import Settings'); ?><span class="w3info"></span><span
				class="w3info-display"><?php $admin->translate('Enter exported json code from DrupalSpeeder plugin import/export page'); ?></span></label>
		<textarea  form="import_form" id="import_text" name="import_text" rows="10" cols="16"
			placeholder="<?php $admin->translate('Enter json code'); ?>"></textarea>
		<input form="import_form" type="hidden" name="_w3nonce"
			value="<?php echo $admin->createSecureKey('w3_settings_import'); ?>">
		<button form="import_form" id="import_button" class="btn"
			type="button"><?php $admin->translate('Import'); ?></button>
	</div>
	<?php
	$export_setting = $result;
	$export_setting['license_key'] = '';
	$export_setting['is_activated'] = '';
	?>

	<hr>
	<div class="import_form">
		<label><?php $admin->translate('Export Settings'); ?><span class="w3info"></span><span
				class="w3info-display"><?php $admin->translate('Copy the code and save it in a file for future use'); ?></span></label>
		<textarea rows="10" cols="16"><?php if (!empty($export_setting))
											echo $admin->w3JsonEncode($export_setting); ?></textarea>
	</div>
</section>