<?php
// General Settings Tab - License key removed
?>
<section id="general" class="tab-pane fade<?php echo empty($tab) || $tab == 'general' ? ' active in' : ''; ?>">
  <div class="ds-section-header">
    <div class="ds-section-icon"><i class="fa fa-cog"></i></div>
    <div>
      <h2 class="ds-section-title"><?php $admin->translate('General Settings'); ?></h2>
      <p class="ds-section-desc"><?php $admin->translate('Core optimization controls for your Drupal site.'); ?></p>
    </div>
  </div>

  <input type="hidden" name="is_activated" value="yes">
  <input type="hidden" name="_w3nonce" value="<?php echo $admin->createSecureKey('w3_settings'); ?>">
  <input type="hidden" name="ws_action" value="cache">

  <?php if ($networkAdmin): ?>
  <div class="ds-card">
    <div class="ds-setting-row">
      <div class="ds-setting-info">
        <label class="ds-setting-label"><?php $admin->translate('Manage Each Site Separately'); ?></label>
        <span class="ds-setting-desc"><?php $admin->translate('Enable separate settings for each site in multisite.'); ?></span>
      </div>
      <label class="ds-toggle">
        <input type="checkbox" name="manage_site_separately" <?php if (!empty($result['manage_site_separately']) && $result['manage_site_separately'] == "on") echo "checked"; ?>>
        <span class="ds-toggle-slider"></span>
      </label>
    </div>
  </div>
  <?php endif; ?>

  <!-- Way to 95+ PSI -->
  <div class="ds-card ds-card-accent <?php echo $hidden_class; ?>">
    <div class="ds-card-header-collapsible" data-ds-toggle="ds-psi-body">
      <div class="ds-card-header-left">
        <i class="fa fa-tachometer ds-accent-icon"></i>
        <div>
          <h3 class="ds-card-title"><?php $admin->translate('Way to 95+ in Google PSI'); ?></h3>
          <p class="ds-card-subtitle"><?php $admin->translate('Quick presets to achieve top PageSpeed scores'); ?></p>
        </div>
      </div>
      <i class="fa fa-chevron-down ds-chevron"></i>
    </div>
    <div id="ds-psi-body" class="ds-card-body">
      <div class="ds-settings-grid">

        <div class="ds-setting-row">
          <div class="ds-setting-info">
            <label class="ds-setting-label"><?php $admin->translate('Basic Settings'); ?></label>
            <span class="ds-setting-desc"><?php $admin->translate('Enable all basic optimization settings at once.'); ?></span>
          </div>
          <label class="ds-toggle">
            <input type="checkbox" name="main-basic-setting" id="main-basic-settings"
              <?php if (!empty($result['main-basic-setting'])) echo "checked"; ?>
              data-class="basic-set" class="basic-set-checkbox">
            <span class="ds-toggle-slider"></span>
          </label>
        </div>

        <div class="ds-setting-row">
          <div class="ds-setting-info">
            <label class="ds-setting-label"><?php $admin->translate('Optimize Images & Convert to WebP'); ?></label>
            <span class="ds-setting-desc"><?php $admin->translate('Compress and convert images to modern WebP format.'); ?></span>
          </div>
          <div class="ds-setting-control">
            <?php if (!empty($result['main-opt-img'])):
              $image_percentage = number_format((100 - ($img_remaining / $img_to_opt * 100)), 1);
              $no_animation_class = ($image_percentage == 100) ? 'no-animate' : '';
            ?>
            <div class="ds-progress-ring <?php echo $no_animation_class; ?>">
              <span><?php echo $image_percentage; ?>%</span>
            </div>
            <?php endif; ?>
            <label class="ds-toggle">
              <input type="checkbox" name="main-opt-img" id="optimize-images-and-convert-images-to-webp"
                <?php if (!empty($result['main-opt-img'])) echo "checked"; ?>
                data-class="main-opt-img" class="basic-set-checkbox">
              <span class="ds-toggle-slider"></span>
            </label>
          </div>
        </div>

        <div class="ds-setting-row">
          <div class="ds-setting-info">
            <label class="ds-setting-label"><?php $admin->translate('Lazyload Resources'); ?></label>
            <span class="ds-setting-desc"><?php $admin->translate('Defer off-screen images and iframes until needed.'); ?></span>
          </div>
          <label class="ds-toggle">
            <input type="checkbox" name="main-lazy-image" id="lazyload-images"
              <?php if (!empty($result['main-lazy-image'])) echo "checked"; ?>
              data-class="lazy-reso" class="basic-set-checkbox">
            <span class="ds-toggle-slider"></span>
          </label>
        </div>

        <div class="ds-setting-row">
          <div class="ds-setting-info">
            <label class="ds-setting-label"><?php $admin->translate('Responsive Images'); ?></label>
            <span class="ds-setting-desc"><?php $admin->translate('Serve smaller images on mobile devices.'); ?></span>
          </div>
          <label class="ds-toggle">
            <input type="checkbox" name="main-resp-img" id="responsive-images"
              <?php if (!empty($result['main-resp-img'])) echo "checked"; ?>
              data-class="resp-img" class="basic-set-checkbox">
            <span class="ds-toggle-slider"></span>
          </label>
        </div>

        <div class="ds-setting-row">
          <div class="ds-setting-info">
            <label class="ds-setting-label"><?php $admin->translate('Optimize CSS'); ?></label>
            <span class="ds-setting-desc"><?php $admin->translate('Enable CSS optimization and critical CSS generation.'); ?></span>
          </div>
          <div class="ds-setting-control">
            <?php if (!empty($result['main-opt-css'])):
              $percent_basic = $preload_created > 0 ? number_format((($preload_created / $preload_total * 100)), 1) : 1;
              $no_animation_class = ($percent_basic == 100) ? 'no-animate' : '';
            ?>
            <div class="ds-progress-ring <?php echo $no_animation_class; ?>">
              <span><?php echo $percent_basic; ?>%</span>
            </div>
            <?php endif; ?>
            <label class="ds-toggle">
              <input type="checkbox" name="main-opt-css" id="optimize-css"
                <?php if (!empty($result['main-opt-css'])) echo "checked"; ?>
                data-class="opt-css" class="basic-set-checkbox">
              <span class="ds-toggle-slider"></span>
            </label>
          </div>
        </div>

        <div class="ds-setting-row">
          <div class="ds-setting-info">
            <label class="ds-setting-label"><?php $admin->translate('Lazyload JavaScript'); ?></label>
            <span class="ds-setting-desc"><?php $admin->translate('Defer JS execution to speed up page rendering.'); ?></span>
          </div>
          <label class="ds-toggle">
            <input type="checkbox" name="main-lazy-js" id="lazyload-javascript"
              <?php if (!empty($result['main-lazy-js'])) echo "checked"; ?>
              data-class="opt-js" class="basic-set-checkbox">
            <span class="ds-toggle-slider"></span>
          </label>
        </div>

      </div>
    </div>
  </div>

  <!-- Core Optimization Settings -->
  <div class="ds-card <?php echo $hidden_class; ?>">
    <div class="ds-card-header">
      <i class="fa fa-sliders"></i>
      <h3><?php $admin->translate('Core Optimization'); ?></h3>
    </div>
    <div class="ds-card-body">
      <div class="ds-settings-grid">

        <div class="ds-setting-row">
          <div class="ds-setting-info">
            <label class="ds-setting-label" for="turn-on-optimization"><?php $admin->translate('Enable Optimization'); ?></label>
            <span class="ds-setting-desc"><?php $admin->translate('Master switch — applies all optimization settings to your site.'); ?></span>
          </div>
          <label class="ds-toggle">
            <input type="checkbox" name="optimization_on" id="turn-on-optimization" class="basic-set"
              <?php if (!empty($result['optimization_on']) && $result['optimization_on'] == "on") echo "checked"; ?>>
            <span class="ds-toggle-slider"></span>
          </label>
        </div>

        <div class="ds-setting-row <?php echo $hidden_class; ?>">
          <div class="ds-setting-info">
            <label class="ds-setting-label" for="optimize-pages-with-query-parameters"><?php $admin->translate('Optimize Pages with Query Parameters'); ?></label>
            <span class="ds-setting-desc"><?php $admin->translate('Optimize URLs with query strings. Recommended for high-performance servers.'); ?></span>
          </div>
          <label class="ds-toggle">
            <input type="checkbox" name="optimize_query_parameters" id="optimize-pages-with-query-parameters" class="basic-set"
              <?php if (!empty($result['optimize_query_parameters'])) echo "checked"; ?>>
            <span class="ds-toggle-slider"></span>
          </label>
        </div>

        <div class="ds-setting-row <?php echo $hidden_class; ?>">
          <div class="ds-setting-info">
            <label class="ds-setting-label" for="optimize-pages-when-user-logged-in"><?php $admin->translate('Optimize Pages when User is Logged In'); ?></label>
            <span class="ds-setting-desc"><?php $admin->translate('Apply optimization for authenticated users. Use with caution on high-performance servers.'); ?></span>
          </div>
          <label class="ds-toggle">
            <input type="checkbox" name="optimize_user_logged_in" id="optimize-pages-when-user-logged-in"
              <?php if (!empty($result['optimize_user_logged_in'])) echo "checked"; ?>>
            <span class="ds-toggle-slider"></span>
          </label>
        </div>

        <div class="ds-setting-row <?php echo $hidden_class; ?>">
          <div class="ds-setting-info">
            <label class="ds-setting-label" for="separate-css-cache-for-mobile"><?php $admin->translate('Separate CSS Cache for Mobile'); ?></label>
            <span class="ds-setting-desc"><?php $admin->translate('Generate separate CSS cache for mobile visitors.'); ?></span>
          </div>
          <label class="ds-toggle">
            <input type="checkbox" name="separate_cache_for_mobile" id="separate-css-cache-for-mobile" class="resp-img"
              <?php if (!empty($result['separate_cache_for_mobile'])) echo "checked"; ?>>
            <span class="ds-toggle-slider"></span>
          </label>
        </div>

        <div class="ds-setting-row <?php echo $hidden_class; ?>">
          <div class="ds-setting-info">
            <label class="ds-setting-label" for="enable-inp"><?php $admin->translate('Fix INP Issues'); ?></label>
            <span class="ds-setting-desc"><?php $admin->translate('Fix Interaction to Next Paint issues reported in Google PageSpeed and Search Console.'); ?></span>
          </div>
          <label class="ds-toggle">
            <input type="checkbox" name="enable_inp" id="enable-inp"
              <?php if (!empty($result['enable_inp']) && $result['enable_inp'] == "on") echo "checked"; ?>>
            <span class="ds-toggle-slider"></span>
          </label>
        </div>

      </div>
    </div>
  </div>

  <div class="ds-save-bar <?php echo $hidden_class; ?>">
    <button type="button" class="ds-btn ds-btn-primary hook_submit">
      <i class="fa fa-save"></i> <?php $admin->translate('Save Changes'); ?>
    </button>
    <div class="save-changes-loader ds-saving-indicator" style="display:none">
      <i class="fa fa-spinner fa-spin"></i> <?php $admin->translate('Saving...'); ?>
    </div>
  </div>
</section>
