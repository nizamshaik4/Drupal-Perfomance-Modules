<?php
$admin  = $drupal_speeder_admin ?? $drupal_speeder ?? null;
if (!$admin) return;
$result = $admin->settings;
if (empty($result['by_serve_cache_file'])) {
    $result['by_serve_cache_file'] = ($admin->addSettings['serverType'] ?? '') === 'apache' ? 'htaccess' : 'advanceCache';
}
// Ensure is_activated is always set (no license needed)
$result['is_activated'] = 'yes';

$tab            = !empty($_GET['tab']) ? $_GET['tab'] : '';
list($img_to_opt, $img_remaining)      = $admin->getImageOptimizationDetails();
list($preload_total, $preload_created) = $admin->w3CriticalCssDetails();
$networkAdmin   = 0;
$hidden_class   = '';
$dsFolderErrors = $admin->checkW3FolderPermissionErrors();

// Admin page URL (new route)
$admin_page_url = '/admin/config/development/drupal-speeder';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Drupal Speeder &mdash; Speed Optimization</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo DRUPAL_SPEEDER_URL; ?>assets/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo DRUPAL_SPEEDER_URL; ?>assets/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="<?php echo DRUPAL_SPEEDER_URL; ?>assets/css/jquery-ui.css">
<link rel="stylesheet" href="<?php echo DRUPAL_SPEEDER_URL; ?>assets/css/select2.min.css">
<link rel="stylesheet" href="<?php echo DRUPAL_SPEEDER_URL; ?>assets/css/codemirror.min.css">
<link rel="stylesheet" href="<?php echo DRUPAL_SPEEDER_URL; ?>assets/css/ds-admin.css">
<script src="<?php echo DRUPAL_SPEEDER_URL; ?>assets/js/jquery.min.js"></script>
<script src="<?php echo DRUPAL_SPEEDER_URL; ?>assets/js/jquery.dataTables.min.js"></script>
<script src="<?php echo DRUPAL_SPEEDER_URL; ?>assets/js/prefixfree.min.js"></script>
<script src="<?php echo DRUPAL_SPEEDER_URL; ?>assets/js/jquery-ui.js"></script>
<script src="<?php echo DRUPAL_SPEEDER_URL; ?>assets/js/select2.min.js"></script>
<script src="<?php echo DRUPAL_SPEEDER_URL; ?>assets/js/codemirror.min.js"></script>
<script src="<?php echo DRUPAL_SPEEDER_URL; ?>assets/js/diff.min.js"></script>
<script src="<?php echo DRUPAL_SPEEDER_URL; ?>assets/js/codemirror.javascript.min.js"></script>
<script src="<?php echo DRUPAL_SPEEDER_URL; ?>assets/js/ds-admin-core.js?ver=<?php echo DRUPAL_SPEEDER_VERSION; ?>"></script>
<script src="<?php echo DRUPAL_SPEEDER_URL; ?>assets/js/ds-custom.js?ver=<?php echo DRUPAL_SPEEDER_VERSION; ?>"></script>
<script>
var adminUrl  = "<?php
  $req = \Drupal::request();
  echo htmlspecialchars($req->getSchemeAndHttpHost() . base_path());
?>";
var secureKey = "<?php echo $admin->createSecureKey('hook_callback'); ?>";
var ds_html_cache_purge    = '<?php echo $admin->createSecureKey('ds_html_cache_purge'); ?>';
var ds_cache_purge         = '<?php echo $admin->createSecureKey('ds_cache_purge'); ?>';
var ds_critical_cache_purge = '<?php echo $admin->createSecureKey('ds_critical_cache_purge'); ?>';
var dsAdminUrl = "<?php echo htmlspecialchars($admin_page_url); ?>";
</script>
</head>
<body class="ds-admin-body">
<div id="ds-wrapper">
  <!-- Sidebar -->
  <aside id="ds-sidebar">
    <div class="ds-logo-area">
      <div class="ds-logo-icon"><i class="fa fa-rocket"></i></div>
      <div class="ds-logo-text">Drupal Speeder<small>v<?php echo DRUPAL_SPEEDER_VERSION; ?> &bull; Drupal 10+</small></div>
    </div>
    <nav class="ds-nav"><?php include __DIR__ . '/includes/tabs.php'; ?></nav>
  </aside>

  <!-- Main Content -->
  <div id="ds-main">
    <div id="ds-topbar">
      <div class="ds-topbar-left">
        <button class="ds-mobile-toggle" id="ds-mobile-toggle"><i class="fa fa-bars"></i></button>
        <div class="ds-topbar-title">
          <i class="fa fa-rocket ds-title-icon"></i>
          <span id="ds-page-title">Drupal Speeder</span>
        </div>
      </div>
      <div class="ds-topbar-actions">
        <a href="<?php echo $admin_page_url; ?>?clear-cache=1" class="ds-btn ds-btn-outline ds-btn-sm" title="Clear all caches">
          <i class="fa fa-refresh"></i> <span>Clear Cache</span>
        </a>
      </div>
    </div>

    <div id="ds-content">
      <div id="ds-toast-container"></div>

      <?php if (!empty($dsFolderErrors)): ?>
      <div class="ds-alert ds-alert-danger">
        <i class="fa fa-exclamation-triangle"></i>
        <div><strong>Permission Error</strong> &mdash; Unable to create: <?php echo implode(', ', array_map('htmlspecialchars', $dsFolderErrors)); ?></div>
      </div>
      <?php endif; ?>

      <form method="post" action="<?php echo htmlspecialchars($admin_page_url); ?>" class="main-form">
        <?php if (method_exists($admin, 'userProfileData')) $admin->userProfileData(); ?>
        <div class="tab-content">
          <?php include __DIR__ . '/includes/general.php'; ?>
          <?php include __DIR__ . '/includes/html-cache.php'; ?>
          <?php include __DIR__ . '/includes/cdn.php'; ?>
          <?php include __DIR__ . '/includes/opt-img.php'; ?>
          <?php include __DIR__ . '/includes/css.php'; ?>
          <?php include __DIR__ . '/includes/js.php'; ?>
          <?php include __DIR__ . '/includes/exclusions.php'; ?>
          <?php include __DIR__ . '/includes/ds-custom-code.php'; ?>
          <?php include __DIR__ . '/includes/cache.php'; ?>
          <?php include __DIR__ . '/includes/hooks.php'; ?>
          <?php include __DIR__ . '/includes/webvital-logs.php'; ?>
          <?php include __DIR__ . '/includes/import-export.php'; ?>
          <?php include __DIR__ . '/includes/change-log.php'; ?>
        </div>
      </form>
      <form id="import_form" method="post" action="<?php echo htmlspecialchars($admin_page_url); ?>"></form>
    </div>
  </div>
</div>

<script>
// Show toasts for any queued errors/messages
<?php $errors = $admin->w3GetErrors(); foreach ($errors as $value): ?>
if (typeof dsShowToast === 'function') dsShowToast('<?php echo $value['type'] ?? 'info'; ?>', '<?php echo addslashes($value['message'] ?? 'Something went wrong'); ?>');
<?php endforeach; $admin->w3FlushErrors(); ?>

// Mobile sidebar toggle
document.getElementById('ds-mobile-toggle').addEventListener('click', function() {
  document.getElementById('ds-sidebar').classList.toggle('ds-sidebar-open');
});
</script>
<?php include __DIR__ . '/includes/code-editor.php'; ?>
</body>
</html>
