(function ($, Drupal, drupalSettings, once) {
  'use strict';

  var cfg = drupalSettings.freyrPerformance || {};
  if (!cfg.enabled) return;

  Drupal.behaviors.freyrPerformance = {
    attach: function (context) {

      // ── 1. LAZY LOAD IMAGES (IntersectionObserver) ──────────────────────
      if (cfg.lazyLoadImages) {
        var imgCount = 0;
        var offset = cfg.lazyOffset || 300;
        var excludePatterns = (cfg.excludeLazyImages || '').split('\n').filter(Boolean);

        var imgObserver = 'IntersectionObserver' in window
          ? new IntersectionObserver(function(entries) {
              entries.forEach(function(e) {
                if (!e.isIntersecting) return;
                var img = e.target;
                if (img.dataset.src) img.src = img.dataset.src;
                if (img.dataset.srcset) img.srcset = img.dataset.srcset;
                img.classList.add('freyr-loaded');
                imgObserver.unobserve(img);
              });
            }, { rootMargin: offset + 'px 0px' })
          : null;

        once('freyr-img', 'img', context).forEach(function(img) {
          var $img = $(img);
          imgCount++;

          // Always protect first image (hero)
          if (cfg.skipFirstImage && imgCount === 1) {
            $img.attr({ fetchpriority: 'high', loading: 'eager', decoding: 'sync' });
            $img.addClass('freyr-loaded');
            return;
          }

          // Protect logo
          if ($img.closest('.logo,.site-logo,.navbar-brand,.header-logo').length) return;

          // Check exclusions
          var src = img.src || img.getAttribute('data-src') || '';
          if (excludePatterns.some(function(p) { return p && src.indexOf(p) !== -1; })) return;

          // Skip tiny images
          var w = parseInt($img.attr('width') || '0');
          if (w > 0 && w < 60) return;

          if (!$img.attr('loading')) {
            $img.attr({ loading: 'lazy', decoding: 'async' });
            $img.on('load', function() { $(this).addClass('freyr-loaded'); });
            if (img.complete) $img.addClass('freyr-loaded');
          }
          if (imgObserver) imgObserver.observe(img);
        });
      }

      // ── 2. LAZY LOAD IFRAMES ────────────────────────────────────────────
      if (cfg.lazyLoadIframes) {
        once('freyr-iframe', 'iframe', context).forEach(function(el) {
          if (!el.getAttribute('loading')) el.setAttribute('loading', 'lazy');
        });
      }

      // ── 3. LAZY LOAD VIDEOS ─────────────────────────────────────────────
      if (cfg.lazyLoadVideos) {
        once('freyr-video', 'video', context).forEach(function(el) {
          if (!el.getAttribute('preload')) el.setAttribute('preload', 'none');
        });
      }

      // ── 4. FIX IMAGE DIMENSIONS (CLS) ───────────────────────────────────
      if (cfg.fixImageDimensions) {
        once('freyr-dim', 'img', context).forEach(function(img) {
          function setDims() {
            if (img.naturalWidth > 0 && !img.getAttribute('width')) {
              img.setAttribute('width',  img.naturalWidth);
              img.setAttribute('height', img.naturalHeight);
              if (!img.style.aspectRatio)
                img.style.aspectRatio = img.naturalWidth + '/' + img.naturalHeight;
            }
          }
          img.complete ? setDims() : img.addEventListener('load', setDims);
        });
      }

      // ── 5. CLS FIXES — reserve space for all dynamic elements ───────────
      if (cfg.fixCls) {

        // Reserve slider space (most critical CLS fix)
        var sel = cfg.sliderSelector || '.slick-slider';
        once('freyr-slider-cls', sel, context).forEach(function(slider) {
          var $s = $(slider);
          var h = cfg.sliderMinHeight || '500px';
          if (!$s.hasClass('slick-initialized')) {
            $s.css({ minHeight: h, contain: 'layout', overflow: 'hidden' });
            $s.on('init afterChange', function() {
              setTimeout(function() { $s.css('minHeight', ''); }, 500);
            });
          }
        });

        // Reserve space for sticky header/navbar
        once('freyr-header-cls', 'header,.header,.navbar,[class*=site-header]', context).forEach(function(el) {
          var h = $(el).outerHeight(true);
          if (h > 0) $(el).css({ minHeight: h + 'px', contain: 'layout' });
        });

        // Reserve space for announcement/top bars
        once('freyr-topbar-cls', '[class*=top-bar],[class*=alert-bar],[class*=announcement],[class*=notice-bar]', context).forEach(function(el) {
          var h = $(el).outerHeight(true);
          if (h > 0) $(el).css({ minHeight: h + 'px', contain: 'layout' });
        });

        // Reserve space for chat widgets (huge CLS cause)
        once('freyr-chat-cls', '[class*=chat],[id*=chat],[id*=tawk],[id*=crisp],[id*=intercom],[class*=chatbot]', context).forEach(function(el) {
          $(el).css({ contain: 'layout' });
        });

        // Reserve space for cookie banners
        once('freyr-cookie-cls', '[class*=cookie],[id*=cookie],[class*=gdpr],[id*=gdpr]', context).forEach(function(el) {
          $(el).css({ contain: 'layout' });
        });

        // Fix images that may cause layout shift — wrap in aspect-ratio container
        once('freyr-img-cls', 'img[width][height]:not([loading=eager])', context).forEach(function(img) {
          var w = img.getAttribute('width');
          var h = img.getAttribute('height');
          if (w && h && !img.style.aspectRatio) {
            img.style.aspectRatio = w + '/' + h;
          }
        });
      }

      // ── 6. SLICK SLIDER OPTIMIZATION (LCP) ─────────────────────────────
      if (cfg.optimizeSlick) {
        var slickSel = cfg.sliderSelector || '.slick-slider';
        once('freyr-slick', slickSel, context).forEach(function(slider) {
          var $s = $(slider);

          function optimizeSlides() {
            $s.find('.slick-slide').not('.slick-cloned').each(function(i) {
              var $img = $(this).find('img').first();
              if (!$img.length) return;
              if (i === 0) {
                $img.attr({ fetchpriority: 'high', loading: 'eager', decoding: 'sync' });
                $img.addClass('freyr-loaded');
              } else {
                if (!$img.attr('loading')) $img.attr({ loading: 'lazy', decoding: 'async' });
              }
            });
          }

          $s.hasClass('slick-initialized') ? optimizeSlides() : $s.on('init', optimizeSlides);

          // Preload next slide
          $s.on('beforeChange', function(e, slick, cur, next) {
            var $ni = $(slick.$slides[next]).find('img').first();
            var src = $ni.attr('src') || $ni.attr('data-lazy') || $ni.attr('data-src');
            if (src && !$('link[href="' + src + '"][rel=preload]').length)
              $('<link>').attr({ rel: 'preload', as: 'image', href: src }).appendTo('head');
          });
        });
      }

      // ── 7. MEGA MENU OPTIMIZATION ────────────────────────────────────────
      if (cfg.optimizeMegaMenu) {
        once('freyr-menu', 'nav,.main-navigation,#block-main-navigation', context).forEach(function(nav) {
          $(nav).find('.menu-item').css('contain', 'layout');
        });
      }

      // ── 8. FONT OPTIMIZATION ─────────────────────────────────────────────
      if (cfg.optimizeFonts) {
        once('freyr-fonts', 'head', context).forEach(function() {
          $('link[href*="fonts.googleapis.com"]').each(function() {
            var href = $(this).attr('href');
            if (href && href.indexOf('display=swap') === -1)
              $(this).attr('href', href + (href.indexOf('?') !== -1 ? '&' : '?') + 'display=swap');
          });
        });
      }

      // ── 9. INP FIX — Remove 300ms tap delay ─────────────────────────────
      if (cfg.fixInp) {
        once('freyr-inp', 'a,button,[role=button],input[type=submit],label,select', context).forEach(function(el) {
          if (!el.style.touchAction) el.style.touchAction = 'manipulation';
        });
      }

      // ── 10. FORCED REFLOW PREVENTION ─────────────────────────────────────
      // Batch DOM reads to prevent layout thrashing
      if (cfg.fixForcedReflow) {
        // Use passive event listeners everywhere possible
        once('freyr-passive', document, context).forEach(function() {
          var passiveSupported = false;
          try {
            window.addEventListener('test', null, Object.defineProperty({}, 'passive', {
              get: function() { passiveSupported = true; return true; }
            }));
          } catch(e) {}

          if (passiveSupported) {
            // These are the most common forced reflow triggers
            var passiveEvents = ['scroll', 'touchstart', 'touchmove', 'wheel', 'mousewheel'];
            passiveEvents.forEach(function(evt) {
              document.addEventListener(evt, function(){}, { passive: true, capture: false });
            });
          }
        });
      }

      // ── 11. PREFETCH ON HOVER ────────────────────────────────────────────
      if (cfg.prefetchOnHover) {
        once('freyr-prefetch', 'nav a[href],header a[href]', context).forEach(function(link) {
          $(link).on('mouseenter', function() {
            var href = $(this).attr('href');
            if (!href || /^(#|javascript:|mailto:|tel:)/.test(href)) return;
            if (/^https?:\/\//.test(href) && href.indexOf(window.location.hostname) === -1) return;
            if ($('link[href="' + href + '"][rel=prefetch]').length) return;
            $('<link>').attr({ rel: 'prefetch', href: href }).appendTo('head');
          });
        });
      }

      // ── 12. CDN URL REWRITE ──────────────────────────────────────────────
      if (cfg.cdnUrl) {
        var cdn = cfg.cdnUrl.replace(/\/$/, '');
        var origin = window.location.origin;
        once('freyr-cdn', 'img[src]', context).forEach(function(el) {
          if (el.src && el.src.indexOf(origin) === 0)
            el.src = cdn + el.src.replace(origin, '');
        });
      }

      // ── 13. BACKGROUND IMAGE LAZY LOAD ──────────────────────────────────
      if ('IntersectionObserver' in window) {
        once('freyr-bg', '[data-bg]', context).forEach(function(el) {
          var bgObs = new IntersectionObserver(function(entries) {
            entries.forEach(function(e) {
              if (e.isIntersecting) {
                e.target.style.backgroundImage = 'url(' + e.target.getAttribute('data-bg') + ')';
                bgObs.unobserve(e.target);
              }
            });
          }, { rootMargin: '300px' });
          bgObs.observe(el);
        });
      }

    }
  };

})(jQuery, Drupal, drupalSettings, once);
