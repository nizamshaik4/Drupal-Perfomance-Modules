(function ($) {
  'use strict';

  $(document).ready(function () {

    // ── Highlight active tab on settings page ─────────────────────────────
    $('body').addClass('freyr-optimized-admin');

    // ── Auto-validate Hero Image URL ──────────────────────────────────────
    var $heroField = $('input[name="hero_image_url"]');
    if ($heroField.length) {
      $heroField.on('blur', function () {
        var url = $(this).val().trim();
        if (!url) return;

        // Check if URL looks valid
        if (!/^https?:\/\/.+\.(jpg|jpeg|png|webp|gif|svg)/i.test(url)) {
          $(this).css('border-color', '#ea4335');
          if (!$('#freyr-url-warn').length) {
            $(this).after('<p id="freyr-url-warn" style="color:#ea4335;font-size:12px;margin:4px 0;">⚠️ URL should be a direct image URL ending in .jpg, .png, .webp etc.</p>');
          }
        } else {
          $(this).css('border-color', '#34a853');
          $('#freyr-url-warn').remove();
          if (!$('#freyr-url-ok').length) {
            $(this).after('<p id="freyr-url-ok" style="color:#34a853;font-size:12px;margin:4px 0;">✅ Valid image URL!</p>');
          }
        }
      });

      $heroField.on('focus', function () {
        $('#freyr-url-warn, #freyr-url-ok').remove();
        $(this).css('border-color', '');
      });
    }

    // ── Score estimator ───────────────────────────────────────────────────
    var checkboxes = [
      'enable_optimization', 'inline_critical_css', 'lazy_load_images',
      'defer_javascript', 'delay_third_party', 'optimize_slick',
      'optimize_mega_menu', 'optimize_fonts', 'prefetch_on_hover',
      'fix_inp', 'fix_image_dimensions', 'lazy_load_iframes'
    ];

    function updateScoreEstimate() {
      var heroSet = $('input[name="hero_image_url"]').val().trim().length > 0;
      var enabled = 0;
      checkboxes.forEach(function (name) {
        if ($('input[name="' + name + '"]').is(':checked')) enabled++;
      });

      var baseScore = 29; // current score
      var gain = 0;
      if (heroSet) gain += 12;
      gain += Math.round((enabled / checkboxes.length) * 30);

      var estimated = Math.min(95, baseScore + gain);
      var color = estimated >= 90 ? '#34a853' : estimated >= 70 ? '#fbbc04' : '#ea4335';

      if ($('#freyr-score-estimate').length) {
        $('#freyr-score-estimate').html(
          '📊 Estimated Score: <strong style="color:' + color + '">' + estimated + '/100</strong> ' +
          (heroSet ? '(Hero URL set ✅)' : '(Set Hero URL for +12 pts)')
        ).css({ background: '#f8f9fa', padding: '8px 14px', borderRadius: '6px', display: 'block', margin: '15px 0', fontSize: '13px', border: '1px solid #e0e0e0' });
      }
    }

    // Add score estimator after header
    if ($('.freyr-settings-header').length) {
      $('.freyr-settings-header').after('<div id="freyr-score-estimate"></div>');
      $('input[type="checkbox"], input[name="hero_image_url"]').on('change input', updateScoreEstimate);
      updateScoreEstimate();
    }

    // ── Quick copy console command ────────────────────────────────────────
    var consoleCmd = "document.querySelector('.slick-slide:not(.slick-cloned) img')?.src";
    if ($('input[name="hero_image_url"]').length && !$('#freyr-copy-cmd').length) {
      $('input[name="hero_image_url"]').before(
        '<div id="freyr-copy-cmd" style="margin-bottom:10px;">' +
        '<button type="button" class="button button--small" id="freyr-copy-btn">📋 Copy Console Command</button>' +
        '<span id="freyr-copy-msg" style="margin-left:10px;color:#34a853;font-size:12px;display:none">✅ Copied! Paste in browser Console (F12)</span>' +
        '</div>'
      );

      $('#freyr-copy-btn').on('click', function () {
        if (navigator.clipboard) {
          navigator.clipboard.writeText(consoleCmd).then(function () {
            $('#freyr-copy-msg').show().delay(3000).fadeOut();
          });
        } else {
          // Fallback
          var $tmp = $('<input>').val(consoleCmd).appendTo('body').select();
          document.execCommand('copy');
          $tmp.remove();
          $('#freyr-copy-msg').show().delay(3000).fadeOut();
        }
      });
    }

    // ── Confirm cache clear ───────────────────────────────────────────────
    $('a[href*="clear-cache"]').on('click', function (e) {
      if (!confirm('Clear all Freyr Speed Optimizer caches?')) {
        e.preventDefault();
      }
    });

  });

})(jQuery);
