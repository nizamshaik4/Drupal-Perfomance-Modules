# Drupal Speed Master

**Enterprise-grade performance optimizer for Drupal 10/11.**  
Successor to Freyr Performance v2.0 Pro, upgraded with features inspired by W3Speedster.

---

## What's New vs. Freyr Performance v2.0 Pro

| Feature | Freyr v2.0 Pro | Drupal Speed Master |
|---|---|---|
| LCP hero preload | ✅ | ✅ Improved |
| Lazy load images | ✅ | ✅ + fade-in animation |
| Lazy load iframes/video | ❌ | ✅ NEW |
| Lazy load CSS backgrounds | ❌ | ✅ NEW |
| Critical CSS | ✅ Basic | ✅ + Cron regeneration |
| JS defer (safe mode) | ✅ | ✅ Improved |
| CLS fixes | ✅ | ✅ + content-visibility |
| **WebP auto-conversion** | ❌ | ✅ **NEW** (GD/Imagick) |
| **HTML page caching** | ❌ | ✅ **NEW** |
| **CDN URL rewriting** | ❌ | ✅ **NEW** |
| **Google Fonts localization** | ❌ | ✅ **NEW** |
| **Gzip + Brotli .htaccess** | Manual | ✅ **NEW** (automated) |
| **Expires headers** | Manual | ✅ **NEW** (automated) |
| **Core Web Vitals logging** | ❌ | ✅ **NEW** (real-user data) |
| **Settings change log** | ❌ | ✅ **NEW** |
| **Exclusions (page/JS/CSS/media)** | Basic | ✅ **NEW** (granular) |
| **Dashboard with score estimator** | ✅ Basic | ✅ Improved |
| **Image optimization status** | ❌ | ✅ **NEW** |

---

## Installation

```
Upload to: /modules/custom/drupal_speed_master/
Enable:    Admin → Extend → "Drupal Speed Master" → Install
Settings:  Admin → Configuration → Development → Drupal Speed Master
Dashboard: Admin → Configuration → Development → Drupal Speed Master → Dashboard
```

---

## Quick Start Checklist

1. **Set Hero Image URL** (LCP tab) — +12 pts
2. **Enable Critical CSS** — +10 pts
3. **Enable CLS Fixes** — +10 pts
4. **Enable WebP conversion** (WebP tab) — +8 pts
5. **Enable JS defer** (safe mode) — +8 pts
6. **Enable HTML Cache** — +8 pts
7. **Enable delay 3rd-party** — +7 pts
8. **Enable Gzip + Expires** (Server tab) — +11 pts
9. **Enable Drupal aggregation** — +10 pts
10. **Add Cloudflare** (external) — +10–15 pts

Total potential: **~90+ on Mobile, 96+ on Desktop**

---

## WebP Conversion

Requires one of:
- PHP GD library with WebP support (`imagewebp()`)  
- PHP Imagick extension

Check status at: `Admin → Reports → Status report`

---

## Module Structure

```
drupal_speed_master/
├── drupal_speed_master.info.yml
├── drupal_speed_master.module          ← All PHP hooks
├── drupal_speed_master.routing.yml
├── drupal_speed_master.links.menu.yml
├── drupal_speed_master.libraries.yml
├── config/install/
│   └── drupal_speed_master.settings.yml
├── css/
│   ├── speed_master_frontend.css       ← CLS fixes, lazy load styles
│   └── speed_master_admin.css          ← Dashboard UI
├── js/
│   ├── speed_master_frontend.js        ← Lazy load, 3rd-party delay, vitals
│   └── speed_master_admin.js           ← Score estimator, dashboard
├── src/
│   ├── Controller/
│   │   └── SpeedMasterDashboardController.php
│   └── Form/
│       └── SpeedMasterSettingsForm.php  ← Full settings (10 tabs)
└── templates/
    └── drupal-speed-master-dashboard.html.twig
```

---

*Drupal Speed Master v1.0 | Feb 2026*
