/**
 * Drupal Speed Master — Admin JavaScript
 */
(function ($, Drupal) {
  'use strict';

  Drupal.behaviors.speedMasterAdmin = {
    attach: function (context, settings) {
      // Animate score counter on dashboard.
      $('.dsm-dashboard-score', context).once('dsm-score-anim').each(function () {
        var $el = $(this);
        var target = parseInt($el.text(), 10);
        var current = 0;
        var step = Math.max(1, Math.floor(target / 40));
        var interval = setInterval(function () {
          current = Math.min(current + step, target);
          $el.text(current);
          if (current >= target) clearInterval(interval);
        }, 30);
      });

      // Show/hide child settings based on parent checkbox.
      $('[data-dsm-parent]', context).once('dsm-toggle').each(function () {
        var parent = $(this).data('dsm-parent');
        var $parent = $('#' + parent);
        var $self = $(this);
        function toggle() {
          $self.closest('.form-item').toggle($parent.is(':checked'));
        }
        $parent.on('change', toggle);
        toggle();
      });
    }
  };

})(jQuery, Drupal);
