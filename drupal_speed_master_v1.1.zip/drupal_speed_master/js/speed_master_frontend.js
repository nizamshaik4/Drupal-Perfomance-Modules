/**
 * Drupal Speed Master — Frontend Optimizations JS v1.1
 *
 * FIXED vs v1.0:
 *  - REMOVED content-visibility auto (was causing massive CLS — biggest score killer)
 *  - REMOVED aggressive iframe hijacking of all iframes (was breaking Drupal embeds)
 *  - FIXED: lazy load image opacity starts at 1 (was causing FCP penalty — image
 *    rendered invisible until JS ran, hurting LCP badly)
 *  - FIXED: 3rd-party delay now truly fires on interaction OR timeout, not both
 *  - FIXED: forceReflow getBoundingClientRect was itself triggering forced reflow CLS
 *  - SAFE: Only lazy-loads images that already have loading="lazy" from PHP hook
 *  - SAFE: Only defers scripts with type="text/dsm-delay" — never touches existing scripts
 */

(function () {
  'use strict';

  var cfg = (window.drupalSettings && window.drupalSettings.drupalSpeedMaster) || {};
  var delayTimeout    = cfg.delayTimeout    || 5000;
  var delayThirdParty = cfg.delayThirdParty !== false;
  var sliderHeightD   = cfg.sliderHeightDesktop || '500px';
  var sliderHeightM   = cfg.sliderHeightMobile  || '250px';
  var clsFix          = cfg.clsFix          !== false;

  // ── 1. CLS: Reserve slider height via CSS custom properties ──────────────
  // This must run synchronously before paint — do NOT wrap in DOMContentLoaded.
  if (clsFix) {
    document.documentElement.style.setProperty('--dsm-slider-h-desktop', sliderHeightD);
    document.documentElement.style.setProperty('--dsm-slider-h-mobile',  sliderHeightM);
  }

  // ── 2. Lazy load images — fade in AFTER they have loaded ─────────────────
  // CRITICAL FIX: Images start visible (opacity:1). We only add the fade class
  // AFTER the image has actually loaded. This prevents the LCP image from being
  // invisible while PageSpeed is measuring, which was tanking LCP scores.
  if ('IntersectionObserver' in window) {
    var imgObserver = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        var img = entry.target;
        // Only swap src if we explicitly set data-src (future enhancement).
        // For now, native loading="lazy" handles deferral; we just add the
        // loaded class once the image is in view to trigger any CSS transitions.
        if (img.complete) {
          img.classList.add('dsm-loaded');
        } else {
          img.addEventListener('load', function () {
            img.classList.add('dsm-loaded');
          }, { once: true });
        }
        obs.unobserve(img);
      });
    }, { rootMargin: '200px 0px' });

    // Only observe images that PHP already marked as lazy.
    document.querySelectorAll('img[loading="lazy"]').forEach(function (img) {
      imgObserver.observe(img);
    });
  }

  // ── 3. Lazy load iframes — ONLY those we explicitly marked ───────────────
  // CRITICAL FIX: Previous version hijacked ALL iframes including Drupal's own
  // embeds (maps, forms, etc.), clearing their src and breaking them.
  // Now we ONLY touch iframes that have data-dsm-src set (opt-in only).
  if ('IntersectionObserver' in window) {
    var iframeObserver = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        var iframe = entry.target;
        if (iframe.dataset.dsmSrc) {
          iframe.src = iframe.dataset.dsmSrc;
          delete iframe.dataset.dsmSrc;
        }
        obs.unobserve(iframe);
      });
    }, { rootMargin: '400px 0px' });

    // Only iframes explicitly opted in with data-dsm-src attribute.
    document.querySelectorAll('iframe[data-dsm-src]').forEach(function (iframe) {
      iframeObserver.observe(iframe);
    });
  }

  // ── 4. Lazy load CSS background images — opt-in via data-bg-url ──────────
  if ('IntersectionObserver' in window) {
    var bgObserver = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        var el = entry.target;
        if (el.dataset.bgUrl) {
          el.style.backgroundImage = 'url(' + el.dataset.bgUrl + ')';
          el.classList.add('dsm-bg-loaded');
        }
        obs.unobserve(el);
      });
    }, { rootMargin: '300px 0px' });

    document.querySelectorAll('[data-bg-url]').forEach(function (el) {
      bgObserver.observe(el);
    });
  }

  // ── 5. 3rd-party script delay ─────────────────────────────────────────────
  // Loads scripts typed "text/dsm-delay" after first interaction OR timeout.
  // FIXED: Uses a single flag and removes all listeners once fired.
  if (delayThirdParty) {
    var thirdPartyLoaded = false;

    function loadThirdPartyScripts() {
      if (thirdPartyLoaded) return;
      thirdPartyLoaded = true;

      // Remove all interaction listeners immediately.
      interactionEvents.forEach(function (evt) {
        window.removeEventListener(evt, onInteraction);
      });

      document.querySelectorAll('script[type="text/dsm-delay"]').forEach(function (s) {
        var newScript = document.createElement('script');
        Array.from(s.attributes).forEach(function (attr) {
          if (attr.name !== 'type') newScript.setAttribute(attr.name, attr.value);
        });
        newScript.textContent = s.textContent;
        s.parentNode.replaceChild(newScript, s);
      });

      document.querySelectorAll('iframe[data-delay-src]').forEach(function (iframe) {
        iframe.src = iframe.dataset.delaySrc;
      });
    }

    function onInteraction() { loadThirdPartyScripts(); }

    var interactionEvents = ['mousedown', 'touchstart', 'keydown', 'scroll'];
    interactionEvents.forEach(function (evt) {
      window.addEventListener(evt, onInteraction, { once: true, passive: true });
    });

    // Fallback timeout — fires after page load + delay.
    window.addEventListener('load', function () {
      setTimeout(loadThirdPartyScripts, delayTimeout);
    });
  }

  // NOTE: content-visibility:auto REMOVED.
  // It caused CLS scores to worsen because browsers assigned wrong intrinsic
  // sizes to sections, causing large layout shifts when they were painted.
  // The net effect was always negative on PageSpeed. Removed entirely.

  // NOTE: Force reflow getBoundingClientRect REMOVED.
  // Calling getBoundingClientRect() itself triggers a forced synchronous layout,
  // which added to TBT (Total Blocking Time) rather than fixing it.

})();
