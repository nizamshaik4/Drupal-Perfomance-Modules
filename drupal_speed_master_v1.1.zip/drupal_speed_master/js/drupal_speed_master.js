/**
 * Drupal Speed Master — Frontend JavaScript
 *
 * Handles:
 * 1. Background image lazy loading (IntersectionObserver)
 * 2. Delayed third-party script execution
 * 3. INP optimization helpers
 */
(function (Drupal, drupalSettings) {
  'use strict';

  // =========================================================================
  // 1. Background image lazy loading
  // =========================================================================
  function initLazyBackgrounds() {
    var lazyBgs = document.querySelectorAll('.dsm-lazy-bg[data-bg]');
    if (!lazyBgs.length) return;

    if ('IntersectionObserver' in window) {
      var bgObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            var el = entry.target;
            el.style.backgroundImage = 'url(' + el.getAttribute('data-bg') + ')';
            el.classList.add('dsm-bg-loaded');
            el.removeAttribute('data-bg');
            bgObserver.unobserve(el);
          }
        });
      }, { rootMargin: '200px 0px' });

      lazyBgs.forEach(function (el) { bgObserver.observe(el); });
    } else {
      // Fallback: load all immediately.
      lazyBgs.forEach(function (el) {
        el.style.backgroundImage = 'url(' + el.getAttribute('data-bg') + ')';
        el.classList.add('dsm-bg-loaded');
      });
    }
  }

  // =========================================================================
  // 2. Execute delayed scripts (marked with data-dsm-delay)
  // =========================================================================
  function loadDelayedScripts() {
    var delayed = document.querySelectorAll('script[data-dsm-delay]');
    delayed.forEach(function (s) {
      var ns = document.createElement('script');
      var src = s.getAttribute('data-src') || s.getAttribute('src');
      if (src) {
        ns.src = src;
        ns.async = true;
      } else {
        ns.textContent = s.textContent;
      }
      document.body.appendChild(ns);
      s.parentNode.removeChild(s);
    });
  }

  // =========================================================================
  // 3. INP optimization — debounce heavy click handlers
  // =========================================================================
  function initInpOptimizations() {
    // Yield to the browser between tasks using scheduler or setTimeout fallback.
    window.dsmYield = function (fn) {
      if (window.scheduler && scheduler.postTask) {
        scheduler.postTask(fn, { priority: 'user-visible' });
      } else {
        setTimeout(fn, 0);
      }
    };
  }

  // =========================================================================
  // 4. Auto-detect hero image URL for admin hint (console helper)
  // =========================================================================
  window.dsmDetectHeroImage = function () {
    var selectors = [
      '.slick-slide:not(.slick-cloned) img',
      '.hero img',
      '.banner img',
      '[class*="hero"] img',
      '.field--name-field-hero-image img',
      'main img:first-of-type',
    ];
    for (var i = 0; i < selectors.length; i++) {
      var el = document.querySelector(selectors[i]);
      if (el && el.src) {
        console.log('%c[Drupal Speed Master] Hero image detected:', 'color:#0cce6b;font-weight:bold;');
        console.log('%c' + el.src, 'color:#4285f4;text-decoration:underline;');
        console.log('Copy this URL into: Admin → Speed Master Settings → LCP & Hero Image → Hero Image URL');
        return el.src;
      }
    }
    console.warn('[Drupal Speed Master] No hero image auto-detected. Try checking your slider/banner markup.');
    return null;
  };

  // =========================================================================
  // Bootstrap
  // =========================================================================
  Drupal.behaviors.speedMaster = {
    attach: function (context, settings) {
      if (context !== document) return;
      initLazyBackgrounds();
      initInpOptimizations();
    }
  };

  // Run delayed scripts on load.
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initLazyBackgrounds);
  } else {
    initLazyBackgrounds();
  }

})(Drupal, drupalSettings);
