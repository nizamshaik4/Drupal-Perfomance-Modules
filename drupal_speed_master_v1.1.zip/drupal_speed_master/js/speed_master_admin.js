/**
 * Drupal Speed Master — Admin JS
 * Score estimator, live checklist animation, tab memory.
 */
(function ($, Drupal, once) {
  'use strict';

  Drupal.behaviors.dsmAdmin = {
    attach: function (context) {

      // ── Animate score ring on dashboard ────────────────────────────────
      once('dsm-score', '.dsm-score-ring', context).forEach(function (el) {
        var score = parseInt(el.dataset.score || '0', 10);
        el.style.setProperty('--score-pct', Math.round(score) + '%');
      });

      // ── Animate progress bar ────────────────────────────────────────────
      once('dsm-progress', '.dsm-progress-fill', context).forEach(function (el) {
        var pct = el.dataset.pct || '0';
        requestAnimationFrame(function () {
          requestAnimationFrame(function () {
            el.style.width = pct + '%';
          });
        });
      });

      // ── Cache clear confirmation ────────────────────────────────────────
      once('dsm-cache-btn', '.dsm-cache-actions a', context).forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          if (!confirm(Drupal.t('Clear this cache? This cannot be undone.'))) {
            e.preventDefault();
          }
        });
      });

      // ── Settings form: master toggle hides/shows all other sections ─────
      once('dsm-master-toggle', '#edit-optimization-enabled', context).forEach(function (chk) {
        function toggleSections() {
          var tabs = document.querySelector('.vertical-tabs');
          if (tabs) {
            tabs.style.opacity = chk.checked ? '1' : '.4';
            tabs.style.pointerEvents = chk.checked ? '' : 'none';
          }
        }
        chk.addEventListener('change', toggleSections);
        toggleSections();
      });

      // ── Real-time PageSpeed score estimator in settings form ────────────
      var checkboxes = context.querySelectorAll ? context.querySelectorAll('.form-checkbox') : [];
      if (checkboxes.length && document.getElementById('dsm-live-score')) {
        function updateLiveScore() {
          var score = 20;
          var pointMap = {
            'edit-hero-image-url': 12,
            'edit-critical-css-enabled': 10,
            'edit-cls-fix-enabled': 10,
            'edit-defer-js': 8,
            'edit-delay-third-party': 7,
            'edit-webp-convert-jpg': 8,
            'edit-lazy-load-images': 5,
            'edit-html-cache-enabled': 8,
            'edit-enable-gzip': 6,
            'edit-enable-expires-headers': 5,
          };
          Object.entries(pointMap).forEach(function (entry) {
            var el = document.getElementById(entry[0]);
            if (el && (el.type === 'checkbox' ? el.checked : el.value.trim())) {
              score += entry[1];
            }
          });
          score = Math.min(score, 98);
          var el = document.getElementById('dsm-live-score');
          if (el) el.textContent = '~' + score;
        }
        checkboxes.forEach(function (chk) {
          chk.addEventListener('change', updateLiveScore);
        });
        updateLiveScore();
      }

    }
  };

})(jQuery, Drupal, once);
