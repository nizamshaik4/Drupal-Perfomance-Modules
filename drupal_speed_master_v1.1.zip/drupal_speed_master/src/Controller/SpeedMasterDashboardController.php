<?php

namespace Drupal\drupal_speed_master\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Dashboard controller for Drupal Speed Master.
 */
class SpeedMasterDashboardController extends ControllerBase {

  /**
   * Renders the main dashboard.
   */
  public function dashboard(): array {
    $config = \Drupal::config('drupal_speed_master.settings')->getRawData();
    $perf   = \Drupal::config('system.performance');

    // Compute checklist status.
    $checklist = [
      'optimization_enabled' => [
        'label'   => $this->t('Speed Master optimization ON'),
        'status'  => !empty($config['optimization_enabled']),
        'points'  => 5,
        'help'    => $this->t('Enable the master optimization switch.'),
      ],
      'hero_image_url' => [
        'label'   => $this->t('Hero/LCP image URL set'),
        'status'  => !empty($config['hero_image_url']),
        'points'  => 12,
        'help'    => $this->t('Set the hero image URL in LCP & Images tab. Worth +12 points.'),
      ],
      'lazy_load_images' => [
        'label'   => $this->t('Image lazy loading enabled'),
        'status'  => !empty($config['lazy_load_images']),
        'points'  => 5,
        'help'    => $this->t('Enable lazy loading in LCP & Images tab.'),
      ],
      'critical_css_enabled' => [
        'label'   => $this->t('Critical CSS enabled'),
        'status'  => !empty($config['critical_css_enabled']),
        'points'  => 10,
        'help'    => $this->t('Enable Critical CSS in CSS Optimization tab.'),
      ],
      'defer_js' => [
        'label'   => $this->t('JavaScript deferred'),
        'status'  => !empty($config['defer_js']),
        'points'  => 8,
        'help'    => $this->t('Enable JS defer in JavaScript Optimization tab.'),
      ],
      'delay_third_party' => [
        'label'   => $this->t('3rd-party scripts delayed'),
        'status'  => !empty($config['delay_third_party']),
        'points'  => 7,
        'help'    => $this->t('Enable delay in General tab.'),
      ],
      'webp_convert_jpg' => [
        'label'   => $this->t('WebP image conversion enabled'),
        'status'  => !empty($config['webp_convert_jpg']) || !empty($config['webp_convert_png']),
        'points'  => 8,
        'help'    => $this->t('Enable in WebP & Image Optimization tab.'),
      ],
      'cls_fix_enabled' => [
        'label'   => $this->t('CLS fixes enabled'),
        'status'  => !empty($config['cls_fix_enabled']),
        'points'  => 10,
        'help'    => $this->t('Enable CLS fixes in CLS Fixes tab.'),
      ],
      'drupal_css_agg' => [
        'label'   => $this->t('Drupal CSS aggregation ON'),
        'status'  => (bool) $perf->get('css.preprocess'),
        'points'  => 5,
        'help'    => $this->t('<a href="/admin/config/development/performance">Enable CSS aggregation</a> in Drupal Performance settings.'),
      ],
      'drupal_js_agg' => [
        'label'   => $this->t('Drupal JS aggregation ON'),
        'status'  => (bool) $perf->get('js.preprocess'),
        'points'  => 5,
        'help'    => $this->t('<a href="/admin/config/development/performance">Enable JS aggregation</a> in Drupal Performance settings.'),
      ],
      'html_cache_enabled' => [
        'label'   => $this->t('HTML page cache enabled'),
        'status'  => !empty($config['html_cache_enabled']),
        'points'  => 8,
        'help'    => $this->t('Enable HTML caching in HTML Page Cache tab.'),
      ],
      'cdn_enabled' => [
        'label'   => $this->t('CDN configured'),
        'status'  => !empty($config['cdn_enabled']) && !empty($config['cdn_url']),
        'points'  => 6,
        'help'    => $this->t('Configure a CDN in the CDN Integration tab.'),
      ],
      'enable_gzip' => [
        'label'   => $this->t('Gzip compression enabled'),
        'status'  => !empty($config['enable_gzip']),
        'points'  => 6,
        'help'    => $this->t('Enable Gzip in Server Optimizations tab. Or use Cloudflare.'),
      ],
      'enable_expires_headers' => [
        'label'   => $this->t('Browser cache (Expires headers) enabled'),
        'status'  => !empty($config['enable_expires_headers']),
        'points'  => 5,
        'help'    => $this->t('Enable Expires headers in Server Optimizations tab.'),
      ],
    ];

    $total_points   = array_sum(array_column($checklist, 'points'));
    $earned_points  = 0;
    foreach ($checklist as $item) {
      if ($item['status']) {
        $earned_points += $item['points'];
      }
    }
    $score_estimate = (int) round(20 + ($earned_points / $total_points) * 75);

    // Recent web vitals summary.
    $vitals_summary = [];
    if (!empty($config['webvitals_logging'])) {
      try {
        $rows = \Drupal::database()->select('drupal_speed_master_webvitals', 'v')
          ->fields('v', ['metric_name', 'metric_value', 'metric_rating'])
          ->orderBy('id', 'DESC')
          ->range(0, 100)
          ->execute()
          ->fetchAll();
        $grouped = [];
        foreach ($rows as $row) {
          $grouped[$row->metric_name][] = $row->metric_value;
        }
        foreach ($grouped as $name => $values) {
          $vitals_summary[$name] = round(array_sum($values) / count($values), 2);
        }
      }
      catch (\Exception $e) {}
    }

    return [
      '#theme' => 'drupal_speed_master_dashboard',
      '#checklist' => $checklist,
      '#score_estimate' => $score_estimate,
      '#earned_points' => $earned_points,
      '#total_points' => $total_points,
      '#vitals_summary' => $vitals_summary,
      '#attached' => ['library' => ['drupal_speed_master/admin']],
      '#cache' => ['max-age' => 0],
    ];
  }

  /**
   * Image optimization page.
   */
  public function optimizeImages(): array {
    $config = \Drupal::config('drupal_speed_master.settings')->getRawData();

    $info = [
      'webp_enabled' => !empty($config['webp_convert_jpg']) || !empty($config['webp_convert_png']),
      'gd_webp'      => function_exists('imagewebp'),
      'imagick'      => extension_loaded('imagick'),
    ];

    // Count images by type.
    try {
      $db = \Drupal::database();
      $jpeg_count = $db->select('file_managed', 'f')->condition('filemime', 'image/jpeg')->countQuery()->execute()->fetchField();
      $png_count  = $db->select('file_managed', 'f')->condition('filemime', 'image/png')->countQuery()->execute()->fetchField();
      $webp_count = $db->select('file_managed', 'f')->condition('filemime', 'image/webp')->countQuery()->execute()->fetchField();
      $info['jpeg_count'] = $jpeg_count;
      $info['png_count']  = $png_count;
      $info['webp_count'] = $webp_count;
    }
    catch (\Exception $e) {
      $info['jpeg_count'] = $info['png_count'] = $info['webp_count'] = 'N/A';
    }

    return [
      '#markup' => $this->buildImageOptimizationPage($info, $config),
      '#attached' => ['library' => ['drupal_speed_master/admin']],
      '#cache' => ['max-age' => 0],
    ];
  }

  /**
   * Web vitals log page.
   */
  public function webVitalsLog(): array {
    $rows = [];
    try {
      $results = \Drupal::database()->select('drupal_speed_master_webvitals', 'v')
        ->fields('v')
        ->orderBy('id', 'DESC')
        ->range(0, 200)
        ->execute()
        ->fetchAll();
      foreach ($results as $r) {
        $badge_class = 'dsm-badge-' . ($r->metric_rating ?: 'unknown');
        $rows[] = [
          $r->metric_name,
          number_format($r->metric_value, 2),
          ['data' => ['#markup' => "<span class=\"dsm-badge {$badge_class}\">" . htmlspecialchars($r->metric_rating) . '</span>']],
          htmlspecialchars($r->page_url),
          \Drupal::service('date.formatter')->format($r->timestamp, 'short'),
        ];
      }
    }
    catch (\Exception $e) {
      $rows[] = [['data' => ['#markup' => '<em>' . $this->t('No data yet. Enable Web Vitals Logging in Settings → Logging tab.') . '</em>'], 'colspan' => 5]];
    }

    return [
      '#type' => 'table',
      '#header' => [$this->t('Metric'), $this->t('Value'), $this->t('Rating'), $this->t('Page URL'), $this->t('Time')],
      '#rows' => $rows,
      '#empty' => $this->t('No web vitals data recorded yet.'),
      '#attributes' => ['class' => ['dsm-vitals-table']],
      '#attached' => ['library' => ['drupal_speed_master/admin']],
      '#cache' => ['max-age' => 0],
    ];
  }

  /**
   * Cache clear action endpoint.
   */
  public function cacheClear(Request $request): \Symfony\Component\HttpFoundation\RedirectResponse {
    $type = $request->query->get('type', 'all');
    switch ($type) {
      case 'html':
        \Drupal::cache('page')->deleteAll();
        $msg = $this->t('HTML page cache cleared.');
        break;
      case 'css':
        _drupal_flush_css_js();
        $msg = $this->t('CSS/JS cache cleared.');
        break;
      default:
        drupal_flush_all_caches();
        $msg = $this->t('All caches cleared.');
    }
    $this->messenger()->addStatus($msg);
    return $this->redirect('drupal_speed_master.dashboard');
  }

  /**
   * Build image optimization info page HTML.
   */
  private function buildImageOptimizationPage(array $info, array $config): string {
    $gd_status   = $info['gd_webp'] ? '<span class="dsm-ok">✓ Available</span>' : '<span class="dsm-warn">✗ Not available</span>';
    $im_status   = $info['imagick'] ? '<span class="dsm-ok">✓ Available</span>' : '<span class="dsm-warn">✗ Not available</span>';
    $webp_status = $info['webp_enabled'] ? '<span class="dsm-ok">✓ Enabled</span>' : '<span class="dsm-warn">Configure in Settings</span>';

    return <<<HTML
<div class="dsm-image-opt-page">
  <h2>Image Optimization Status</h2>
  <table class="dsm-status-table">
    <tr><td>GD WebP support</td><td>{$gd_status}</td></tr>
    <tr><td>Imagick extension</td><td>{$im_status}</td></tr>
    <tr><td>WebP auto-conversion</td><td>{$webp_status}</td></tr>
    <tr><td>JPEG images in system</td><td><strong>{$info['jpeg_count']}</strong></td></tr>
    <tr><td>PNG images in system</td><td><strong>{$info['png_count']}</strong></td></tr>
    <tr><td>WebP images in system</td><td><strong>{$info['webp_count']}</strong></td></tr>
  </table>
  <p><a href="/admin/config/development/drupal-speed-master" class="button button--primary">Configure WebP Settings</a></p>
  <h3>How WebP Conversion Works</h3>
  <p>When enabled, every new image upload (JPG or PNG) is automatically converted to WebP. 
  Existing images are <strong>not</strong> retroactively converted — re-upload them or use Drush/a migration script for bulk conversion.</p>
  <h3>Serving WebP to Browsers</h3>
  <p>Modern browsers (Chrome, Firefox, Edge, Safari 14+) support WebP natively. 
  For older browsers, configure a CDN with automatic WebP serving, or add .htaccess rules to serve WebP with JPEG/PNG fallback.</p>
</div>
HTML;
  }

}
