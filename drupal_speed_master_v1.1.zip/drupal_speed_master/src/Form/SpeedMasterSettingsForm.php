<?php

namespace Drupal\drupal_speed_master\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Settings form for Drupal Speed Master.
 *
 * Tabs:
 *   General | LCP & Images | WebP & Optimize | CSS | JavaScript |
 *   HTML Cache | CDN | Exclusions | Server (.htaccess) | Logs
 */
class SpeedMasterSettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return ['drupal_speed_master.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'drupal_speed_master_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $config = $this->config('drupal_speed_master.settings');

    $form['#attached']['library'][] = 'drupal_speed_master/admin';

    // ── Master toggle ──────────────────────────────────────────────────────
    $form['optimization_enabled'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable Drupal Speed Master'),
      '#description' => $this->t('Master switch. Uncheck to disable all optimizations instantly without uninstalling.'),
      '#default_value' => $config->get('optimization_enabled') ?? TRUE,
    ];

    // ── Vertical tabs ──────────────────────────────────────────────────────
    $form['tabs'] = [
      '#type' => 'vertical_tabs',
      '#default_tab' => 'general',
    ];

    // =====================================================================
    // TAB: GENERAL
    // =====================================================================
    $form['general'] = [
      '#type' => 'details',
      '#title' => $this->t('⚡ General'),
      '#group' => 'tabs',
      '#description' => $this->t('Global performance settings.'),
    ];
    $form['general']['gtm_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Google Tag Manager ID'),
      '#description' => $this->t('Enter your GTM-XXXXXX ID. Leave empty to skip GTM injection.'),
      '#default_value' => $config->get('gtm_id') ?? '',
      '#placeholder' => 'GTM-XXXXXX',
    ];
    $form['general']['delay_timeout'] = [
      '#type' => 'number',
      '#title' => $this->t('Third-party delay timeout (ms)'),
      '#description' => $this->t('Delay 3rd-party scripts by this many milliseconds after page load. Default: 5000.'),
      '#default_value' => $config->get('delay_timeout') ?? 5000,
      '#min' => 1000,
      '#max' => 15000,
    ];
    $form['general']['delay_third_party'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Delay 3rd-party scripts (GTM, analytics, chat widgets)'),
      '#default_value' => $config->get('delay_third_party') ?? TRUE,
    ];

    // =====================================================================
    // TAB: LCP & IMAGES
    // =====================================================================
    $form['lcp_images'] = [
      '#type' => 'details',
      '#title' => $this->t('🖼 LCP & Images'),
      '#group' => 'tabs',
      '#description' => $this->t('Optimize Largest Contentful Paint and image loading.'),
    ];
    $form['lcp_images']['hero_image_url'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Hero / LCP Image URL'),
      '#description' => $this->t('URL of the above-fold hero image (slider, banner, etc). This adds a <code>rel=preload fetchpriority=high</code> hint and is worth +8–12 LCP points. Find it via: <code>document.querySelector(\'.slick-slide:not(.slick-cloned) img\')?.src</code>'),
      '#default_value' => $config->get('hero_image_url') ?? '',
      '#placeholder' => 'https://example.com/sites/default/files/hero.webp',
    ];
    $form['lcp_images']['hero_image_fetchpriority'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Add fetchpriority="high" to hero image'),
      '#default_value' => $config->get('hero_image_fetchpriority') ?? TRUE,
    ];
    $form['lcp_images']['slider_selector'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Slider CSS selector'),
      '#default_value' => $config->get('slider_selector') ?? '.slick-slider',
    ];
    $form['lcp_images']['slider_height_desktop'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Slider reserved height — Desktop'),
      '#description' => $this->t('Pre-reserves space to prevent CLS. E.g. 500px'),
      '#default_value' => $config->get('slider_height_desktop') ?? '500px',
    ];
    $form['lcp_images']['slider_height_mobile'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Slider reserved height — Mobile'),
      '#default_value' => $config->get('slider_height_mobile') ?? '250px',
    ];
    $form['lcp_images']['lazy_load_images'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Lazy load images (loading=lazy + decoding=async)'),
      '#default_value' => $config->get('lazy_load_images') ?? TRUE,
    ];
    $form['lcp_images']['lazy_load_iframes'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Lazy load iframes (YouTube, Google Maps, embeds)'),
      '#default_value' => $config->get('lazy_load_iframes') ?? TRUE,
    ];
    $form['lcp_images']['lazy_load_videos'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Lazy load videos'),
      '#default_value' => $config->get('lazy_load_videos') ?? TRUE,
    ];
    $form['lcp_images']['lazy_load_background'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Lazy load CSS background images'),
      '#default_value' => $config->get('lazy_load_background') ?? TRUE,
    ];
    $form['lcp_images']['responsive_images'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enforce responsive images (serve smaller images on mobile)'),
      '#default_value' => $config->get('responsive_images') ?? TRUE,
    ];

    // =====================================================================
    // TAB: WebP & IMAGE OPTIMIZATION (NEW)
    // =====================================================================
    $form['webp'] = [
      '#type' => 'details',
      '#title' => $this->t('🌐 WebP & Image Optimization'),
      '#group' => 'tabs',
      '#description' => $this->t('Convert images to WebP on upload and compress JPG/PNG. Requires GD with WebP support or Imagick PHP extension.'),
    ];
    $form['webp']['webp_convert_jpg'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Auto-convert JPEG images to WebP on upload'),
      '#default_value' => $config->get('webp_convert_jpg') ?? FALSE,
    ];
    $form['webp']['webp_convert_png'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Auto-convert PNG images to WebP on upload'),
      '#default_value' => $config->get('webp_convert_png') ?? FALSE,
    ];
    $form['webp']['webp_quality'] = [
      '#type' => 'number',
      '#title' => $this->t('WebP quality (1–100)'),
      '#description' => $this->t('85 is recommended — good balance of quality and file size.'),
      '#default_value' => $config->get('webp_quality') ?? 85,
      '#min' => 1,
      '#max' => 100,
    ];
    $form['webp']['optimize_jpg_png'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Optimize JPG/PNG images (lossless compression)'),
      '#default_value' => $config->get('optimize_jpg_png') ?? FALSE,
    ];
    $form['webp']['img_quality'] = [
      '#type' => 'number',
      '#title' => $this->t('JPG/PNG optimization quality (1–100)'),
      '#default_value' => $config->get('img_quality') ?? 90,
      '#min' => 1,
      '#max' => 100,
    ];
    $form['webp']['remove_original_img'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Remove original image after WebP conversion'),
      '#description' => $this->t('<strong>Warning:</strong> This permanently deletes the original file. Make sure you have backups.'),
      '#default_value' => $config->get('remove_original_img') ?? FALSE,
    ];

    // =====================================================================
    // TAB: CSS
    // =====================================================================
    $form['css'] = [
      '#type' => 'details',
      '#title' => $this->t('🎨 CSS Optimization'),
      '#group' => 'tabs',
    ];
    $form['css']['enable_css_optimization'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable CSS optimization'),
      '#default_value' => $config->get('enable_css_optimization') ?? TRUE,
    ];
    $form['css']['critical_css_enabled'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable Critical CSS (inline above-fold CSS)'),
      '#description' => $this->t('Inline critical CSS in <code>&lt;head&gt;</code> and defer the rest. Significantly improves FCP and LCP.'),
      '#default_value' => $config->get('critical_css_enabled') ?? TRUE,
    ];
    $form['css']['critical_css_inline'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Inline critical CSS in &lt;style&gt; tag (faster) vs link tag'),
      '#default_value' => $config->get('critical_css_inline') ?? TRUE,
    ];
    $form['css']['critical_css_via_cron'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Regenerate critical CSS via cron'),
      '#description' => $this->t('Auto-update critical CSS on each cron run. Recommended for dynamic sites.'),
      '#default_value' => $config->get('critical_css_via_cron') ?? FALSE,
    ];
    $form['css']['combine_google_fonts'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Combine Google Fonts (merge multiple font requests into one)'),
      '#default_value' => $config->get('combine_google_fonts') ?? TRUE,
    ];
    $form['css']['localize_google_fonts'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Localize / self-host Google Fonts (serve from your domain)'),
      '#description' => $this->t('Downloads and serves Google Fonts from your own server. Eliminates third-party DNS lookup and is required for GDPR compliance in some regions.'),
      '#default_value' => $config->get('localize_google_fonts') ?? FALSE,
    ];
    $form['css']['load_style_in_head'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Force these CSS files into &lt;head&gt; to prevent CLS'),
      '#description' => $this->t('Enter one CSS filename or pattern per line. These will be moved to the very top of &lt;head&gt;.'),
      '#default_value' => $config->get('load_style_in_head') ?? '',
      '#rows' => 4,
    ];
    $form['css']['remove_unused_css'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Remove unused CSS (experimental — requires manual exclusion tuning)'),
      '#default_value' => $config->get('remove_unused_css') ?? FALSE,
    ];

    // =====================================================================
    // TAB: JAVASCRIPT
    // =====================================================================
    $form['javascript'] = [
      '#type' => 'details',
      '#title' => $this->t('⚡ JavaScript Optimization'),
      '#group' => 'tabs',
    ];
    $form['javascript']['defer_js'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Defer JavaScript'),
      '#default_value' => $config->get('defer_js') ?? TRUE,
    ];
    $form['javascript']['defer_js_safe_mode'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Safe mode (only defer analytics — never jQuery/Slick/Bootstrap)'),
      '#description' => $this->t('Highly recommended. Prevents sliders and interactive components from breaking.'),
      '#default_value' => $config->get('defer_js_safe_mode') ?? TRUE,
    ];
    $form['javascript']['exclude_js'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Additional JS files to exclude from defer (one per line)'),
      '#description' => $this->t('Enter matching text of JS file paths. E.g. <code>my-custom-slider</code>'),
      '#default_value' => $config->get('exclude_js') ?? '',
      '#rows' => 4,
    ];
    $form['javascript']['exclude_js_inline'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Load these inline scripts as external URLs (reduces page size)'),
      '#description' => $this->t('Enter matching text of inline &lt;script&gt; content to extract as external files.'),
      '#default_value' => $config->get('exclude_js_inline') ?? '',
      '#rows' => 4,
    ];

    // =====================================================================
    // TAB: HTML CACHE (NEW)
    // =====================================================================
    $form['html_cache'] = [
      '#type' => 'details',
      '#title' => $this->t('🗄 HTML Page Cache'),
      '#group' => 'tabs',
      '#description' => $this->t('Cache fully rendered HTML pages for anonymous users. Biggest server-side speed boost available.'),
    ];
    $form['html_cache']['html_cache_enabled'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable HTML page caching'),
      '#default_value' => $config->get('html_cache_enabled') ?? FALSE,
    ];
    $form['html_cache']['html_cache_logged_in'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable caching for logged-in users'),
      '#default_value' => $config->get('html_cache_logged_in') ?? FALSE,
    ];
    $form['html_cache']['html_cache_ttl'] = [
      '#type' => 'number',
      '#title' => $this->t('Cache lifetime (seconds)'),
      '#description' => $this->t('How long to keep cached pages. Default: 86400 (24 hours).'),
      '#default_value' => $config->get('html_cache_ttl') ?? 86400,
      '#min' => 60,
    ];
    $form['html_cache']['html_cache_exclude_urls'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Exclude these URLs from HTML caching (one per line)'),
      '#description' => $this->t('E.g. /cart, /checkout, /user'),
      '#default_value' => $config->get('html_cache_exclude_urls') ?? "/user\n/cart\n/checkout\n/admin",
      '#rows' => 5,
    ];
    $form['html_cache']['html_cache_actions'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['dsm-cache-actions']],
      'clear_html' => [
        '#type' => 'link',
        '#title' => $this->t('🗑 Clear HTML Cache Now'),
        '#url' => \Drupal\Core\Url::fromRoute('drupal_speed_master.cache_clear', [], ['query' => ['type' => 'html']]),
        '#attributes' => ['class' => ['button', 'button--danger']],
      ],
    ];

    // =====================================================================
    // TAB: CDN (NEW)
    // =====================================================================
    $form['cdn'] = [
      '#type' => 'details',
      '#title' => $this->t('🌍 CDN Integration'),
      '#group' => 'tabs',
      '#description' => $this->t('Serve static assets from a CDN to reduce server load and improve global latency.'),
    ];
    $form['cdn']['cdn_enabled'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable CDN URL rewriting'),
      '#default_value' => $config->get('cdn_enabled') ?? FALSE,
    ];
    $form['cdn']['cdn_url'] = [
      '#type' => 'textfield',
      '#title' => $this->t('CDN base URL'),
      '#description' => $this->t('Your CDN URL including scheme, e.g. <code>https://cdn.example.com</code>'),
      '#default_value' => $config->get('cdn_url') ?? '',
      '#placeholder' => 'https://cdn.example.com',
    ];
    $form['cdn']['cdn_file_types'] = [
      '#type' => 'textfield',
      '#title' => $this->t('File types to serve via CDN'),
      '#description' => $this->t('Comma-separated. Options: image, css, js, font, audio, video'),
      '#default_value' => $config->get('cdn_file_types') ?? 'image,css,js,font',
    ];
    $form['cdn']['cdn_exclude_paths'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Exclude these paths from CDN (comma-separated)'),
      '#description' => $this->t('E.g. <code>/sites/default/files/private/,/admin/</code>'),
      '#default_value' => $config->get('cdn_exclude_paths') ?? '',
    ];

    // =====================================================================
    // TAB: PRECONNECT & PRELOAD
    // =====================================================================
    $form['preconnect'] = [
      '#type' => 'details',
      '#title' => $this->t('🔗 Preconnect & Preload'),
      '#group' => 'tabs',
    ];
    $form['preconnect']['preconnect_origins'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Preconnect origins (one per line)'),
      '#description' => $this->t('Add origins for early connection. E.g. fonts, CDN, analytics.'),
      '#default_value' => $config->get('preconnect_origins') ?? "https://fonts.googleapis.com\nhttps://fonts.gstatic.com\nhttps://cdn.jsdelivr.net",
      '#rows' => 5,
    ];
    $form['preconnect']['dns_prefetch'] = [
      '#type' => 'textarea',
      '#title' => $this->t('DNS prefetch origins (one per line)'),
      '#default_value' => $config->get('dns_prefetch') ?? "//fonts.googleapis.com\n//cdn.jsdelivr.net",
      '#rows' => 4,
    ];
    $form['preconnect']['preload_resources'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Preload specific resources (one URL per line)'),
      '#description' => $this->t('Add critical assets (fonts, images, CSS) for early preloading. File type is detected automatically.'),
      '#default_value' => $config->get('preload_resources') ?? '',
      '#rows' => 5,
    ];

    // =====================================================================
    // TAB: SERVER (.htaccess)  (NEW — from W3Speedster)
    // =====================================================================
    $form['server'] = [
      '#type' => 'details',
      '#title' => $this->t('🖥 Server Optimizations (.htaccess)'),
      '#group' => 'tabs',
      '#description' => $this->t('These settings modify your .htaccess file. Backup first! Requires Apache with mod_deflate and mod_expires.'),
    ];
    $form['server']['enable_gzip'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable Gzip/Brotli compression via .htaccess'),
      '#description' => $this->t('Adds mod_deflate and mod_brotli directives. Typically adds +5–8 PageSpeed points.'),
      '#default_value' => $config->get('enable_gzip') ?? FALSE,
    ];
    $form['server']['enable_expires_headers'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable browser caching (Expires headers) via .htaccess'),
      '#description' => $this->t('Tells browsers to cache static assets locally. Major performance win for repeat visits.'),
      '#default_value' => $config->get('enable_expires_headers') ?? FALSE,
    ];
    $form['server']['expires_images'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Image cache lifetime'),
      '#default_value' => $config->get('expires_images') ?? '1 year',
      '#size' => 15,
    ];
    $form['server']['expires_css_js'] = [
      '#type' => 'textfield',
      '#title' => $this->t('CSS/JS cache lifetime'),
      '#default_value' => $config->get('expires_css_js') ?? '1 month',
      '#size' => 15,
    ];
    $form['server']['htaccess_note'] = [
      '#type' => 'markup',
      '#markup' => '<div class="messages messages--warning">' . $this->t('<strong>Tip:</strong> If you\'re on Cloudflare, use its Caching and Speed settings instead of .htaccess. Cloudflare adds +10–15 PageSpeed points alone.') . '</div>',
    ];

    // =====================================================================
    // TAB: EXCLUSIONS  (NEW — from W3Speedster)
    // =====================================================================
    $form['exclusions'] = [
      '#type' => 'details',
      '#title' => $this->t('🚫 Exclusions'),
      '#group' => 'tabs',
      '#description' => $this->t('Fine-tune which pages, scripts, or assets are excluded from optimization.'),
    ];
    $form['exclusions']['exclude_pages'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Exclude pages from all optimization (one path per line)'),
      '#description' => $this->t('E.g. <code>/checkout</code>, <code>/user/login</code>, <code>/special-page</code>'),
      '#default_value' => $config->get('exclude_pages') ?? '',
      '#rows' => 5,
    ];
    $form['exclusions']['exclude_css_files'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Exclude CSS files from optimization (one pattern per line)'),
      '#default_value' => $config->get('exclude_css_files') ?? '',
      '#rows' => 4,
    ];
    $form['exclusions']['exclude_js_files'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Exclude JS files from defer/optimization (one pattern per line)'),
      '#default_value' => $config->get('exclude_js_files') ?? '',
      '#rows' => 4,
    ];
    $form['exclusions']['exclude_lazy_media'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Exclude images/videos from lazy loading (one pattern per line)'),
      '#description' => $this->t('Match by class, alt text, URL path, or filename. E.g. <code>logo</code>, <code>hero-above-fold</code>'),
      '#default_value' => $config->get('exclude_lazy_media') ?? '',
      '#rows' => 4,
    ];

    // =====================================================================
    // TAB: CLS FIXES
    // =====================================================================
    $form['cls'] = [
      '#type' => 'details',
      '#title' => $this->t('📐 CLS Fixes'),
      '#group' => 'tabs',
      '#description' => $this->t('Fix Cumulative Layout Shift — the biggest mobile score killer.'),
    ];
    $form['cls']['cls_fix_enabled'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable CLS fixes'),
      '#default_value' => $config->get('cls_fix_enabled') ?? TRUE,
    ];
    $form['cls']['reserve_slider_space'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Pre-reserve slider space (prevents layout jump while slider loads)'),
      '#default_value' => $config->get('reserve_slider_space') ?? TRUE,
    ];
    $form['cls']['reserve_chat_space'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Reserve space for chat widgets (Tawk, Crisp, Intercom)'),
      '#default_value' => $config->get('reserve_chat_space') ?? TRUE,
    ];
    $form['cls']['force_reflow_fix'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Force layout reflow fix (prevents invisible forced reflow CLS)'),
      '#default_value' => $config->get('force_reflow_fix') ?? TRUE,
    ];

    // =====================================================================
    // TAB: LOGGING  (NEW — from W3Speedster)
    // =====================================================================
    $form['logging'] = [
      '#type' => 'details',
      '#title' => $this->t('📊 Logging & Diagnostics'),
      '#group' => 'tabs',
    ];
    $form['logging']['webvitals_logging'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable Core Web Vitals logging (CLS, LCP, INP per page)'),
      '#description' => $this->t('Collects real-user CWV data. View at <a href="/admin/config/development/drupal-speed-master/webvitals-log">Web Vitals Log</a>.'),
      '#default_value' => $config->get('webvitals_logging') ?? FALSE,
    ];
    $form['logging']['webvitals_log_ttl'] = [
      '#type' => 'number',
      '#title' => $this->t('Keep web vitals logs for (days)'),
      '#default_value' => $config->get('webvitals_log_ttl') ?? 30,
      '#min' => 1,
      '#max' => 365,
    ];
    $form['logging']['change_log_enabled'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable settings change log'),
      '#description' => $this->t('Logs all settings changes with before/after values and the user who made them.'),
      '#default_value' => $config->get('change_log_enabled') ?? FALSE,
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    $cdn_url = $form_state->getValue('cdn_url');
    if (!empty($cdn_url) && !filter_var($cdn_url, FILTER_VALIDATE_URL)) {
      $form_state->setErrorByName('cdn_url', $this->t('CDN URL must be a valid URL including http:// or https://'));
    }
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $config = $this->config('drupal_speed_master.settings');
    $old_config = $config->getRawData();

    $fields = [
      'optimization_enabled', 'gtm_id', 'delay_timeout', 'delay_third_party',
      'hero_image_url', 'hero_image_fetchpriority', 'slider_selector',
      'slider_height_desktop', 'slider_height_mobile', 'lazy_load_images',
      'lazy_load_iframes', 'lazy_load_videos', 'lazy_load_background', 'responsive_images',
      // WebP
      'webp_convert_jpg', 'webp_convert_png', 'webp_quality', 'optimize_jpg_png',
      'img_quality', 'remove_original_img',
      // CSS
      'enable_css_optimization', 'critical_css_enabled', 'critical_css_inline',
      'critical_css_via_cron', 'combine_google_fonts', 'localize_google_fonts',
      'load_style_in_head', 'remove_unused_css',
      // JS
      'defer_js', 'defer_js_safe_mode', 'exclude_js', 'exclude_js_inline',
      // HTML Cache
      'html_cache_enabled', 'html_cache_logged_in', 'html_cache_ttl', 'html_cache_exclude_urls',
      // CDN
      'cdn_enabled', 'cdn_url', 'cdn_file_types', 'cdn_exclude_paths',
      // Preconnect
      'preconnect_origins', 'dns_prefetch', 'preload_resources',
      // Server
      'enable_gzip', 'enable_expires_headers', 'expires_images', 'expires_css_js',
      // Exclusions
      'exclude_pages', 'exclude_css_files', 'exclude_js_files', 'exclude_lazy_media',
      // CLS
      'cls_fix_enabled', 'reserve_slider_space', 'reserve_chat_space', 'force_reflow_fix',
      // Logging
      'webvitals_logging', 'webvitals_log_ttl', 'change_log_enabled',
    ];

    foreach ($fields as $field) {
      $new_val = $form_state->getValue($field);
      $old_val = $old_config[$field] ?? NULL;
      if ($new_val !== $old_val) {
        drupal_speed_master_log_change($field, $old_val, $new_val);
      }
      $config->set($field, $new_val);
    }

    $config->save();

    // Update .htaccess if server settings changed.
    drupal_speed_master_update_htaccess();

    // Clear all caches so changes take effect immediately.
    drupal_flush_all_caches();

    $this->messenger()->addStatus($this->t('Drupal Speed Master settings saved. All caches cleared.'));
    parent::submitForm($form, $form_state);
  }

}
