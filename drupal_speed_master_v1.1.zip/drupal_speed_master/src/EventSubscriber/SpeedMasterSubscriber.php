<?php

namespace Drupal\drupal_speed_master\EventSubscriber;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpFoundation\Response;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Session\AccountInterface;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * SpeedMasterSubscriber — post-processes HTML output for performance.
 *
 * Handles:
 *  - HTML page caching (file-based with TTL & exclusions)
 *  - CSS minification & Google Fonts combining/localizing
 *  - JS minification & aggressive defer injection
 *  - CDN URL rewriting
 *  - Background image lazy loading
 *  - Deferred non-critical CSS (loadCSS pattern)
 *  - Remove query strings from static assets
 *  - font-display: swap in <link> tags
 */
class SpeedMasterSubscriber implements EventSubscriberInterface {

  protected ConfigFactoryInterface $configFactory;
  protected AccountInterface $currentUser;
  protected RequestStack $requestStack;
  protected string $cacheDir;

  public function __construct(
    ConfigFactoryInterface $config_factory,
    AccountInterface $current_user,
    RequestStack $request_stack
  ) {
    $this->configFactory = $config_factory;
    $this->currentUser   = $current_user;
    $this->requestStack  = $request_stack;
    $this->cacheDir      = DRUPAL_ROOT . '/sites/default/files/dsm_cache';
  }

  public static function getSubscribedEvents(): array {
    return [
      KernelEvents::REQUEST  => ['onRequest',  300],
      KernelEvents::RESPONSE => ['onResponse', -100],
    ];
  }

  // -------------------------------------------------------------------------
  // REQUEST: Serve from HTML cache if available
  // -------------------------------------------------------------------------
  public function onRequest(RequestEvent $event): void {
    if (!$event->isMainRequest()) return;
    $config = $this->configFactory->get('drupal_speed_master.settings');
    if (!$config->get('html_caching')) return;

    $request = $event->getRequest();
    if (!$this->isCacheable($request, $config)) return;

    $cache_file = $this->getCacheFilePath($request);
    if (file_exists($cache_file)) {
      $ttl = (int) ($config->get('cache_ttl') ?? 86400);
      if ((time() - filemtime($cache_file)) < $ttl) {
        $content = file_get_contents($cache_file);
        $response = new Response($content, 200, [
          'Content-Type' => 'text/html; charset=UTF-8',
          'X-DSM-Cache'  => 'HIT',
        ]);
        $event->setResponse($response);
      }
    }
  }

  // -------------------------------------------------------------------------
  // RESPONSE: Process & optionally cache HTML output
  // -------------------------------------------------------------------------
  public function onResponse(ResponseEvent $event): void {
    if (!$event->isMainRequest()) return;
    $response = $event->getResponse();
    if (!($response instanceof Response)) return;

    $content_type = $response->headers->get('Content-Type', '');
    if (strpos($content_type, 'text/html') === FALSE) return;

    $config  = $this->configFactory->get('drupal_speed_master.settings');
    $request = $event->getRequest();

    // Skip admin and non-HTML responses.
    if (\Drupal::service('router.admin_context')->isAdminRoute()) return;

    $html = $response->getContent();
    if (empty($html)) return;

    $html = $this->processHtml($html, $config);

    // Write to HTML cache.
    if ($config->get('html_caching') && $this->isCacheable($request, $config)) {
      $this->writeCacheFile($request, $html);
    }

    $response->setContent($html);
    $response->headers->set('X-DSM-Optimized', 'true');
  }

  // -------------------------------------------------------------------------
  // MAIN HTML PROCESSING PIPELINE
  // -------------------------------------------------------------------------
  protected function processHtml(string $html, $config): string {

    // 1. Combine & optionally localize Google Fonts.
    if ($config->get('combine_google_fonts')) {
      $html = $this->combineGoogleFonts($html, $config);
    }

    // 2. Defer non-critical CSS (loadCSS pattern).
    if ($config->get('defer_non_critical_css')) {
      $html = $this->deferNonCriticalCss($html);
    }

    // 3. CSS minification (inline <style> blocks).
    if ($config->get('css_minification')) {
      $html = $this->minifyInlineCss($html);
    }

    // 4. JS minification (inline <script> blocks).
    if ($config->get('js_minification')) {
      $html = $this->minifyInlineJs($html);
    }

    // 5. Background image lazy loading.
    if ($config->get('lazy_load_background_images')) {
      $html = $this->lazyLoadBackgroundImages($html);
    }

    // 6. Remove query strings from static assets.
    if ($config->get('remove_query_strings')) {
      $html = $this->removeQueryStrings($html);
    }

    // 7. CDN URL rewriting.
    if ($config->get('cdn_enabled')) {
      $html = $this->rewriteCdnUrls($html, $config);
    }

    // 8. Delay third-party scripts (mark with data-dsm-delay).
    if ($config->get('delay_third_party_js')) {
      $html = $this->markThirdPartyScripts($html, $config);
    }

    // 9. Add missing image width/height attributes.
    if ($config->get('add_missing_image_dimensions')) {
      $html = $this->addMissingImageDimensions($html);
    }

    // 10. font-display: swap in <link> stylesheet tags for Google Fonts.
    if ($config->get('font_display_swap')) {
      $html = $this->injectFontDisplaySwap($html);
    }

    return $html;
  }

  // -------------------------------------------------------------------------
  // GOOGLE FONTS: Combine all requests into one URL
  // -------------------------------------------------------------------------
  protected function combineGoogleFonts(string $html, $config): string {
    $pattern = '/<link[^>]+href=["\']https:\/\/fonts\.googleapis\.com\/css[^"\']*["\'][^>]*>/i';
    preg_match_all($pattern, $html, $matches);
    if (empty($matches[0]) || count($matches[0]) < 2) return $html;

    $families = [];
    $display = 'swap';

    foreach ($matches[0] as $tag) {
      if (preg_match('/href=["\']([^"\']+)["\']/', $tag, $href_m)) {
        $url = html_entity_decode($href_m[1]);
        $parsed = parse_url($url);
        parse_str($parsed['query'] ?? '', $params);
        if (!empty($params['family'])) {
          foreach (explode('|', $params['family']) as $f) {
            $families[$f] = $f;
          }
        }
      }
      $html = str_replace($tag, '', $html);
    }

    if (!empty($families)) {
      $combined_url = 'https://fonts.googleapis.com/css2?family='
        . implode('&family=', array_map('urlencode', array_keys($families)))
        . '&display=' . $display;

      $new_tag = "<link rel=\"preload\" href=\"{$combined_url}\" as=\"style\" onload=\"this.onload=null;this.rel='stylesheet'\">"
        . "<noscript><link rel=\"stylesheet\" href=\"{$combined_url}\"></noscript>";

      // Insert after </title> or at start of <head>.
      $html = preg_replace('/<\/title>/i', '</title>' . $new_tag, $html, 1);
    }

    return $html;
  }

  // -------------------------------------------------------------------------
  // DEFER NON-CRITICAL CSS (loadCSS pattern)
  // -------------------------------------------------------------------------
  protected function deferNonCriticalCss(string $html): string {
    // Convert render-blocking <link rel="stylesheet"> to async using media swap trick.
    // Skip: critical CSS id'd by dsm-critical-css, or already async.
    $pattern = '/<link([^>]+)rel=["\']stylesheet["\']([^>]*)>/i';
    $html = preg_replace_callback($pattern, function($m) {
      $full = $m[0];
      // Skip admin, print, and already-preloaded.
      if (strpos($full, 'media="print"') !== FALSE
        || strpos($full, "media='print'") !== FALSE
        || strpos($full, 'preload') !== FALSE) {
        return $full;
      }
      // Replace rel="stylesheet" with preload + onload swap.
      $async = str_replace('rel="stylesheet"', 'rel="preload" as="style" onload="this.onload=null;this.rel=\'stylesheet\'"', $full);
      $async = str_replace("rel='stylesheet'", "rel='preload' as='style' onload=\"this.onload=null;this.rel='stylesheet'\"", $async);
      // Append noscript fallback.
      return $async . '<noscript>' . $full . '</noscript>';
    }, $html);

    return $html;
  }

  // -------------------------------------------------------------------------
  // INLINE CSS MINIFICATION
  // -------------------------------------------------------------------------
  protected function minifyInlineCss(string $html): string {
    return preg_replace_callback('/<style[^>]*>(.*?)<\/style>/is', function($m) {
      $css = $m[1];
      // Remove comments.
      $css = preg_replace('/\/\*[^*]*\*+([^\/][^*]*\*+)*\//', '', $css);
      // Remove whitespace.
      $css = preg_replace('/\s*([:;{}>,])\s*/', '$1', $css);
      $css = preg_replace('/\s+/', ' ', $css);
      $css = preg_replace('/;}/', '}', $css);
      return str_replace($m[1], trim($css), $m[0]);
    }, $html);
  }

  // -------------------------------------------------------------------------
  // INLINE JS MINIFICATION (safe — strips comments & excess whitespace)
  // -------------------------------------------------------------------------
  protected function minifyInlineJs(string $html): string {
    return preg_replace_callback('/<script([^>]*)>(.*?)<\/script>/is', function($m) {
      $attrs = $m[1];
      $js    = $m[2];

      // Skip if it has a src, is JSON-LD, or is a template.
      if (strpos($attrs, 'src=') !== FALSE
        || strpos($attrs, 'application/ld+json') !== FALSE
        || strpos($attrs, 'text/template') !== FALSE
        || strpos($attrs, 'text/html') !== FALSE) {
        return $m[0];
      }

      // Remove single-line comments (careful: not URLs).
      $js = preg_replace('/(?<!["\':])\/\/(?![\/:]).*$/m', '', $js);
      // Remove multi-line comments.
      $js = preg_replace('/\/\*[\s\S]*?\*\//', '', $js);
      // Collapse whitespace.
      $js = preg_replace('/\s{2,}/', ' ', $js);
      $js = trim($js);

      return "<script{$attrs}>{$js}</script>";
    }, $html);
  }

  // -------------------------------------------------------------------------
  // BACKGROUND IMAGE LAZY LOADING
  // -------------------------------------------------------------------------
  protected function lazyLoadBackgroundImages(string $html): string {
    // Find elements with inline background-image style — convert to data-bg.
    $html = preg_replace_callback(
      '/(<[a-z][^>]+style=["\'][^"\']*background-image\s*:\s*url\(([^)]+)\)[^"\']*["\'][^>]*>)/i',
      function($m) {
        $tag = $m[1];
        $url = trim($m[2], '"\'');
        // Add data-bg attribute and class for JS lazy loader.
        $tag = preg_replace('/background-image\s*:\s*url\([^)]+\)/', 'background-image:none', $tag);
        $tag = preg_replace('/>$/', " data-bg=\"{$url}\" class=\"dsm-lazy-bg\">", $tag);
        return $tag;
      },
      $html
    );

    return $html;
  }

  // -------------------------------------------------------------------------
  // REMOVE QUERY STRINGS from CSS/JS static assets
  // -------------------------------------------------------------------------
  protected function removeQueryStrings(string $html): string {
    // Remove ?ver=xxx and ?v=xxx from link/script src/href.
    $html = preg_replace('/(<(?:link|script)[^>]+(?:href|src)=["\'][^"\']+)\?(?:ver|v)=[^"\'&]+(["\'])/i', '$1$2', $html);
    return $html;
  }

  // -------------------------------------------------------------------------
  // CDN URL REWRITING
  // -------------------------------------------------------------------------
  protected function rewriteCdnUrls(string $html, $config): string {
    $cdn_entries = $config->get('cdn_entries') ?? [];
    if (empty($cdn_entries)) return $html;

    $base_url = \Drupal::request()->getSchemeAndHttpHost();

    foreach ($cdn_entries as $entry) {
      $cdn_url = rtrim($entry['url'] ?? '', '/');
      $types   = $entry['type'] ?? 'image,css,js,font';
      if (empty($cdn_url)) continue;

      $ext_map = [
        'image' => 'jpg|jpeg|png|gif|webp|svg|ico',
        'css'   => 'css',
        'js'    => 'js',
        'font'  => 'woff|woff2|ttf|eot',
      ];

      $exts = [];
      foreach (explode(',', $types) as $t) {
        $t = trim($t);
        if (isset($ext_map[$t])) $exts[] = $ext_map[$t];
      }
      if (empty($exts)) continue;

      $ext_pattern = implode('|', $exts);
      // Rewrite absolute URLs to CDN.
      $html = preg_replace(
        '/(["\'])(' . preg_quote($base_url, '/') . ')(\/[^"\']+\.(?:' . $ext_pattern . '))/i',
        '$1' . $cdn_url . '$3',
        $html
      );
    }

    return $html;
  }

  // -------------------------------------------------------------------------
  // MARK THIRD-PARTY SCRIPTS for delayed loading
  // -------------------------------------------------------------------------
  protected function markThirdPartyScripts(string $html, $config): string {
    $third_party_patterns = [
      'googletagmanager', 'google-analytics', 'gtag', 'fbq', 'facebook.net',
      'hotjar', 'clarity.ms', 'segment.com', 'mixpanel', 'amplitude',
      'tawk.to', 'tidio', 'intercom', 'hubspot', 'hs-scripts',
      'doubleclick', 'adsbygoogle', 'disqus', 'sharebutton',
    ];

    $exclude_delay_raw = $config->get('exclude_delay_js') ?? '';
    $exclude_delay = array_filter(array_map('trim', explode("\n", $exclude_delay_raw)));

    return preg_replace_callback('/<script([^>]*)src=["\']([^"\']+)["\']([^>]*)>/i', function($m) use ($third_party_patterns, $exclude_delay) {
      $pre  = $m[1];
      $src  = $m[2];
      $post = $m[3];

      // Check exclusions first.
      foreach ($exclude_delay as $ex) {
        if (!empty($ex) && strpos($src, $ex) !== FALSE) return $m[0];
      }

      foreach ($third_party_patterns as $pattern) {
        if (strpos(strtolower($src), $pattern) !== FALSE) {
          // Mark for delayed loading.
          return "<script{$pre}data-dsm-delay data-src=\"{$src}\"{$post}>";
        }
      }
      return $m[0];
    }, $html);
  }

  // -------------------------------------------------------------------------
  // ADD MISSING IMAGE DIMENSIONS
  // -------------------------------------------------------------------------
  protected function addMissingImageDimensions(string $html): string {
    return preg_replace_callback('/<img([^>]+)>/i', function($m) {
      $tag = $m[0];
      // Skip if already has width and height.
      if (preg_match('/width=/i', $tag) && preg_match('/height=/i', $tag)) {
        return $tag;
      }
      // Try to get src.
      if (!preg_match('/src=["\']([^"\']+)["\']/', $tag, $src_m)) return $tag;
      $src = $src_m[1];
      // Only attempt for local files.
      if (strpos($src, 'http') === 0 && strpos($src, \Drupal::request()->getSchemeAndHttpHost()) === FALSE) {
        return $tag;
      }
      $path = DRUPAL_ROOT . parse_url($src, PHP_URL_PATH);
      if (!file_exists($path)) return $tag;

      $size = @getimagesize($path);
      if (!$size) return $tag;

      [$w, $h] = $size;
      if (!preg_match('/width=/i', $tag)) {
        $tag = str_replace('<img', "<img width=\"{$w}\"", $tag);
      }
      if (!preg_match('/height=/i', $tag)) {
        $tag = str_replace('<img', "<img height=\"{$h}\"", $tag);
      }
      return $tag;
    }, $html);
  }

  // -------------------------------------------------------------------------
  // INJECT font-display: swap into Google Fonts link tags
  // -------------------------------------------------------------------------
  protected function injectFontDisplaySwap(string $html): string {
    return preg_replace_callback(
      '/(<link[^>]+href=["\'])(https:\/\/fonts\.googleapis\.com\/css[^"\']*?)(["\'][^>]*>)/i',
      function($m) {
        $href = $m[2];
        if (strpos($href, 'display=') === FALSE) {
          $href .= (strpos($href, '?') === FALSE ? '?' : '&') . 'display=swap';
        }
        return $m[1] . $href . $m[3];
      },
      $html
    );
  }

  // -------------------------------------------------------------------------
  // HTML CACHE helpers
  // -------------------------------------------------------------------------
  protected function isCacheable($request, $config): bool {
    // Only GET requests.
    if ($request->getMethod() !== 'GET') return FALSE;
    // Skip logged-in users unless enabled.
    if ($this->currentUser->isAuthenticated() && !$config->get('cache_logged_in_users')) return FALSE;
    // Skip admin paths.
    $path = $request->getPathInfo();
    if (strpos($path, '/admin') === 0) return FALSE;
    // Check exclusion list.
    $excludes_raw = $config->get('exclude_cache_urls') ?? '/admin,/user,/cart,/checkout';
    foreach (array_filter(array_map('trim', explode(',', $excludes_raw))) as $excl) {
      if (!empty($excl) && strpos($path, $excl) === 0) return FALSE;
    }
    return TRUE;
  }

  protected function getCacheFilePath($request): string {
    $path = $request->getPathInfo();
    $query = $request->getQueryString();
    $key = md5($path . '?' . $query);
    return $this->cacheDir . '/' . $key . '.html';
  }

  protected function writeCacheFile($request, string $html): void {
    if (!is_dir($this->cacheDir)) {
      mkdir($this->cacheDir, 0755, TRUE);
    }
    $file = $this->getCacheFilePath($request);
    $html_with_comment = $html . "\n<!-- DSM Cache: " . date('Y-m-d H:i:s') . " -->";
    @file_put_contents($file, $html_with_comment);
  }

  /**
   * Clear all HTML cache files.
   */
  public function clearCache(): void {
    if (!is_dir($this->cacheDir)) return;
    $files = glob($this->cacheDir . '/*.html');
    if ($files) {
      foreach ($files as $f) @unlink($f);
    }
  }
}
